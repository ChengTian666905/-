# ============================================================
# 成添工具箱 混淆规则（已修正）
#
# 【上一版的致命错误，已修复】
#   旧规则里有这两行：
#     -keep class com.modace.ctmod.security.** { *; }
#     -keep class com.modace.ctmod.lua.LuaCipher { *; }
#   它们会让加密核心与安全模块完全不混淆，反编译出来就是明文，
#   等于把最该保护的代码主动交出去。现已删除。
#
# 【混淆能做什么 / 不能做什么】
#   能：类名方法名变无意义短名，字符串常量可加密，代码阅读成本大幅提高。
#   不能：防止决心足够大的逆向者。Java/Dex 是中间语言，不是机器码，
#         只要能运行就一定能被还原，只是代价高低的问题。
# ============================================================


# ============================================================
# 一、基础保留（这些是系统回调入口，混淆了就运行不了）
# ============================================================

# 四大组件：只保留类名，成员照常混淆。
# 这些类在 AndroidManifest.xml 里被按名字引用，改名会 ClassNotFound。
# 注意：这里只 -keep 类名，不含 { *; }，所以方法体依然会被混淆。
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.content.ContentProvider
-keep public class * extends android.app.Application

# XML 里 android:onClick 绑定的方法（本项目未用，保留以防万一）
-keepclassmembers class * extends android.app.Activity {
    public void *(android.view.View);
}

# 自定义 View 的构造（本项目未用）
-keepclassmembers class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# 资源索引类，混淆了 R.id 会找不到
-keepclassmembers class **.R$* {
    public static <fields>;
}
-keep class **.R$* { *; }


# ============================================================
# 二、字符串加密（关键：密钥、路径、提示语不再明文）
# ============================================================

# 把代码里引用常量字符串的地方改成运行时动态生成
-adaptclassstrings
# 资源文件名与内容里出现的类名一并处理
-adaptresourcefilenames
-adaptresourcefilecontents


# ============================================================
# 三、混淆强度
# ============================================================

# 把类搬到默认包，去掉 com/modace/ctmod 这种有语义的包路径
-repackageclasses ''
# 允许放宽访问权限，让更多方法能被混淆
-allowaccessmodification
# 允许同名不同参的方法重载，进一步抹平语义
-overloadaggressively
# 合并接口与类层级，减少可推断的结构信息
-mergeinterfacesaggressively

# 去掉调试日志，防止内部逻辑通过 log 泄露
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
}
-assumenosideeffects class java.lang.System {
    public static void println(...);
    public static void print(...);
}


# ============================================================
# 四、提高反编译难度
# ============================================================

# 【重点】不要保留 SourceFile 属性。
# 保留它等于告诉反编译器「这段代码原本叫 MainActivity.java 第几行」，
# 逆向者拿到后可读性大幅提升。这里直接丢弃。
-renamesourcefileattribute ''

# 保留注解与泛型签名（某些反射场景需要），但不保留行号
-keepattributes *Annotation*
-keepattributes Signature
# 注意：刻意不写 SourceFile,LineNumberTable


# ============================================================
# 五、本项目的特殊处理
# ============================================================

# 反射调用的类必须保留（本项目无反射，留空）
# 若以后加了反射，在这里补 -keep

# JNI 方法（本项目无）
-keepclasseswithmembernames class * {
    native <methods>;
}

# 序列化（本项目未用）
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}


# ============================================================
# 六、警告抑制（零第三方依赖，其实用不上，留着防编译中断）
# ============================================================
-dontwarn android.support.**
-dontwarn java.lang.invoke.**
-dontwarn javax.annotation.**
-dontnote android.support.**

# 不压缩（避免误删有用的类），只做混淆与优化
-dontshrink

# 不做激进优化，降低在旧 ProGuard 上出兼容问题的概率
-dontoptimize


# ============================================================
# 七、产物输出（发布后保留 mapping.txt，它是还原崩溃堆栈的唯一钥匙）
# ============================================================
-printmapping build/outputs/mapping/release/mapping.txt
-printseeds   build/outputs/mapping/release/seeds.txt
-printusage   build/outputs/mapping/release/unused.txt

# mapping.txt 极其重要：
#   反编译出来的 a.b.c.a() 要靠它才能还原成真实方法名。
#   自己排查线上崩溃也靠它。请妥善保存，每个版本单独留档。
