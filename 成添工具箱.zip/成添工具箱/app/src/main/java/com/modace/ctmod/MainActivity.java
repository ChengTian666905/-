package com.modace.ctmod;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.modace.ctmod.util.DeviceInfo;
import com.modace.ctmod.util.FormatUtil;

/**
 * 主界面：设备状态 + 核心双卡 + 工具宫格。
 */
public class MainActivity extends Activity implements View.OnClickListener {

    private TextView tvMemValue;
    private TextView tvStoreValue;
    private TextView tvCpu;
    private ProgressBar pbMem;
    private ProgressBar pbStore;
    private TextView btnOrient;

    private final Handler handler = new Handler();
    private long[] cpuFirst = null;

    /** 图标字 / 名称 / 角标 / 目标页（null 表示未开放） */
    private static final Tool[] TOOLS = {
            new Tool("固", R.string.tool_protect, "", ProtectActivity.class),
            new Tool("编", R.string.tool_lua_editor, "", LuaEditorActivity.class),
            new Tool("管", R.string.tool_appmgr, null, null),
            new Tool("感", R.string.tool_sensor, null, null),
            new Tool("速", R.string.tool_netspeed, null, null),
            new Tool("密", R.string.tool_source_guard, "", SourceGuardActivity.class),
            new Tool("屏", R.string.tool_screen, null, null),
            new Tool("份", R.string.tool_backup, null, null),
            new Tool("关", R.string.tool_about, "", AboutActivity.class)
    };

    private static class Tool {
        final String icon;
        final int nameRes;
        final String badge;
        final Class<?> target;

        Tool(String icon, int nameRes, String badge, Class<?> target) {
            this.icon = icon;
            this.nameRes = nameRes;
            this.badge = badge;
            this.target = target;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 统一应用全局方向设置，必须早于 setContentView
        OrientUtil.apply(this);
        setContentView(R.layout.activity_main);

        bindViews();
        bindEvents();
        buildToolGrid();

        refreshDeviceInfo();
        refreshCpuAsync();

        // 底部导航：主页 / 版本 / 开发信息，当前页高亮「主页」
        NavBar.bind(this, NavBar.TAB_HOME);
    }

    private void bindViews() {
        tvMemValue = (TextView) findViewById(R.id.tv_mem_value);
        tvStoreValue = (TextView) findViewById(R.id.tv_store_value);
        tvCpu = (TextView) findViewById(R.id.tv_cpu);
        pbMem = (ProgressBar) findViewById(R.id.pb_mem);
        pbStore = (ProgressBar) findViewById(R.id.pb_store);

        TextView tvCores = (TextView) findViewById(R.id.tv_cores);
        TextView tvSdk = (TextView) findViewById(R.id.tv_sdk);
        tvCores.setText(String.valueOf(DeviceInfo.getCpuCores()));
        tvSdk.setText(DeviceInfo.getSystemVersion());

        btnOrient = (TextView) findViewById(R.id.btn_orient);
        updateOrientButtonText();
    }

    private void bindEvents() {
        findViewById(R.id.btn_settings).setOnClickListener(this);
        findViewById(R.id.btn_refresh).setOnClickListener(this);
        findViewById(R.id.card_lua).setOnClickListener(this);
        findViewById(R.id.card_clean).setOnClickListener(this);
        if (btnOrient != null) {
            btnOrient.setOnClickListener(this);
        }
    }

    /** 按钮文案显示「点了之后会变成什么」，依据全局偏好而非当前屏幕状态 */
    private void updateOrientButtonText() {
        if (btnOrient == null) {
            return;
        }
        if (OrientUtil.isLandscape(this)) {
            btnOrient.setText(getString(R.string.action_orient_port));
        } else {
            btnOrient.setText(getString(R.string.action_orient_land));
        }
    }

    /**
     * 切换横竖屏：写入全局偏好后立即应用。
     * 之后打开的所有页面都会读取同一份偏好，方向保持一致。
     */
    private void toggleOrientation() {
        OrientUtil.toggle(this);
    }

    private void buildToolGrid() {
        LinearLayout grid = (LinearLayout) findViewById(R.id.tool_grid);
        if (grid == null) {
            return;
        }
        LayoutInflater inflater = getLayoutInflater();
        LinearLayout row = null;

        for (int i = 0; i < TOOLS.length; i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                rowLp.setMargins(0, 0, 0, 10);
                grid.addView(row, rowLp);
            }

            final Tool tool = TOOLS[i];
            View card = inflater.inflate(R.layout.item_tool_card, null);
            TextView icon = (TextView) card.findViewById(R.id.tool_icon);
            TextView name = (TextView) card.findViewById(R.id.tool_name);
            TextView badge = (TextView) card.findViewById(R.id.tool_badge);

            icon.setText(tool.icon);
            name.setText(tool.nameRes);

            if (tool.target == null) {
                badge.setText(getString(R.string.badge_coming));
                icon.setTextColor(getResources().getColor(R.color.text_hint));
                name.setTextColor(getResources().getColor(R.color.text_hint));
            } else {
                badge.setText(tool.badge);
            }

            card.setTag(tool);
            card.setOnClickListener(this);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(6, 0, 6, 0);
            row.addView(card, lp);
        }
    }

    private void refreshDeviceInfo() {
        long memTotal = DeviceInfo.getTotalMemory();
        long memAvail = DeviceInfo.getAvailMemory(this);
        if (memTotal > 0) {
            tvMemValue.setText(FormatUtil.formatUsedTotal(memTotal, memAvail));
            pbMem.setProgress(FormatUtil.percent(memTotal, memAvail));
        }
        long[] store = DeviceInfo.getStorage();
        if (store[0] > 0) {
            tvStoreValue.setText(FormatUtil.formatUsedTotal(store[0], store[1]));
            pbStore.setProgress(FormatUtil.percent(store[0], store[1]));
        }
    }

    private void refreshCpuAsync() {
        cpuFirst = DeviceInfo.readCpuSnapshot();
        handler.postDelayed(new Runnable() {
            public void run() {
                long[] second = DeviceInfo.readCpuSnapshot();
                int usage = DeviceInfo.calcCpuUsage(cpuFirst, second);
                if (usage >= 0 && tvCpu != null) {
                    tvCpu.setText(usage + "%");
                }
            }
        }, 400);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.card_lua) {
            startActivity(new Intent(this, LuaActivity.class));
            return;
        }
        if (id == R.id.card_clean) {
            startActivity(new Intent(this, CleanActivity.class));
            return;
        }
        if (id == R.id.btn_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return;
        }
        if (id == R.id.btn_refresh) {
            refreshDeviceInfo();
            refreshCpuAsync();
            toast("已刷新");
            return;
        }
        if (id == R.id.btn_orient) {
            toggleOrientation();
            return;
        }
        Object tag = v.getTag();
        if (tag instanceof Tool) {
            Tool tool = (Tool) tag;
            if (tool.target == null) {
                toast(getString(tool.nameRes) + " —— 开发中");
            } else {
                startActivity(new Intent(this, tool.target));
            }
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
