package com.modace.ctmod;

import android.widget.LinearLayout;

import com.modace.ctmod.security.AntiDebug;
import com.modace.ctmod.security.ObfCheck;
import com.modace.ctmod.security.SignCheck;
import com.modace.ctmod.security.TamperCheck;

/**
 * 加固自检页（真实检测）。
 *
 * 展示当前运行环境的各项安全状态，以及本应用可以启用的加固层次。
 * 这里做的是「自检展示」，真正的加固在 proguard-rules.pro 与发布流程里生效。
 */
public class ProtectActivity extends BaseModuleActivity {

    @Override
    protected String getTitleText() {
        return getString(R.string.title_protect);
    }

    @Override
    protected void buildContent(LinearLayout container) {
        addCard(container, "", getString(R.string.protect_intro));

        addSectionTitle(container, "实时检测结果");

        // 0. 混淆状态 —— 最重要的一项，直接决定反编译出来能不能读
        ObfCheck.Result obf = ObfCheck.check(this, null);
        if (!obf.checked) {
            addStatusRow(container, "代码混淆", "无法检测", R.color.accent_orange);
        } else if (obf.obfuscated) {
            addStatusRow(container, "代码混淆", "已混淆", R.color.accent_cyan);
        } else {
            addStatusRow(container, "代码混淆", "未混淆 · 源码可读", R.color.accent_red);
            addCard(container, "为什么反编译能看到代码",
                    "检测到当前安装包里仍保留原始包名路径，说明代码未混淆。\n"
                            + "这样反编译出来的类名、方法名基本就是原样，等于裸奔。\n\n"
                            + "解决：用 release 方式打包。\n"
                            + "debug 构建默认不混淆，点「运行」装到手机上的就是 debug 版。");
        }

        // 1. 签名
        String sha1 = SignCheck.getSignatureSha1(this);
        if (sha1 == null) {
            addStatusRow(container, getString(R.string.protect_sign), "读取失败", R.color.accent_red);
        } else {
            String status = SignCheck.hasExpected()
                    ? (SignCheck.verify(this) ? getString(R.string.status_pass) : "签名不匹配")
                    : "未配置期望值";
            int color = SignCheck.hasExpected()
                    ? (SignCheck.verify(this) ? R.color.accent_cyan : R.color.accent_red)
                    : R.color.accent_orange;
            addStatusRow(container, getString(R.string.protect_sign), status, color);
            // 不再展示具体 SHA1 值，避免外泄
        }

        // 2. 调试器
        boolean dbg = AntiDebug.isDebuggerConnected();
        addStatusRow(container, getString(R.string.protect_debug),
                dbg ? "已连接调试器" : getString(R.string.status_pass),
                dbg ? R.color.accent_red : R.color.accent_cyan);

        // 3. ptrace 跟踪
        int pid = AntiDebug.getTracerPid();
        boolean traced = AntiDebug.isTraced();
        addStatusRow(container, "TracerPid = " + pid,
                traced ? "被跟踪" : getString(R.string.status_pass),
                traced ? R.color.accent_red : R.color.accent_cyan);

        // 4. 模拟器
        boolean emu = AntiDebug.isEmulator();
        addStatusRow(container, getString(R.string.protect_emulator),
                emu ? "疑似模拟器" : getString(R.string.status_pass),
                emu ? R.color.accent_orange : R.color.accent_cyan);

        // 5. debuggable
        boolean debuggable = AntiDebug.isDebuggable(this);
        addStatusRow(container, getString(R.string.protect_debuggable),
                debuggable ? "是（发布前必须关掉）" : getString(R.string.status_pass),
                debuggable ? R.color.accent_red : R.color.accent_cyan);

        // 6. 篡改检测
        TamperCheck.Result tr = TamperCheck.inspect(this);
        addStatusRow(container, "防篡改",
                tr.ok ? "未发现篡改" : tr.reason,
                tr.ok ? R.color.accent_cyan : R.color.accent_red);

        addSectionTitle(container, "如何启用加固");

        addCard(container, "第 1 层 · 代码混淆（最关键）",
                "build.gradle 的 release 里已设为 minifyEnabled true。\n"
                        + "但光改这个还不够——必须用 release 方式打包：\n\n"
                        + "  AIDE 里点「运行」装上去的是 debug 版，不混淆。\n"
                        + "  要出 release 包：菜单 → Build → 生成已签名的 APK，\n"
                        + "  或用命令行 gradle assembleRelease。\n\n"
                        + "打包后回到本页，第一项应显示「已混淆」。");
        addCard(container, "第 2 层 · 字符串加密",
                "proguard-rules.pro 里已开启 -adaptclassstrings，\n" +
                        "反编译后看不到密钥、路径、提示语等明文字符串。");
        addCard(container, "第 3 层 · 签名校验",
                "先用 keytool 读出正式签名 SHA1：\n" +
                        "  keytool -printcert -jarfile your.apk\n" +
                        "填进 SignCheck.EXPECTED_SHA1，\n" +
                        "再在主 Activity 的 onCreate 里调用 SignCheck.verify()，\n" +
                        "失败就 finish() —— 二次打包的 APK 会直接打不开。");
        addCard(container, "第 4 层 · 反调试",
                "AntiDebug 类已提供检测能力，接入方式：\n" +
                        "在 onCreate 里判断 isTraced() || isDebuggerConnected()，\n" +
                        "命中则延迟退出或禁用核心功能。");
        addCard(container, "第 5 层 · Dex 加壳",
                "Dex 整体加密 + 动态加载，门槛最高。\n" +
                        "但低版本兼容性风险大，建议前四层稳定后再做。");

        addSectionTitle(container, "必须先搞清楚的一件事");
        addCard(container, "你看到的 .java 不是源码文件",
                "APK 里根本没有 .java 文件，只有 classes.dex（字节码）。\n"
                        + "反编译工具是拿 dex 逆向还原出「看起来像 Java」的伪代码。\n"
                        + "所以问题不在「源码被打包进去了」，\n"
                        + "而在于 dex 太容易被还原——解决它靠混淆，不靠加密源码文件。\n\n"
                        + "源码加密那个功能保护的是你的工程目录，\n"
                        + "给 APK 做防护是另一件事，两者不能互相替代。");

        addSectionTitle(container, "必须明白的事");
        addCard(container, "",
                "安卓端不存在无法破解的加固。加固的目标是「提高门槛」，\n" +
                        "让破解成本高于收益，从而挡住绝大多数脚本小子，\n" +
                        "而不是追求绝对安全。把前四层做扎实，性价比最高。");
    }

}
