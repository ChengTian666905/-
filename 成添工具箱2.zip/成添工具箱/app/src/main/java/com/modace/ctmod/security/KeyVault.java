package com.modace.ctmod.security;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;

import java.security.MessageDigest;

/**
 * 密钥保险库 —— 全应用唯一的密钥来源。
 *
 * 【核心原则：代码里不存在任何完整密钥】
 *   硬编码密钥是加固里最常见也最致命的错误。
 *   不管你把它藏得多深、拆得多碎、名字起得多无关，
 *   只要它以完整形式出现在 dex 里，反编译者花十分钟就能搜出来。
 *   真正有效的做法是：代码里只放「配料」，密钥在运行时现算。
 *
 * 【配方】
 *   密钥 = SHA256( 分片种子 ‖ 包名 ‖ APK签名 )
 *
 *   三段各自的作用：
 *     · 分片种子  ：拆成 4 片，分藏在不同方法里，且每片被 XOR 打乱。
 *                   静态看是 4 段无意义字节，组合起来才是种子。
 *     · 包名      ：换包名就换密钥。
 *     · APK 签名  ：【关键】重新签名后签名必然变化，密钥随之变化，
 *                   于是所有加密字符串都解不开 —— 二次打包者拿到的
 *                   不是一个能跑的盗版，而是一个直接崩溃的壳。
 *                   签名校验和密钥派生被绑成了同一件事，没法单独绕过。
 *
 * 【注意】
 *   这意味着：换了签名密钥（比如从 debug 签名换成正式签名），
 *   加密素材必须重新生成，否则会解不开。打包脚本要配套处理。
 */
public final class KeyVault {

    private KeyVault() {
    }

    /**
     * 取得主密钥（32 字节）。
     * 每次调用都会重新计算，不做静态缓存——缓存会让它长时间
     * 停留在内存里，被 dump 出来的风险更高。
     */
    public static byte[] master(Context ctx) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(seed());
            md.update(pkgBytes(ctx));
            md.update(sigBytes(ctx));
            return md.digest();
        } catch (Exception e) {
            // 拿不到就退化成只有种子，保证不会崩，但强度下降
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                md.update(seed());
                return md.digest();
            } catch (Exception e2) {
                return seed();
            }
        }
    }

    // ==================== 配料一：分片种子 ====================

    /** 把 4 个分片拼起来并还原 XOR */
    private static byte[] seed() {
        byte[] a = unmask(p0(), 0x5A);
        byte[] b = unmask(p1(), 0x3C);
        byte[] c = unmask(p2(), 0x7E);
        byte[] d = unmask(p3(), 0x19);
        byte[] out = new byte[a.length + b.length + c.length + d.length];
        System.arraycopy(a, 0, out, 0, a.length);
        System.arraycopy(b, 0, out, a.length, b.length);
        System.arraycopy(c, 0, out, a.length + b.length, c.length);
        System.arraycopy(d, 0, out, a.length + b.length + c.length, d.length);
        return out;
    }

    private static byte[] unmask(byte[] in, int k) {
        byte[] out = new byte[in.length];
        for (int i = 0; i < in.length; i++) {
            out[i] = (byte) (in[i] ^ (k + i));
        }
        return out;
    }

    // 四个分片：单独看只是杂乱字节数组，拼起来才是种子
    // 这些值由打包脚本随机生成，每次构建都不同
    private static byte[] p0() {
        return new byte[]{11, -34, 92, 7, -88, 45, 120, -3, 66, 21, -71, 39};
    }

    private static byte[] p1() {
        return new byte[]{-52, 83, 14, -97, 30, 108, -25, 61, 4, -116, 77, 9};
    }

    private static byte[] p2() {
        return new byte[]{95, -8, 47, 113, -60, 26, -42, 88, 3, -19, 70, 52};
    }

    private static byte[] p3() {
        return new byte[]{-14, 67, -103, 35, 91, -6, 118, 24, -49, 82, 5, -75};
    }

    // ==================== 配料二：包名 ====================

    private static byte[] pkgBytes(Context ctx) {
        try {
            String p = ctx.getPackageName();
            return p.getBytes("UTF-8");
        } catch (Exception e) {
            return new byte[]{0};
        }
    }

    // ==================== 配料三：APK 签名 ====================

    private static byte[] sigBytes(Context ctx) {
        try {
            PackageInfo pi = ctx.getPackageManager().getPackageInfo(
                    ctx.getPackageName(), PackageManager.GET_SIGNATURES);
            if (pi == null || pi.signatures == null || pi.signatures.length == 0) {
                return new byte[]{0};
            }
            Signature sg = pi.signatures[0];
            if (sg == null) {
                return new byte[]{0};
            }
            byte[] raw = sg.toByteArray();
            // 再哈希一次，避免把整段签名直接喂进摘要
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return md.digest(raw);
        } catch (Exception e) {
            return new byte[]{0};
        }
    }
}
