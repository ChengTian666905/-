package com.modace.ctmod.lua;

import java.util.ArrayList;
import java.util.List;

/**
 * Lua 语法检查器（静态扫描，不执行代码）。
 *
 * 能查出来的：
 *   1. 小括号 / 方括号 不配对
 *   2. 单引号 / 双引号 / 长字符串 [[ ]] 未闭合
 *   3. 块结构不配对：function / if / for / while / do 缺少 end，repeat 缺少 until
 *   4. then 缺失（if ... 后面必须有 then）
 *   5. 条件里误用赋值号「=」（应为比较号「==」）
 *   6. 长注释 --[[ ]] 未闭合
 *
 * 【定位说明】这是启发式检查，不是完整 Lua 解析器。
 *   目标是覆盖绝大多数手滑写错的情况，不追求 100% 准确，
 *   因此宁可少报也不乱报——不确定的一律放过。
 */
public final class LuaChecker {

    /** 一条检查结果 */
    public static class Issue {
        public final int line;
        public final String message;
        /** 出错行的代码原文（用于顶部提示显示，可能很长，展示时需截断） */
        public final String lineText;

        public Issue(int line, String message, String lineText) {
            this.line = line;
            this.message = message;
            this.lineText = lineText;
        }

        @Override
        public String toString() {
            return "第 " + line + " 行：" + message;
        }
    }

    // ============ 行定位：供波浪线与顶部提示使用 ============

    /** 计算每行起始字符偏移，下标 0 对应第 1 行 */
    public static int[] lineStarts(String src) {
        int n = 1;
        for (int i = 0; i < src.length(); i++) {
            if (src.charAt(i) == '\n') {
                n++;
            }
        }
        int[] starts = new int[n];
        starts[0] = 0;
        int idx = 1;
        for (int i = 0; i < src.length(); i++) {
            if (src.charAt(i) == '\n' && idx < n) {
                starts[idx] = i + 1;
                idx++;
            }
        }
        return starts;
    }

    /** 取指定行（从 1 开始）的字符范围 [start, end)，不含换行符 */
    public static int[] lineRange(String src, int line) {
        int[] starts = lineStarts(src);
        if (line < 1 || line > starts.length) {
            return new int[]{0, 0};
        }
        int s = starts[line - 1];
        int e = (line < starts.length) ? starts[line] - 1 : src.length();
        if (e < s) {
            e = s;
        }
        return new int[]{s, e};
    }

    /** 取指定行的代码原文 */
    public static String lineText(String src, int line) {
        int[] r = lineRange(src, line);
        if (r[1] <= r[0]) {
            return "";
        }
        return src.substring(r[0], r[1]);
    }

    /** 需要配对 end 的关键字 */
    private static final String[] BLOCK_OPEN = {
            "function", "if", "for", "while", "do"
    };

    private LuaChecker() {
    }

    /**
     * 检查源码，返回问题列表（按行号升序）。
     * 无问题时返回空列表。
     */
    public static List<Issue> check(String source) {
        List<Issue> issues = new ArrayList<Issue>();
        if (source == null || source.length() == 0) {
            return issues;
        }

        int line = 1;
        int i = 0;
        int len = source.length();

        // 括号栈：记录字符与所在行
        List<Integer> parenLines = new ArrayList<Integer>();
        List<Integer> bracketLines = new ArrayList<Integer>();
        // 块栈：记录关键字与所在行
        List<String> blockStack = new ArrayList<String>();
        List<Integer> blockLines = new ArrayList<Integer>();
        // 等待 then 的 if/elseif 行号
        List<Integer> waitThen = new ArrayList<Integer>();

        /*
         * for / while 后面必须跟 do，这个 do 属于同一条语句，
         * 不能再单独开一个块，否则 for...do...end 会变成两个块，
         * 一个 end 关不掉，必然误报「缺少 end」。
         */
        boolean expectDo = false;

        while (i < len) {
            char c = source.charAt(i);

            if (c == '\n') {
                line++;
                i++;
                continue;
            }

            // ---- 换行符之外的空白 ----
            if (c == ' ' || c == '\t' || c == '\r') {
                i++;
                continue;
            }

            // ---- 注释 ----
            if (c == '-' && i + 1 < len && source.charAt(i + 1) == '-') {
                // 长注释 --[[ ]]
                if (i + 3 < len && source.charAt(i + 2) == '[' && source.charAt(i + 3) == '[') {
                    int end = source.indexOf("]]", i + 4);
                    if (end < 0) {
                        issues.add(new Issue(line, "长注释 --[[ 未闭合，缺少 ]]", lineText(source, line)));
                        return issues;
                    }
                    line += countLines(source, i, end);
                    i = end + 2;
                    continue;
                }
                // 单行注释，跳到行尾
                int nl = source.indexOf('\n', i);
                if (nl < 0) {
                    break;
                }
                i = nl + 1;
                line++;
                continue;
            }

            // ---- 长字符串 [[ ]] ----
            if (c == '[' && i + 1 < len && source.charAt(i + 1) == '[') {
                int end = source.indexOf("]]", i + 2);
                if (end < 0) {
                    issues.add(new Issue(line, "长字符串 [[ 未闭合，缺少 ]]", lineText(source, line)));
                    return issues;
                }
                line += countLines(source, i, end);
                i = end + 2;
                continue;
            }

            // ---- 普通字符串 ----
            if (c == '"' || c == '\'') {
                int end = findStringEnd(source, i);
                if (end < 0) {
                    issues.add(new Issue(line, "字符串未闭合，缺少配对的 " + c, lineText(source, line)));
                    return issues;
                }
                line += countLines(source, i, end);
                i = end + 1;
                continue;
            }

            // ---- 括号 ----
            if (c == '(') {
                parenLines.add(line);
                i++;
                continue;
            }
            if (c == ')') {
                if (parenLines.isEmpty()) {
                    issues.add(new Issue(line, "多出一个右括号 )", lineText(source, line)));
                } else {
                    parenLines.remove(parenLines.size() - 1);
                }
                i++;
                continue;
            }
            if (c == '[') {
                bracketLines.add(line);
                i++;
                continue;
            }
            if (c == ']') {
                if (bracketLines.isEmpty()) {
                    issues.add(new Issue(line, "多出一个右方括号 ]", lineText(source, line)));
                } else {
                    bracketLines.remove(bracketLines.size() - 1);
                }
                i++;
                continue;
            }

            // ---- 标识符 / 关键字 ----
            if (isIdentStart(c)) {
                int start = i;
                while (i < len && isIdentChar(source.charAt(i))) {
                    i++;
                }
                String word = source.substring(start, i);

                if (word.equals("end")) {
                    /*
                     * 块都结束了却还没等到 then，说明这个 if/while 从头到尾没写 then。
                     * 例如：if a==1 \n print(1) \n end
                     * 必须在关块之前检查，否则块弹出后就查不出来了。
                     */
                    if (!waitThen.isEmpty()) {
                        issues.add(new Issue(waitThen.get(0), "该行之后缺少 then",
                            lineText(source, waitThen.get(0))));
                        waitThen.clear();
                    }
                    if (blockStack.isEmpty()) {
                        issues.add(new Issue(line, "多出一个 end，没有对应的块开始", lineText(source, line)));
                    } else {
                        blockStack.remove(blockStack.size() - 1);
                        blockLines.remove(blockLines.size() - 1);
                    }
                    expectDo = false;
                    continue;
                }

                if (word.equals("then")) {
                    waitThen.clear();
                    expectDo = false;
                    continue;
                }

                if (word.equals("until")) {
                    if (blockStack.isEmpty() || !blockStack.get(blockStack.size() - 1).equals("repeat")) {
                        // until 没有对应 repeat：只在确实没有 repeat 时报错
                        boolean hasRepeat = false;
                        for (int k = blockStack.size() - 1; k >= 0; k--) {
                            if (blockStack.get(k).equals("repeat")) {
                                hasRepeat = true;
                                break;
                            }
                        }
                        if (!hasRepeat) {
                            issues.add(new Issue(line, "until 没有对应的 repeat", lineText(source, line)));
                        }
                    } else {
                        blockStack.remove(blockStack.size() - 1);
                        blockLines.remove(blockLines.size() - 1);
                    }
                    expectDo = false;
                    continue;
                }

                if (word.equals("elseif")) {
                    // elseif 后面同样需要 then
                    waitThen.clear();
                    waitThen.add(line);
                    expectDo = false;
                    continue;
                }

                if (word.equals("else")) {
                    // else 属于 if 块，不改变块层级
                    expectDo = false;
                    continue;
                }

                if (word.equals("repeat")) {
                    blockStack.add("repeat");
                    blockLines.add(line);
                    expectDo = false;
                    continue;
                }

                boolean matched = false;
                for (int k = 0; k < BLOCK_OPEN.length; k++) {
                    if (BLOCK_OPEN[k].equals(word)) {
                        if (word.equals("do") && expectDo) {
                            // 这个 do 属于上一条 for / while，不再开块
                            expectDo = false;
                            matched = true;
                            break;
                        }
                        blockStack.add(word);
                        blockLines.add(line);
                        /*
                         * 只有 if / elseif 后面跟 then，
                         * while 后面跟的是 do，不能把 while 也算进等 then 的队列，
                         * 否则 `while true do ... end` 会被误报「缺少 then」。
                         */
                        if (word.equals("if")) {
                            waitThen.clear();
                            waitThen.add(line);
                        }
                        if (word.equals("for") || word.equals("while")) {
                            expectDo = true;
                        } else {
                            expectDo = false;
                        }
                        matched = true;
                        break;
                    }
                }
                if (matched) {
                    continue;
                }
                continue;
            }

            // ---- 等号：检查条件里误用赋值 ----
            if (c == '=') {
                char prev = (i > 0) ? source.charAt(i - 1) : 0;
                char next = (i + 1 < len) ? source.charAt(i + 1) : 0;
                // == ~= <= >= 都是比较运算符，不能当成赋值号
                // 注意：== 必须一次吃掉两个字符，否则第二个 = 会被误判
                boolean isCompare = (next == '=') || prev == '~' || prev == '<'
                        || prev == '>' || prev == '=';
                if (isCompare) {
                    i += (next == '=') ? 2 : 1;
                    continue;
                }
                if (!waitThen.isEmpty()) {
                    // if/while/elseif 之后到 then 之前，出现单个 = 极可能是把 == 写成 =
                    issues.add(new Issue(line, "条件判断中疑似误用赋值号 = ，比较应用 ==", lineText(source, line)));
                    waitThen.clear();
                }
                i++;
                continue;
            }

            i++;
        }

        // ---- 收尾统计 ----
        for (int k = 0; k < parenLines.size(); k++) {
            issues.add(new Issue(parenLines.get(k), "左括号 ( 未闭合，缺少 )",
                    lineText(source, parenLines.get(k))));
        }
        for (int k = 0; k < bracketLines.size(); k++) {
            issues.add(new Issue(bracketLines.get(k), "左方括号 [ 未闭合，缺少 ]",
                    lineText(source, bracketLines.get(k))));
        }
        for (int k = 0; k < blockLines.size(); k++) {
            String kw = blockStack.get(k);
            if (kw.equals("repeat")) {
                issues.add(new Issue(blockLines.get(k), "repeat 缺少 until",
                        lineText(source, blockLines.get(k))));
            } else if (kw.equals("if")) {
                issues.add(new Issue(blockLines.get(k), "if 缺少 end（也可能缺 then）",
                        lineText(source, blockLines.get(k))));
            } else if (kw.equals("function")) {
                issues.add(new Issue(blockLines.get(k), "function 缺少 end",
                        lineText(source, blockLines.get(k))));
            } else if (kw.equals("for")) {
                issues.add(new Issue(blockLines.get(k), "for 缺少 end",
                        lineText(source, blockLines.get(k))));
            } else if (kw.equals("while")) {
                issues.add(new Issue(blockLines.get(k), "while 缺少 end",
                        lineText(source, blockLines.get(k))));
            } else {
                issues.add(new Issue(blockLines.get(k), "do 缺少 end",
                        lineText(source, blockLines.get(k))));
            }
        }

        // then 缺失提示（if/while/elseif 后面直到块结束都没有 then）
        if (!waitThen.isEmpty() && !blockStack.isEmpty()) {
            issues.add(new Issue(waitThen.get(0), "该行之后缺少 then",
                            lineText(source, waitThen.get(0))));
        }

        return issues;
    }

    /** 按行号排序后拼成可读文本 */
    public static String format(List<Issue> issues) {
        if (issues == null || issues.isEmpty()) {
            return null;
        }
        List<Issue> sorted = new ArrayList<Issue>(issues);
        java.util.Collections.sort(sorted, new java.util.Comparator<Issue>() {
            public int compare(Issue a, Issue b) {
                return a.line - b.line;
            }
        });
        StringBuilder sb = new StringBuilder();
        sb.append("发现 ").append(sorted.size()).append(" 处问题：\n\n");
        for (int i = 0; i < sorted.size(); i++) {
            sb.append(sorted.get(i).toString());
            if (i != sorted.size() - 1) {
                sb.append("\n");
            }
        }
        return sb.toString();
    }

    // ============ 词法辅助 ============

    /** 找到字符串结束引号（处理转义），未找到返回 -1 */
    private static int findStringEnd(String src, int start) {
        char quote = src.charAt(start);
        int i = start + 1;
        while (i < src.length()) {
            char c = src.charAt(i);
            if (c == '\\') {
                i += 2;
                continue;
            }
            if (c == '\n') {
                // Lua 中普通字符串不能跨行，遇到换行说明没闭合
                return -1;
            }
            if (c == quote) {
                return i;
            }
            i++;
        }
        return -1;
    }

    private static int countLines(String src, int from, int to) {
        int n = 0;
        for (int i = from; i < to && i < src.length(); i++) {
            if (src.charAt(i) == '\n') {
                n++;
            }
        }
        return n;
    }

    private static boolean isIdentStart(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
    }

    private static boolean isIdentChar(char c) {
        return isIdentStart(c) || (c >= '0' && c <= '9');
    }
}
