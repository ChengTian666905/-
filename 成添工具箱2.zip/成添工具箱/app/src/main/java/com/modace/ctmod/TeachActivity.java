package com.modace.ctmod;

import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * 教程页 —— 从零开始的 Lua / GG 脚本入门。
 *
 * 【怎么自己改】
 *   正文段落：addCard(container, "标题", "内容");
 *   代码区块：addCode(container, "代码内容");
 *   章节标题：addSectionTitle(container, "章节名");
 *
 *   代码区块用等宽字体 + 深色底，比普通卡片更适合贴代码。
 *   字符串里用 \n 换行，加一条就是一行代码，不影响其他功能。
 */
public class TeachActivity extends BaseModuleActivity {

    @Override
    protected String getTitleText() {
        return getString(R.string.tool_teach);
    }

    @Override
    protected void buildContent(LinearLayout container) {
        if (container == null) {
            return;
        }
        /*
         * 内容构建整体兜底：万一资源缺失或 API 不兼容，只提示不崩溃。
         * 正常情况下不会进 catch。
         */
        try {
            buildContentSafe(container);
        } catch (Throwable t) {
            addCard(container, "页面构建出错", String.valueOf(t));
        }
    }

    /** 真正的正文构建，被 buildContent 包在 try 里调用 */
    private void buildContentSafe(LinearLayout container) {

        addCard(container, "", getString(R.string.teach_intro));

        // ============================================================
        // 第一章 先跑起来
        // ============================================================
        addSectionTitle(container, "第一章 · 先跑起来");

        addCard(container, "1.1 第一个脚本",
                "新建 hello.lua，只写一行：");
        addCode(container, "print(\"Hello, Lua!\")");
        addCard(container, "",
                "运行后控制台会输出 Hello, Lua!。\n"
                        + "print 是最常用的调试手段，任何变量都能直接打印。\n"
                        + "脚本出错时，第一件事就是在可疑位置插 print。");

        addCard(container, "1.2 注释",
                "两个减号是单行注释，--[[ ]] 是多行注释：");
        addCode(container,
                "-- 这是单行注释\n"
                        + "\n"
                        + "--[[\n"
                        + "  这是多行注释\n"
                        + "  调试时常用它临时整段屏蔽\n"
                        + "]]");

        addCard(container, "1.3 变量必须先 local",
                "Lua 里不加 local 就是全局变量，会污染环境、拖慢执行：");
        addCode(container,
                "local name = \"成添\"   -- 字符串\n"
                        + "local age  = 18        -- 数字\n"
                        + "local ok   = true      -- 布尔\n"
                        + "local t    = {}        -- 表（数组 / 字典通用）\n"
                        + "local n    = nil       -- 空值");

        // ============================================================
        // 第二章 核心语法
        // ============================================================
        addSectionTitle(container, "第二章 · 核心语法");

        addCard(container, "2.1 条件判断",
                "比较用 ==，不是 = 。把 == 写成 = 是最高频的新手错误：");
        addCode(container,
                "if score >= 90 then\n"
                        + "    print(\"优秀\")\n"
                        + "elseif score >= 60 then\n"
                        + "    print(\"及格\")\n"
                        + "else\n"
                        + "    print(\"不及格\")\n"
                        + "end");

        addCard(container, "2.2 循环",
                "数值 for 的区间是闭区间（包含两端），这点和其他语言不同：");
        addCode(container,
                "-- 数值循环：1 到 10，含 10\n"
                        + "for i = 1, 10 do\n"
                        + "    print(i)\n"
                        + "end\n"
                        + "\n"
                        + "-- 带步长：10 递减到 1\n"
                        + "for i = 10, 1, -1 do\n"
                        + "    print(i)\n"
                        + "end\n"
                        + "\n"
                        + "-- 遍历表\n"
                        + "for k, v in pairs(t) do\n"
                        + "    print(k, v)\n"
                        + "end");

        addCard(container, "2.3 函数",
                "Lua 支持多返回值，这是它很方便的特性：");
        addCode(container,
                "local function add(a, b)\n"
                        + "    return a + b\n"
                        + "end\n"
                        + "\n"
                        + "print(add(1, 2))        -- 3\n"
                        + "\n"
                        + "-- 多返回值\n"
                        + "local function swap(a, b)\n"
                        + "    return b, a\n"
                        + "end\n"
                        + "local x, y = swap(1, 2) -- x=2, y=1");

        addCard(container, "2.4 表（数组 + 字典）",
                "表是 Lua 唯一的数据结构，数组和字典都用它：");
        addCode(container,
                "-- 当数组用，下标从 1 开始\n"
                        + "local list = {\"a\", \"b\", \"c\"}\n"
                        + "print(list[1])          -- a\n"
                        + "print(#list)            -- 3，井号取长度\n"
                        + "\n"
                        + "-- 当字典用\n"
                        + "local cfg = {hp = 100, mp = 50}\n"
                        + "print(cfg.hp)           -- 100\n"
                        + "print(cfg[\"mp\"])      -- 50\n"
                        + "\n"
                        + "-- 插入与遍历\n"
                        + "table.insert(list, \"d\")\n"
                        + "for i, v in ipairs(list) do\n"
                        + "    print(i, v)\n"
                        + "end");

        // ============================================================
        // 第三章 常用标准库
        // ============================================================
        addSectionTitle(container, "第三章 · 常用标准库");

        addCard(container, "3.1 字符串 string",
                "截取、查找、替换、格式化，日常用得最多：");
        addCode(container,
                "local s = \"Hello Lua\"\n"
                        + "\n"
                        + "string.sub(s, 1, 5)         -- Hello   截取\n"
                        + "string.len(s)               -- 9       长度\n"
                        + "string.upper(s)             -- 全转大写\n"
                        + "string.lower(s)             -- 全转小写\n"
                        + "string.find(s, \"Lua\")     -- 7  12   返回起止位置\n"
                        + "string.gsub(s, \"Lua\", \"World\")  -- 替换\n"
                        + "string.format(\"第%d名\", 1)  -- 第1名   格式化\n"
                        + "\n"
                        + "-- 拼接用两个点号，不要加号\n"
                        + "local all = \"a\" .. \"b\"    -- ab\n"
                        + "local n   = \"值=\" .. 100    -- 数字会自动转");

        addCard(container, "3.2 表操作 table",
                "插入、删除、拼接、排序：");
        addCode(container,
                "local t = {3, 1, 2}\n"
                        + "\n"
                        + "table.insert(t, 4)      -- 末尾插入\n"
                        + "table.remove(t, 1)      -- 按下标删除\n"
                        + "table.sort(t)           -- 升序排序\n"
                        + "table.concat(t, \",\")  -- 拼成字符串\n"
                        + "table.sort(t, function(a, b) return a > b end)  -- 降序");

        addCard(container, "3.3 数学 math 与 系统 os",
                "取整、随机、时间，做延时和随机化时用：");
        addCode(container,
                "math.floor(3.7)         -- 3    向下取整\n"
                        + "math.ceil(3.2)          -- 4    向上取整\n"
                        + "math.max(1, 5, 3)       -- 5\n"
                        + "math.random(1, 100)     -- 1~100 随机整数\n"
                        + "\n"
                        + "os.time()               -- 当前时间戳（秒）\n"
                        + "os.date(\"%Y-%m-%d\")   -- 格式化日期\n"
                        + "\n"
                        + "-- 随机种子，不设的话每次随机序列都一样\n"
                        + "math.randomseed(os.time())");

        addCard(container, "3.4 错误处理",
                "不确定会不会出错的调用，用 pcall 包起来，避免整个脚本崩掉：");
        addCode(container,
                "local ok, err = pcall(function()\n"
                        + "    -- 可能出错的代码\n"
                        + "    error(\"故意抛个错\")\n"
                        + "end)\n"
                        + "\n"
                        + "if ok then\n"
                        + "    print(\"执行成功\")\n"
                        + "else\n"
                        + "    print(\"出错了：\" .. tostring(err))\n"
                        + "end");

        // ============================================================
        // 第四章 GG 脚本实战
        // ============================================================
        addSectionTitle(container, "第四章 · GG 脚本实战");

        addCard(container, "4.1 菜单框架",
                "点「编」→ 右上角「+」→ 基础模板，直接就有这套骨架：");
        addCode(container,
                "function Main()\n"
                        + "    local choice = gg.choice({\n"
                        + "        \"功能一\",\n"
                        + "        \"功能二\",\n"
                        + "        \"退出脚本\"\n"
                        + "    }, nil, \"这里填提示文字\")\n"
                        + "\n"
                        + "    if choice == 1 then Func1() end\n"
                        + "    if choice == 2 then Func2() end\n"
                        + "    if choice == 3 then Exit()   end\n"
                        + "end\n"
                        + "\n"
                        + "function Func1()\n"
                        + "    gg.toast(\"功能一已开启\")\n"
                        + "end\n"
                        + "\n"
                        + "function Func2()\n"
                        + "    gg.toast(\"功能二已开启\")\n"
                        + "end\n"
                        + "\n"
                        + "function Exit()\n"
                        + "    print(\"已退出\")\n"
                        + "    os.exit()\n"
                        + "end\n"
                        + "\n"
                        + "while true do\n"
                        + "    if gg.isVisible(true) then\n"
                        + "        running = true\n"
                        + "        gg.setVisible(false)\n"
                        + "    end\n"
                        + "    gg.clearResults()\n"
                        + "    if running then Main() end\n"
                        + "end");

        addCard(container, "4.2 搜索数值",
                "先搜后改是 GG 脚本的标准流程：");
        addCode(container,
                "-- 搜索金币 = 999\n"
                        + "gg.clearResults()\n"
                        + "gg.searchNumber(\"999\", gg.TYPE_DWORD)\n"
                        + "local count = gg.getResultCount()\n"
                        + "gg.toast(\"搜到 \" .. count .. \" 个结果\")\n"
                        + "\n"
                        + "-- 结果太多就 refine 缩小范围\n"
                        + "if count > 100 then\n"
                        + "    gg.refineNumber(\"999\", gg.TYPE_DWORD)\n"
                        + "    count = gg.getResultCount()\n"
                        + "end\n"
                        + "\n"
                        + "-- 常用类型\n"
                        + "-- gg.TYPE_DWORD  4字节整数\n"
                        + "-- gg.TYPE_FLOAT  单精度浮点\n"
                        + "-- gg.TYPE_DOUBLE 双精度浮点");

        addCard(container, "4.3 修改结果",
                "拿到结果列表后批量改值：");
        addCode(container,
                "local results = gg.getResults(100)\n"
                        + "\n"
                        + "for i, v in ipairs(results) do\n"
                        + "    v.value = 99999\n"
                        + "    v.freeze = true      -- 顺便冻结\n"
                        + "end\n"
                        + "\n"
                        + "gg.setValues(results)\n"
                        + "gg.addListItems(results)\n"
                        + "gg.toast(\"已修改 \" .. #results .. \" 项\")");

        addCard(container, "4.4 提示与输入",
                "和用户交互的两个基本手段：");
        addCode(container,
                "-- 短暂提示（不阻塞）\n"
                        + "gg.toast(\"操作成功\")\n"
                        + "\n"
                        + "-- 弹出输入框\n"
                        + "local input = gg.prompt({\"请输入数值\"}, {\"100\"}, {\"number\"})\n"
                        + "if input ~= nil then\n"
                        + "    gg.toast(\"你输入了 \" .. input[1])\n"
                        + "end\n"
                        + "\n"
                        + "-- 确认框\n"
                        + "if gg.alert(\"确定继续？\", \"是\", \"否\") == 1 then\n"
                        + "    gg.toast(\"继续执行\")\n"
                        + "end");

        addCard(container, "4.5 配置存取",
                "把用户设置写进文件，下次启动读回来：");
        addCode(container,
                "local PATH = gg.getTargetPackage() .. \"_cfg.txt\"\n"
                        + "\n"
                        + "function saveCfg(hp, mp)\n"
                        + "    local f = io.open(PATH, \"w\")\n"
                        + "    if f == nil then return false end\n"
                        + "    f:write(hp .. \"\\n\" .. mp)\n"
                        + "    f:close()\n"
                        + "    return true\n"
                        + "end\n"
                        + "\n"
                        + "function loadCfg()\n"
                        + "    local f = io.open(PATH, \"r\")\n"
                        + "    if f == nil then return 100, 50 end   -- 默认值\n"
                        + "    local hp = f:read(\"*n\")\n"
                        + "    local mp = f:read(\"*n\")\n"
                        + "    f:close()\n"
                        + "    return hp, mp\n"
                        + "end");

        // ============================================================
        // 第五章 本工具箱怎么用
        // ============================================================
        addSectionTitle(container, "第五章 · 本工具箱怎么用");

        addCard(container, "编 · 编写 Lua",
                "主界面点「编」进入：\n"
                        + "  · 左侧自动显示行号\n"
                        + "  · 右上角「+」插入六套模板\n"
                        + "  · 写错会在顶部提示，并在代码下画红色波浪线\n\n"
                        + "保存路径：/sdcard/CTScript/script.lua");

        addCard(container, "Lua 加密",
                "首页「Lua 加密」卡片：\n"
                        + "  · 轻量 RC4 —— 纯 Lua 5.1 可跑，兼容性最好\n"
                        + "  · 增强模式 —— 加置换与校验，更抗篡改\n"
                        + "  · XXTEA —— 需 Lua 5.3+ 或 bit32\n\n"
                        + "产物是自包含的 .lua，内嵌密文与解密函数，\n"
                        + "直接 require 就能运行。\n\n"
                        + "建议先点「回环验证」确认能正确还原。");

        addCard(container, "密 · 源码加密",
                "把工程里的 .java / .xml / .lua 等批量加密成 .ctenc。\n\n"
                        + "加密后会立即解密回环校验，确认能还原才删除原文件，\n"
                        + "避免加密成功却解不开导致源码丢失。\n\n"
                        + "口令务必记牢——丢了就找不回来了。");

        addCard(container, "辅 · 辅助工具",
                "  · FPS 显示 —— 屏幕实时帧率，颜色随高低变化\n"
                        + "  · 悬浮窗 —— 胶囊形小窗，只显示 FPS\n"
                        + "  · 编写 Lua —— 直接进编辑器\n"
                        + "  · 检测病毒 —— 扫可疑文件与应用，逐条勾选处理\n"
                        + "  · 检测设备标记 —— 查是否被游戏厂商下发标记\n\n"
                        + "悬浮窗需要在系统设置里开「显示在其他应用上层」权限。");

        addCard(container, "清理加速",
                "扫描结果按占用空间从大到小排列。\n"
                        + "三个开关：ZIP 压缩包 / 大文件 / APK 安装包，\n"
                        + "前两类默认不勾，确认无用后再手动开启更安全。");

        // ============================================================
        // 第六章 排错
        // ============================================================
        addSectionTitle(container, "第六章 · 常见报错对照");

        addCard(container, "attempt to index nil",
                "对一个空值取下标或调用方法。\n\n"
                        + "典型原因：gg.getResults() 没搜到东西就直接用，\n"
                        + "或者变量名拼错。\n\n"
                        + "修：用之前先判空 —— if t ~= nil then ... end");

        addCard(container, "')' expected near 'xxx'",
                "括号、then、end 之类的关键字缺了。\n\n"
                        + "if / for / while / function 都必须有对应的 end。\n"
                        + "把光标停在报错位置往前找，多半是某个 end 漏了。\n\n"
                        + "用本应用的「编」写，顶部提示会直接告诉你缺什么。");

        addCard(container, "unfinished string near '\"'",
                "字符串没闭合，引号少了一个。\n\n"
                        + "检查成对出现，注意转义：\n"
                        + "字符串里要表示引号请用 \\\" 。");

        addCard(container, "attempt to perform arithmetic on a string",
                "拿字符串去做算术运算。\n\n"
                        + "从输入框、文件读进来的都是字符串，\n"
                        + "要先 tonumber() 转成数字。");

        addCard(container, "loop initial value must be a number",
                "for 循环的初值不是数字。\n\n"
                        + "for i = 1, n do 里的 n 如果是字符串或 nil 就报这个。\n"
                        + "修：for i = 1, tonumber(n) do");

        addCard(container, "脚本没反应",
                "优先查这三项：\n\n"
                        + "  1. 主循环有没有写 while true do ... end\n"
                        + "  2. gg.isVisible(true) 有没有配合 setVisible(false)\n"
                        + "  3. 函数定义了但没在菜单里调用\n\n"
                        + "在这三个位置各插一句 print，看控制台有没有输出。");

        // ============================================================
        // 第七章 FAQ
        // ============================================================
        addSectionTitle(container, "第七章 · 常见问题");

        addCard(container, "加密后的脚本别人能破解吗？",
                "解释型语言运行时必须还原明文，所以这是混淆级保护，\n"
                        + "不是绝对安全。\n\n"
                        + "能挡住直接阅读和随手篡改，挡不住专业逆向。\n"
                        + "别用它保护高价值密钥。");

        addCard(container, "我要学多久能写脚本？",
                "如果只要改数值类的脚本，照着第四章的模板改两处就够了，\n"
                        + "半小时能出第一个能跑的东西。\n\n"
                        + "想写复杂逻辑再回头看第二、三章的语法与标准库。");

        addCard(container, "为什么清理列表是空的？",
                "安卓 5.0 起第三方应用读不到其他应用的私有数据，\n"
                        + "这是系统限制，任何清理类 App 都一样。\n\n"
                        + "本工具只扫描公共存储里的真实文件，\n"
                        + "宁可显示真实的空列表，也不伪造数据。");

        addCard(container, "怎么自己改本页内容",
                "打开 TeachActivity.java，找到 buildContent()：\n\n"
                        + "  addSectionTitle(container, \"章节名\");\n"
                        + "  addCard(container, \"标题\", \"正文\");\n"
                        + "  addCode(container, \"代码\");\n\n"
                        + "字符串里用 \\n 换行，加一条就是一行代码。\n"
                        + "代码区块用 addCode，会用等宽字体显示，更适合贴代码。");
    }

    /**
     * 代码区块：等宽字体 + 深色底 + 缩进，比普通卡片更适合贴代码。
     * 可点击复制，方便直接粘贴到编辑器里用。
     */
    private void addCode(LinearLayout container, final String code) {
        TextView tv = new TextView(this);
        tv.setText(code);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(11.5f);
        tv.setTextColor(getResources().getColor(R.color.text_primary));
        tv.setBackgroundResource(R.drawable.bg_card);
        tv.setPadding(dp(14), dp(12), dp(14), dp(12));
        tv.setLineSpacing(dp(2), 1f);
        tv.setGravity(Gravity.LEFT);
        tv.setTextIsSelectable(true);

        tv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                copyToClipboard(code);
            }
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(18), 0, dp(18), dp(10));
        container.addView(tv, lp);
    }

    /** 点代码区块复制到剪贴板（兼容低版本） */
    @SuppressWarnings("deprecation")
    private void copyToClipboard(String text) {
        try {
            int sdk = android.os.Build.VERSION.SDK_INT;
            if (sdk >= 11) {
                android.content.ClipboardManager cm =
                        (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setText(text);
            } else {
                android.text.ClipboardManager cm =
                        (android.text.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setText(text);
            }
            toast(getString(R.string.action_copy) + " OK");
        } catch (Exception e) {
            toast("复制失败");
        }
    }
}
