package com.modace.ctmod.security;

import android.content.Context;

/**
 * 加固统一入口。
 *
 * 在首个 Activity 的 onCreate 里、setContentView 之前调用一次：
 *     Guard.boot(this);
 *
 * 做三件事：
 *   1. 初始化字符串解密（拿到 Context 才能算密钥）
 *   2. 篡改检测，命中直接终止
 *   3. 反调试检测（可选，默认只记录不动作，避免误伤）
 *
 * 【为什么必须在 setContentView 之前】
 *   如果先渲染了界面再崩溃，用户会看到界面闪一下然后消失，
 *   观感很差且容易被定位到崩溃点。在最早期终止则干净得多。
 */
public final class Guard {

    private static boolean booted = false;

    private Guard() {
    }

    public static synchronized void boot(Context ctx) {
        if (booted) {
            return;
        }
        booted = true;

        // 1. 字符串解密准备
        StringCrypt.init(ctx);

        // 2. 篡改检测：命中直接抛异常终止，不做任何提示
        TamperCheck.enforce(ctx);
    }

    /** 只做检查不终止，供自检页展示 */
    public static TamperCheck.Result inspect(Context ctx) {
        return TamperCheck.inspect(ctx);
    }
}
