package com.modace.ctmod.security;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.os.Debug;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 * 反调试与运行环境检测。
 *
 * 说明：这些都是「提高门槛」而非「无法突破」的手段。
 * 反调试主要用于对抗动态调试与自动化分析脚本，
 * 对静态反编译无效，需要配合混淆（见 proguard-rules.pro）使用。
 */
public final class AntiDebug {

    private AntiDebug() {
    }

    /** 是否有调试器挂载（系统 API） */
    public static boolean isDebuggerConnected() {
        try {
            return Debug.isDebuggerConnected();
        } catch (Exception e) {
            return false;
        }
    }

    /** 读取 /proc/self/status 中的 TracerPid，>0 说明被 ptrace 跟踪 */
    public static int getTracerPid() {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader("/proc/self/status"), 1024);
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("TracerPid")) {
                    String[] parts = line.split("\\s+");
                    return Integer.parseInt(parts[parts.length - 1].trim());
                }
            }
        } catch (Exception e) {
            return -1;
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (Exception ignored) {
                }
            }
        }
        return -1;
    }

    /** 是否被跟踪 */
    public static boolean isTraced() {
        return getTracerPid() > 0;
    }

    /** 是否运行在模拟器（特征匹配，不保证 100%） */
    public static boolean isEmulator() {
        if (Build.FINGERPRINT == null) {
            return false;
        }
        String fp = Build.FINGERPRINT.toLowerCase();
        String model = Build.MODEL == null ? "" : Build.MODEL.toLowerCase();
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase();
        String product = Build.PRODUCT == null ? "" : Build.PRODUCT.toLowerCase();
        String brand = Build.BRAND == null ? "" : Build.BRAND.toLowerCase();

        if (fp.contains("generic") || fp.contains("unknown") || fp.contains("emulator")) {
            return true;
        }
        if (model.contains("sdk") || model.contains("emulator") || model.contains("android sdk")) {
            return true;
        }
        if (manufacturer.contains("genymotion") || manufacturer.contains("unknown")) {
            return true;
        }
        if (product.contains("sdk") || product.contains("emulator") || product.contains("vbox")) {
            return true;
        }
        if (brand.contains("generic") && model.contains("generic")) {
            return true;
        }
        return false;
    }

    /** APK 是否被标记为可调试（android:debuggable=true） */
    public static boolean isDebuggable(Context context) {
        try {
            ApplicationInfo info = context.getApplicationInfo();
            return (info.flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        } catch (Exception e) {
            return false;
        }
    }
}
