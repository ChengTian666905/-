package com.modace.ctmod;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 带底部导航的二级页基类（版本页 / 开发信息页共用）。
 *
 * 子类实现：
 *   getTitleText()  页面标题
 *   buildContent()  往内容容器里加 View
 *   getNavTab()     底栏高亮哪一项
 */
public abstract class NavPageBaseActivity extends Activity {

    private LinearLayout contentContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 统一跟随主界面设置的横竖屏，必须早于 setContentView
        OrientUtil.apply(this);
        setContentView(R.layout.activity_nav_page);

        TextView title = (TextView) findViewById(R.id.tv_title);
        title.setText(getTitleText());

        TextView back = (TextView) findViewById(R.id.btn_back);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });

        contentContainer = (LinearLayout) findViewById(R.id.content_container);
        buildContent(contentContainer);

        NavBar.bind(this, getNavTab());
    }

    protected abstract String getTitleText();

    protected abstract void buildContent(LinearLayout container);

    protected abstract int getNavTab();

    protected void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    protected int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (value * density + 0.5f);
    }

    // ============ 通用 UI 构建辅助 ============

    /** 区块小标题 */
    protected void addSectionTitle(LinearLayout container, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(getResources().getColor(R.color.text_secondary));
        tv.setTextSize(13);
        tv.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(18), dp(18), 0, dp(10));
        container.addView(tv, lp);
    }

    /** 标题 + 正文卡片 */
    protected void addCard(LinearLayout container, String title, String body) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));

        if (title != null && title.length() > 0) {
            TextView t = new TextView(this);
            t.setText(title);
            t.setTextColor(getResources().getColor(R.color.text_primary));
            t.setTextSize(14);
            t.setTypeface(null, Typeface.BOLD);
            card.addView(t);
        }

        if (body != null && body.length() > 0) {
            TextView b = new TextView(this);
            b.setText(body);
            b.setTextColor(getResources().getColor(R.color.text_secondary));
            b.setTextSize(12);
            b.setLineSpacing(dp(2), 1f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, dp(6), 0, 0);
            card.addView(b, lp);
        }

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(18), 0, dp(18), dp(10));
        container.addView(card, lp);
    }

    /** 可点击的跳转条目：主标题 + 说明 + 右侧箭头 */
    protected void addLinkRow(LinearLayout container, String title, String desc,
                              View.OnClickListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBackgroundResource(R.drawable.bg_card);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(14), dp(16), dp(14));

        LinearLayout textBox = new LinearLayout(this);
        textBox.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams boxLp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(getResources().getColor(R.color.text_primary));
        t.setTextSize(14);
        t.setTypeface(null, Typeface.BOLD);
        textBox.addView(t);

        if (desc != null && desc.length() > 0) {
            TextView d = new TextView(this);
            d.setText(desc);
            d.setTextColor(getResources().getColor(R.color.text_hint));
            d.setTextSize(11);
            d.setLineSpacing(dp(2), 1f);
            LinearLayout.LayoutParams dLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            dLp.setMargins(0, dp(4), 0, 0);
            textBox.addView(d, dLp);
        }
        row.addView(textBox, boxLp);

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextColor(getResources().getColor(R.color.accent_cyan));
        arrow.setTextSize(20);
        arrow.setPadding(dp(8), 0, 0, 0);
        row.addView(arrow);

        row.setOnClickListener(listener);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(18), 0, dp(18), dp(10));
        container.addView(row, lp);
    }

    /** 用系统浏览器打开链接 */
    protected void openLink(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            toast(getString(R.string.link_open_failed));
        }
    }
}
