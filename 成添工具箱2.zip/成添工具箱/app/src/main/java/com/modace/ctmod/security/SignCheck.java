package com.modace.ctmod.security;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;

import com.modace.ctmod.util.FormatUtil;

import java.security.MessageDigest;

/**
 * 签名校验 —— 防二次打包的核心手段，成本最低、收益最高。
 *
 * 用法：
 *   1) 首次发布后用 getSignatureSha1() 拿到自己正式签名的 SHA1，写进 EXPECTED_SHA1；
 *   2) 在 Application 或主 Activity 的 onCreate 里调用 verify()，失败直接退出。
 *
 * 注意：调试用的 debug.keystore 与正式签名不同，
 * 硬编码期望值后，AIDE 直接运行的 debug 包会被判定为异常，
 * 这属于正常现象——把 EXPECTED_SHA1 留空即可跳过校验。
 */
public final class SignCheck {

    /** 填入你正式签名的 SHA1（大写十六进制）。留空表示不校验。 */
    public static final String EXPECTED_SHA1 = "";

    private SignCheck() {
    }

    /** 当前 APK 的签名 SHA1，失败返回 null */
    public static String getSignatureSha1(Context context) {
        byte[] raw = getSignatureBytes(context);
        if (raw == null) {
            return null;
        }
        try {
            MessageDigest md = MessageDigest.getInstance("SHA1");
            return FormatUtil.toHex(md.digest(raw)).toUpperCase();
        } catch (Exception e) {
            return null;
        }
    }

    /** 当前 APK 的签名 MD5，失败返回 null */
    public static String getSignatureMd5(Context context) {
        byte[] raw = getSignatureBytes(context);
        if (raw == null) {
            return null;
        }
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            return FormatUtil.toHex(md.digest(raw)).toUpperCase();
        } catch (Exception e) {
            return null;
        }
    }

    private static byte[] getSignatureBytes(Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo info = pm.getPackageInfo(context.getPackageName(),
                    PackageManager.GET_SIGNATURES);
            if (info == null || info.signatures == null || info.signatures.length == 0) {
                return null;
            }
            Signature sig = info.signatures[0];
            return sig.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    /** 是否已配置期望签名 */
    public static boolean hasExpected() {
        return EXPECTED_SHA1 != null && EXPECTED_SHA1.length() > 0;
    }

    /** 校验当前签名。未配置期望值时恒返回 true。 */
    public static boolean verify(Context context) {
        if (!hasExpected()) {
            return true;
        }
        String actual = getSignatureSha1(context);
        if (actual == null) {
            return false;
        }
        return EXPECTED_SHA1.equalsIgnoreCase(actual);
    }
}
