package com.modace.ctmod;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Debug;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.modace.ctmod.clean.CleanItem;
import com.modace.ctmod.clean.CleanScanner;
import com.modace.ctmod.util.DeviceInfo;
import com.modace.ctmod.util.FileUtil;
import com.modace.ctmod.util.FormatUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 清理加速模块（真实可用）。
 *
 * 两个面板：
 *   垃圾清理 —— 扫描公共存储上的安装包/临时文件/大文件/重复文件/空目录/卸载残留
 *   内存进程 —— 展示进程占用排行，可请求结束后台进程
 *
 * 诚实原则：
 *   Android 6.0+ 禁止读写其他应用私有缓存，这里只处理公共存储，
 *   不对用户宣称「一键清空所有 App 缓存」。
 *   Android 8.0+ 被杀的进程会被系统迅速拉起，因此不做虚假提速宣传。
 */
public class CleanActivity extends BaseModuleActivity implements View.OnClickListener {

    private LinearLayout panelJunk;
    private LinearLayout panelMem;
    private TextView tabJunk;
    private TextView tabMem;
    private TextView tvJunkSummary;
    private TextView tvMemSummary;
    private LinearLayout junkList;
    private LinearLayout procList;
    private LinearLayout rowSelect;
    private LinearLayout rowOptions;
    private LinearLayout rowProcEmpty;
    private TextView tvOptHint;
    private CheckBox cbZip;
    private CheckBox cbLarge;
    private CheckBox cbApk;
    private ProgressBar pbScan;

    private final List<CleanItem> items = new ArrayList<CleanItem>();
    private final Set<CleanItem> selected = new HashSet<CleanItem>();

    private final Handler handler = new Handler();
    private boolean scanning = false;

    /** 进程信息 */
    private static class ProcInfo {
        String pkg;
        String name;
        int pssKb;
    }

    private final List<ProcInfo> procs = new ArrayList<ProcInfo>();

    @Override
    protected String getTitleText() {
        return getString(R.string.title_clean);
    }

    @Override
    protected int getContentLayoutRes() {
        return R.layout.activity_clean;
    }

    @Override
    protected void buildContent(LinearLayout container) {
        // 自定义布局
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        panelJunk = (LinearLayout) findViewById(R.id.panel_junk);
        panelMem = (LinearLayout) findViewById(R.id.panel_mem);
        tabJunk = (TextView) findViewById(R.id.tab_junk);
        tabMem = (TextView) findViewById(R.id.tab_mem);
        tvJunkSummary = (TextView) findViewById(R.id.tv_junk_summary);
        tvMemSummary = (TextView) findViewById(R.id.tv_mem_summary);
        junkList = (LinearLayout) findViewById(R.id.junk_list);
        procList = (LinearLayout) findViewById(R.id.proc_list);
        rowSelect = (LinearLayout) findViewById(R.id.row_select);
        rowOptions = (LinearLayout) findViewById(R.id.row_options);
        rowProcEmpty = (LinearLayout) findViewById(R.id.row_proc_empty);
        tvOptHint = (TextView) findViewById(R.id.tv_opt_hint);
        cbZip = (CheckBox) findViewById(R.id.cb_zip);
        cbLarge = (CheckBox) findViewById(R.id.cb_large);
        cbApk = (CheckBox) findViewById(R.id.cb_apk);
        pbScan = (ProgressBar) findViewById(R.id.pb_scan);

        tabJunk.setOnClickListener(this);
        tabMem.setOnClickListener(this);
        findViewById(R.id.btn_scan).setOnClickListener(this);
        findViewById(R.id.btn_clear).setOnClickListener(this);
        findViewById(R.id.btn_select_all).setOnClickListener(this);
        findViewById(R.id.btn_invert).setOnClickListener(this);
        findViewById(R.id.btn_refresh_proc).setOnClickListener(this);
        findViewById(R.id.btn_kill_all).setOnClickListener(this);
        findViewById(R.id.btn_open_settings).setOnClickListener(this);

        // 三个类型开关：任一变化都重算默认勾选并重绘列表
        CompoundButton.OnCheckedChangeListener optListener =
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        applyTypeSelection();
                        renderJunkList();
                        updateSelectedSummary();
                    }
                };
        if (cbZip != null) {
            cbZip.setOnCheckedChangeListener(optListener);
        }
        if (cbLarge != null) {
            cbLarge.setOnCheckedChangeListener(optListener);
        }
        if (cbApk != null) {
            cbApk.setOnCheckedChangeListener(optListener);
        }

        refreshMemSummary();
    }

    /** 某个类型的开关是否打开 */
    private boolean isTypeEnabled(String type) {
        if (CleanItem.TYPE_ZIP.equals(type)) {
            return cbZip != null && cbZip.isChecked();
        }
        if (CleanItem.TYPE_LARGE.equals(type)) {
            return cbLarge != null && cbLarge.isChecked();
        }
        if (CleanItem.TYPE_APK.equals(type)) {
            return cbApk != null && cbApk.isChecked();
        }
        return true; // 临时文件、空目录、重复文件、残留、日志默认都算上
    }

    /** 按三个开关重算勾选集合（每次扫描完或开关变化都调用） */
    private void applyTypeSelection() {
        selected.clear();
        for (int i = 0; i < items.size(); i++) {
            CleanItem item = items.get(i);
            if (isTypeEnabled(item.type)) {
                selected.add(item);
            }
        }
    }

    /** 更新「共 N 项 X · 已选 M 项 Y」 */
    private void updateSelectedSummary() {
        long total = 0;
        long picked = 0;
        for (int i = 0; i < items.size(); i++) {
            total += items.get(i).size;
        }
        for (CleanItem item : selected) {
            picked += item.size;
        }
        tvJunkSummary.setText(getString(R.string.clean_selected_summary,
                items.size(), FormatUtil.formatSize(total),
                selected.size(), FormatUtil.formatSize(picked)));
    }

    @Override
    protected String getFooterText() {
        return "只清理公共存储，应用私有缓存需跳系统设置页处理";
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.tab_junk) {
            switchTab(true);
            return;
        }
        if (id == R.id.tab_mem) {
            switchTab(false);
            loadProcesses();
            return;
        }
        if (id == R.id.btn_scan) {
            startScan();
            return;
        }
        if (id == R.id.btn_clear) {
            confirmClear();
            return;
        }
        if (id == R.id.btn_select_all) {
            selected.clear();
            selected.addAll(items);
            renderJunkList();
            updateSelectedSummary();
            return;
        }
        if (id == R.id.btn_invert) {
            Set<CleanItem> old = new HashSet<CleanItem>(selected);
            selected.clear();
            for (int i = 0; i < items.size(); i++) {
                if (!old.contains(items.get(i))) {
                    selected.add(items.get(i));
                }
            }
            renderJunkList();
            updateSelectedSummary();
            return;
        }
        if (id == R.id.btn_refresh_proc) {
            loadProcesses();
            return;
        }
        if (id == R.id.btn_kill_all) {
            confirmKillAll();
            return;
        }
        if (id == R.id.btn_open_settings) {
            openAppSettings();
            return;
        }
        super.onClick(v);
    }

    private void switchTab(boolean junk) {
        panelJunk.setVisibility(junk ? View.VISIBLE : View.GONE);
        panelMem.setVisibility(junk ? View.GONE : View.VISIBLE);
        if (junk) {
            tabJunk.setBackgroundResource(R.drawable.bg_tab_selected);
            tabJunk.setTextColor(0xFF10221E);
            tabMem.setBackgroundResource(0);
            tabMem.setTextColor(getResources().getColor(R.color.text_secondary));
        } else {
            tabMem.setBackgroundResource(R.drawable.bg_tab_selected);
            tabMem.setTextColor(0xFF10221E);
            tabJunk.setBackgroundResource(0);
            tabJunk.setTextColor(getResources().getColor(R.color.text_secondary));
        }
    }

    // ==================== 垃圾清理 ====================

    private void startScan() {
        if (scanning) {
            return;
        }
        scanning = true;
        pbScan.setVisibility(View.VISIBLE);
        tvJunkSummary.setText(getString(R.string.clean_scanning));
        junkList.removeAllViews();
        rowSelect.setVisibility(View.GONE);

        new Thread(new Runnable() {
            public void run() {
                final List<CleanItem> found = new CleanScanner(CleanActivity.this).scan();
                // 按体积从大到小排序，让用户一眼看到最占空间的东西
                Collections.sort(found, new Comparator<CleanItem>() {
                    public int compare(CleanItem a, CleanItem b) {
                        if (a.size > b.size) {
                            return -1;
                        }
                        if (a.size < b.size) {
                            return 1;
                        }
                        return 0;
                    }
                });
                handler.post(new Runnable() {
                    public void run() {
                        scanning = false;
                        pbScan.setVisibility(View.GONE);
                        items.clear();
                        items.addAll(found);
                        if (found.isEmpty()) {
                            tvJunkSummary.setText(getString(R.string.clean_none));
                            rowSelect.setVisibility(View.GONE);
                            rowOptions.setVisibility(View.GONE);
                            tvOptHint.setVisibility(View.GONE);
                            return;
                        }
                        // 压缩包与大文件默认不选，其余按开关状态走
                        applyTypeSelection();
                        rowSelect.setVisibility(View.VISIBLE);
                        rowOptions.setVisibility(View.VISIBLE);
                        tvOptHint.setVisibility(View.VISIBLE);
                        renderJunkList();
                        updateSelectedSummary();
                    }
                });
            }
        }).start();
    }

    private void renderJunkList() {
        junkList.removeAllViews();
        LayoutInflater inflater = getLayoutInflater();
        for (int i = 0; i < items.size(); i++) {
            final CleanItem item = items.get(i);
            View row = inflater.inflate(R.layout.item_clean_item, null);
            CheckBox cb = (CheckBox) row.findViewById(R.id.cb_select);
            TextView path = (TextView) row.findViewById(R.id.tv_path);
            TextView size = (TextView) row.findViewById(R.id.tv_size);
            TextView type = (TextView) row.findViewById(R.id.tv_type);

            cb.setText(item.name());
            cb.setChecked(selected.contains(item));
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        selected.add(item);
                    } else {
                        selected.remove(item);
                    }
                    updateSelectedSummary();
                }
            });
            path.setText(item.path);
            size.setText(FormatUtil.formatSize(item.size));
            type.setText(item.type);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dp(8));
            junkList.addView(row, lp);
        }
    }

    private void confirmClear() {
        if (selected.isEmpty()) {
            toast("没有选中任何项目");
            return;
        }
        int count = selected.size();
        new AlertDialog.Builder(this)
                .setTitle("确认清理")
                .setMessage(getString(R.string.clean_confirm, count))
                .setPositiveButton("确认删除", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        doClear();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void doClear() {
        final List<CleanItem> targets = new ArrayList<CleanItem>(selected);
        tvJunkSummary.setText("清理中…");
        new Thread(new Runnable() {
            public void run() {
                int ok = 0;
                int fail = 0;
                long freed = 0;
                for (int i = 0; i < targets.size(); i++) {
                    CleanItem item = targets.get(i);
                    File f = new File(item.path);
                    if (!f.exists()) {
                        ok++;
                        continue;
                    }
                    if (FileUtil.deleteRecursive(f)) {
                        ok++;
                        freed += item.size;
                    } else {
                        fail++;
                    }
                }
                final int okCount = ok;
                final int failCount = fail;
                final long freedBytes = freed;
                handler.post(new Runnable() {
                    public void run() {
                        String msg = getString(R.string.clean_deleted, okCount,
                                FormatUtil.formatSize(freedBytes));
                        if (failCount > 0) {
                            msg += "（" + failCount + " 项删除失败，多为系统保护目录）";
                        }
                        tvJunkSummary.setText(msg);
                        items.removeAll(targets);
                        selected.clear();
                        applyTypeSelection();
                        renderJunkList();
                        updateSelectedSummary();
                        toast("清理完成");
                    }
                });
            }
        }).start();
    }

    // ==================== 内存进程 ====================

    private void refreshMemSummary() {
        long total = DeviceInfo.getTotalMemory();
        long avail = DeviceInfo.getAvailMemory(this);
        if (total > 0) {
            tvMemSummary.setText("已用 " + FormatUtil.formatSize(total - avail)
                    + " / " + FormatUtil.formatSize(total)
                    + "  （剩余 " + FormatUtil.percent(total, avail) + "% 未用）");
        }
    }

    private void loadProcesses() {
        refreshMemSummary();
        procList.removeAllViews();
        procs.clear();

        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        PackageManager pm = getPackageManager();
        List<ActivityManager.RunningAppProcessInfo> list = am.getRunningAppProcesses();
        if (list == null) {
            // 高版本上系统可能直接不返回列表
            showProcEmpty(true);
            return;
        }

        int[] pids = new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            pids[i] = list.get(i).pid;
        }
        Debug.MemoryInfo[] memInfos = am.getProcessMemoryInfo(pids);

        String selfPkg = getPackageName();
        for (int i = 0; i < list.size(); i++) {
            ActivityManager.RunningAppProcessInfo info = list.get(i);
            String pkg = info.processName;
            if (pkg == null || pkg.length() == 0) {
                continue;
            }
            // 跳过自身，避免把自己杀掉
            if (pkg.equals(selfPkg)) {
                continue;
            }
            ProcInfo p = new ProcInfo();
            p.pkg = pkg;
            p.name = pkg;
            try {
                ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                p.name = pm.getApplicationLabel(ai).toString();
            } catch (Exception e) {
                // 非应用进程（如系统 native 进程）保持包名显示
            }
            if (memInfos != null && i < memInfos.length && memInfos[i] != null) {
                p.pssKb = memInfos[i].getTotalPss();
            }
            procs.add(p);
        }
        // 安卓 5.0 起第三方应用只能读到自身进程，这里跳过了自身，
        // 所以高版本上列表很可能为空——如实告诉用户，而不是假装没进程
        showProcEmpty(procs.isEmpty());
        renderProcList();
    }

    /** 是否显示「读不到进程列表」的说明卡 */
    private void showProcEmpty(boolean empty) {
        if (rowProcEmpty != null) {
            rowProcEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        }
    }

    private void renderProcList() {
        procList.removeAllViews();
        LayoutInflater inflater = getLayoutInflater();
        for (int i = 0; i < procs.size(); i++) {
            final ProcInfo p = procs.get(i);
            View row = inflater.inflate(R.layout.item_process_item, null);
            TextView name = (TextView) row.findViewById(R.id.tv_proc_name);
            TextView pkg = (TextView) row.findViewById(R.id.tv_proc_pkg);
            TextView mem = (TextView) row.findViewById(R.id.tv_proc_mem);
            TextView icon = (TextView) row.findViewById(R.id.tv_proc_icon);
            TextView kill = (TextView) row.findViewById(R.id.btn_kill);

            name.setText(p.name);
            pkg.setText(p.pkg);
            mem.setText(FormatUtil.formatSize(((long) p.pssKb) * 1024L));
            if (p.name.length() > 0) {
                icon.setText(p.name.substring(0, 1));
            }
            kill.setTag(p.pkg);
            kill.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String target = (String) v.getTag();
                    killOne(target);
                }
            });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dp(8));
            procList.addView(row, lp);
        }
    }

    private void killOne(String pkg) {
        try {
            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            am.killBackgroundProcesses(pkg);
            toast("已请求结束：" + pkg);
            handler.postDelayed(new Runnable() {
                public void run() {
                    loadProcesses();
                }
            }, 800);
        } catch (Exception e) {
            toast("结束失败：" + e.getMessage());
        }
    }

    /** 点「清除后台进程」先弹确认框，确认后才真正执行 */
    private void confirmKillAll() {
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.kill_confirm_title))
                .setMessage(getString(R.string.kill_confirm_msg))
                .setNegativeButton(getString(R.string.action_cancel), null)
                .setPositiveButton(getString(R.string.action_confirm),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                doKillAll();
                            }
                        })
                .show();
    }

    private void doKillAll() {
        if (procs.isEmpty()) {
            toast("当前没有可读到的后台进程，可打开系统设置手动处理");
            return;
        }
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        int count = 0;
        for (int i = 0; i < procs.size(); i++) {
            try {
                am.killBackgroundProcesses(procs.get(i).pkg);
                count++;
            } catch (Exception e) {
                // 单个失败不影响整体
            }
        }
        toast(getString(R.string.mem_killed, count));
        handler.postDelayed(new Runnable() {
            public void run() {
                loadProcesses();
            }
        }, 800);
    }

    /** 跳系统应用设置页，供高版本手动管理后台 */
    private void openAppSettings() {
        try {
            startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_SETTINGS));
        } catch (Exception e) {
            toast("无法打开系统设置页");
        }
    }
}
