package com.modace.ctmod.security;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * 源码文件加密 —— AES-256-CBC。
 *
 * 【为什么要自己拼文件格式】
 *   Cipher 只产出密文，不记录 IV 和版本。
 *   解密时没有 IV 就解不开，所以必须把 IV 写进文件头一起存。
 *
 * 文件格式：
 *   ┌────────┬────────┬─────────┬──────────┐
 *   │ "CTEN" │ 版本 1 │ IV 16B  │  密文…   │
 *   └────────┴────────┴─────────┴──────────┘
 *   4 字节    1 字节    16 字节    其余
 *
 * 前 4 字节 magic 用于识别「这个文件是不是本工具加密的」，
 * 避免误解密把正常文件搞坏。
 *
 * 【兼容性】
 *   只用了 MessageDigest / Cipher / SecureRandom，
 *   这些从 Android 1.0 就有，minSdk 14 完全没问题。
 *   刻意没用 PBKDF2WithHmacSHA256 —— 那个要 API 26。
 */
public final class SourceCipher {

    /** 文件头标识 */
    private static final byte[] MAGIC = {'C', 'T', 'E', 'N'};
    private static final byte VERSION = 1;
    private static final int IV_LEN = 16;
    private static final int HEADER_LEN = 5 + IV_LEN;

    private SourceCipher() {
    }

    /** 该字节数组是否为本工具加密的产物 */
    public static boolean isEncrypted(byte[] data) {
        if (data == null || data.length < HEADER_LEN) {
            return false;
        }
        for (int i = 0; i < MAGIC.length; i++) {
            if (data[i] != MAGIC[i]) {
                return false;
            }
        }
        return data[4] == VERSION;
    }

    /**
     * 加密明文。
     * @param plain    明文
     * @param password 口令
     * @return 带文件头的完整密文
     */
    public static byte[] encrypt(byte[] plain, String password) throws Exception {
        byte[] key = deriveKey(password);
        byte[] iv = new byte[IV_LEN];
        new SecureRandom().nextBytes(iv);

        Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
        byte[] body = c.doFinal(plain);

        byte[] out = new byte[HEADER_LEN + body.length];
        System.arraycopy(MAGIC, 0, out, 0, 4);
        out[4] = VERSION;
        System.arraycopy(iv, 0, out, 5, IV_LEN);
        System.arraycopy(body, 0, out, HEADER_LEN, body.length);
        return out;
    }

    /**
     * 解密密文。
     * @param cipherData 带文件头的完整密文
     * @param password   口令（必须与加密时一致）
     */
    public static byte[] decrypt(byte[] cipherData, String password) throws Exception {
        if (!isEncrypted(cipherData)) {
            throw new IllegalArgumentException("不是本工具加密的文件");
        }
        byte[] key = deriveKey(password);
        byte[] iv = Arrays.copyOfRange(cipherData, 5, 5 + IV_LEN);
        byte[] body = Arrays.copyOfRange(cipherData, HEADER_LEN, cipherData.length);

        Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
        return c.doFinal(body);
    }

    /**
     * 由口令派生 32 字节密钥。
     * 用 SHA-256 而非 PBKDF2：PBKDF2 的标准算法名在低版本上支持不一致，
     * 而 SHA-256 全版本可用。口令建议用户设置足够长。
     */
    private static byte[] deriveKey(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        String pw = (password == null) ? "" : password;
        return md.digest(pw.getBytes("UTF-8"));
    }
}
