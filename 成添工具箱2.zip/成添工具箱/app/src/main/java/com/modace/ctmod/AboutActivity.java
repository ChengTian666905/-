package com.modace.ctmod;

import android.widget.LinearLayout;

/** 关于页 */
public class AboutActivity extends BaseModuleActivity {

    @Override
    protected String getTitleText() {
        return getString(R.string.title_about);
    }

    @Override
    protected void buildContent(LinearLayout container) {
        addCard(container, getString(R.string.app_name), getString(R.string.app_subtitle));
        addCard(container, "定位", getString(R.string.about_desc));
        addCard(container, "原则", getString(R.string.about_principle));

        addSectionTitle(container, "已实现能力");
        addCard(container, "Lua 加密",
                "三种模式：轻量 RC4、增强（RC4+置换+校验）、XXTEA。\n" +
                        "自动生成自包含 Loader，支持回环验证。");
        addCard(container, "清理加速",
                "扫描安装包、临时文件、大文件、重复文件、空目录、卸载残留；\n" +
                        "进程列表与后台释放。");
        addCard(container, "加固自检",
                "签名校验、调试器检测、ptrace 跟踪检测、模拟器识别、debuggable 检查。");

        addSectionTitle(container, "使用提醒");
        addCard(container, "",
                "1. Lua 加密属混淆级保护，用于保护自有脚本知识产权，\n" +
                        "   请勿用于破解或注入他人程序。\n" +
                        "2. 清理前务必查看预览列表，确认无误再删。\n" +
                        "3. 应用私有缓存受系统限制无法直接清理，需跳系统设置页。");

        addCard(container, "版本", "v1.0");
    }
}
