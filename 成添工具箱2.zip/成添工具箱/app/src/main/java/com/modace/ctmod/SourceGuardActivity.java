package com.modace.ctmod;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.modace.ctmod.security.SourceCipher;
import com.modace.ctmod.security.SourceScanner;
import com.modace.ctmod.util.FileUtil;
import com.modace.ctmod.util.FormatUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 源码加密 —— 批量把 .java / .kt / .xml / .lua / .gradle 等加密成 .ctenc。
 *
 * 【安全设计：回环校验后才删原文件】
 *   加密 → 立刻用同一口令解密 → 比对 MD5 → 一致才删除原文件。
 *   这是防止「加密成功但解不开」导致源码永久丢失的关键一步，
 *   没有这一步的批量加密工具是极其危险的。
 *
 * 【诚实说明】
 *   这是文件级加密，防的是「别人拿到你的源码目录直接看」。
 *   它不能防止 APK 被反编译——那是混淆和加固的活，两回事。
 */
public class SourceGuardActivity extends BaseModuleActivity implements View.OnClickListener {

    private static final int MODE_ENCRYPT = 0;
    private static final int MODE_DECRYPT = 1;

    private EditText etDir;
    private EditText etPwd;
    private TextView tvSummary;
    private TextView tvLog;
    private LinearLayout fileList;
    private LinearLayout rowSelect;
    private ProgressBar pbWork;
    private CheckBox cbJava;
    private CheckBox cbKt;
    private CheckBox cbXml;
    private CheckBox cbLua;
    private CheckBox cbGradle;
    private CheckBox cbOther;

    private final List<SourceScanner.SourceFile> files = new ArrayList<SourceScanner.SourceFile>();
    private final Set<SourceScanner.SourceFile> selected = new HashSet<SourceScanner.SourceFile>();

    private final Handler handler = new Handler();
    private boolean working = false;

    @Override
    protected String getTitleText() {
        return getString(R.string.tool_source_guard);
    }

    @Override
    protected int getContentLayoutRes() {
        return R.layout.activity_source_guard;
    }

    @Override
    protected void buildContent(LinearLayout container) {
        // 使用自定义布局
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        etDir = (EditText) findViewById(R.id.et_dir);
        etPwd = (EditText) findViewById(R.id.et_pwd);
        tvSummary = (TextView) findViewById(R.id.tv_summary);
        tvLog = (TextView) findViewById(R.id.tv_log);
        fileList = (LinearLayout) findViewById(R.id.file_list);
        rowSelect = (LinearLayout) findViewById(R.id.row_select);
        pbWork = (ProgressBar) findViewById(R.id.pb_work);
        cbJava = (CheckBox) findViewById(R.id.cb_java);
        cbKt = (CheckBox) findViewById(R.id.cb_kt);
        cbXml = (CheckBox) findViewById(R.id.cb_xml);
        cbLua = (CheckBox) findViewById(R.id.cb_lua);
        cbGradle = (CheckBox) findViewById(R.id.cb_gradle);
        cbOther = (CheckBox) findViewById(R.id.cb_other);

        findViewById(R.id.btn_scan).setOnClickListener(this);
        findViewById(R.id.btn_encrypt).setOnClickListener(this);
        findViewById(R.id.btn_decrypt).setOnClickListener(this);
        findViewById(R.id.btn_select_all).setOnClickListener(this);
        findViewById(R.id.btn_invert).setOnClickListener(this);

        // 默认定位到外部存储下的工程目录（若存在）
        File guess = new File(android.os.Environment.getExternalStorageDirectory(), "AppProjects");
        if (!guess.exists()) {
            guess = android.os.Environment.getExternalStorageDirectory();
        }
        etDir.setText(guess.getAbsolutePath());

        tvSummary.setText(getString(R.string.hint_placeholder));
    }

    @Override
    protected String getFooterText() {
        return "加密前请先备份 · 口令遗失无法恢复";
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btn_scan) {
            doScan(MODE_ENCRYPT);
            return;
        }
        if (id == R.id.btn_encrypt) {
            confirmAndRun(MODE_ENCRYPT);
            return;
        }
        if (id == R.id.btn_decrypt) {
            doScan(MODE_DECRYPT);
            return;
        }
        if (id == R.id.btn_select_all) {
            selected.clear();
            selected.addAll(files);
            renderList();
            return;
        }
        if (id == R.id.btn_invert) {
            Set<SourceScanner.SourceFile> old = new HashSet<SourceScanner.SourceFile>(selected);
            selected.clear();
            for (int i = 0; i < files.size(); i++) {
                if (!old.contains(files.get(i))) {
                    selected.add(files.get(i));
                }
            }
            renderList();
            return;
        }
    }

    // ==================== 扫描 ====================

    private String[] chosenExts() {
        List<String> list = new ArrayList<String>();
        if (cbJava != null && cbJava.isChecked()) {
            list.add("java");
        }
        if (cbKt != null && cbKt.isChecked()) {
            list.add("kt");
        }
        if (cbXml != null && cbXml.isChecked()) {
            list.add("xml");
        }
        if (cbLua != null && cbLua.isChecked()) {
            list.add("lua");
        }
        if (cbGradle != null && cbGradle.isChecked()) {
            list.add("gradle");
            list.add("pro");
        }
        if (cbOther != null && cbOther.isChecked()) {
            list.add("txt");
            list.add("md");
            list.add("json");
            list.add("properties");
        }
        return list.toArray(new String[list.size()]);
    }

    private void doScan(final int mode) {
        final String dirPath = etDir.getText().toString().trim();
        if (dirPath.length() == 0) {
            toast(getString(R.string.guard_need_dir));
            return;
        }
        final File dir = new File(dirPath);
        if (!dir.isDirectory()) {
            toast(getString(R.string.guard_need_dir));
            return;
        }

        tvLog.setText("扫描中…");
        new Thread(new Runnable() {
            public void run() {
                final List<SourceScanner.SourceFile> found =
                        SourceScanner.scan(dir, chosenExts(), mode == MODE_DECRYPT);
                handler.post(new Runnable() {
                    public void run() {
                        files.clear();
                        files.addAll(found);
                        selected.clear();
                        selected.addAll(found);
                        if (found.isEmpty()) {
                            tvSummary.setText(getString(R.string.guard_none));
                            rowSelect.setVisibility(View.GONE);
                            fileList.removeAllViews();
                            tvLog.setText("");
                            return;
                        }
                        long total = 0;
                        for (int i = 0; i < found.size(); i++) {
                            total += found.get(i).size;
                        }
                        tvSummary.setText(getString(R.string.guard_found,
                                found.size(), FormatUtil.formatSize(total), selected.size()));
                        rowSelect.setVisibility(View.VISIBLE);
                        renderList();
                        tvLog.setText(mode == MODE_DECRYPT
                                ? getString(R.string.guard_mode_note) : "");
                    }
                });
            }
        }).start();
    }

    private void renderList() {
        fileList.removeAllViews();
        if (files.isEmpty()) {
            return;
        }
        LayoutInflater inflater = getLayoutInflater();
        for (int i = 0; i < files.size(); i++) {
            final SourceScanner.SourceFile sf = files.get(i);
            View row = inflater.inflate(R.layout.item_source_file, null);
            CheckBox cb = (CheckBox) row.findViewById(R.id.cb_select);
            TextView name = (TextView) row.findViewById(R.id.tv_name);
            TextView path = (TextView) row.findViewById(R.id.tv_path);
            TextView size = (TextView) row.findViewById(R.id.tv_size);

            name.setText(sf.name());
            path.setText(sf.path());
            size.setText(FormatUtil.formatSize(sf.size));
            cb.setChecked(selected.contains(sf));

            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        selected.add(sf);
                    } else {
                        selected.remove(sf);
                    }
                }
            });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dp(8));
            fileList.addView(row, lp);
        }
        // 同步摘要里的已选数量
        if (!files.isEmpty()) {
            long total = 0;
            for (int i = 0; i < files.size(); i++) {
                total += files.get(i).size;
            }
            tvSummary.setText(getString(R.string.guard_found,
                    files.size(), FormatUtil.formatSize(total), selected.size()));
        }
    }

    // ==================== 执行 ====================

    private void confirmAndRun(final int mode) {
        if (working) {
            return;
        }
        if (selected.isEmpty()) {
            toast(getString(R.string.guard_need_select));
            return;
        }
        final String pwd = etPwd.getText().toString();
        if (pwd.length() == 0) {
            toast(getString(R.string.guard_need_pwd));
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle(mode == MODE_ENCRYPT
                        ? getString(R.string.guard_encrypt) : getString(R.string.guard_decrypt))
                .setMessage(getString(R.string.guard_warn_delete))
                .setNegativeButton(getString(R.string.action_cancel), null)
                .setPositiveButton(getString(R.string.action_confirm),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                runWork(mode, pwd);
                            }
                        })
                .show();
    }

    private void runWork(final int mode, final String pwd) {
        final List<SourceScanner.SourceFile> targets =
                new ArrayList<SourceScanner.SourceFile>(selected);
        working = true;
        pbWork.setVisibility(View.VISIBLE);
        pbWork.setProgress(0);
        tvLog.setText(getString(R.string.guard_working, 0, targets.size()));

        new Thread(new Runnable() {
            public void run() {
                int ok = 0;
                int fail = 0;
                final StringBuilder log = new StringBuilder();

                for (int i = 0; i < targets.size(); i++) {
                    final int idx = i + 1;
                    SourceScanner.SourceFile sf = targets.get(i);
                    try {
                        if (mode == MODE_ENCRYPT) {
                            if (encryptOne(sf, pwd)) {
                                ok++;
                            } else {
                                fail++;
                                log.append("失败 ").append(sf.name()).append("：校验未通过\n");
                            }
                        } else {
                            if (decryptOne(sf, pwd)) {
                                ok++;
                            } else {
                                fail++;
                                log.append("失败 ").append(sf.name()).append("：口令错误或文件损坏\n");
                            }
                        }
                    } catch (Exception e) {
                        fail++;
                        log.append("失败 ").append(sf.name()).append("：")
                                .append(e.getMessage()).append("\n");
                    }

                    final int progress = idx * 100 / targets.size();
                    final int doneCount = idx;
                    handler.post(new Runnable() {
                        public void run() {
                            pbWork.setProgress(progress);
                            tvLog.setText(getString(R.string.guard_working,
                                    doneCount, targets.size()));
                        }
                    });
                }

                final int okCount = ok;
                final int failCount = fail;
                final String detail = log.toString();
                handler.post(new Runnable() {
                    public void run() {
                        working = false;
                        pbWork.setVisibility(View.GONE);
                        tvLog.setText(getString(R.string.guard_done, okCount, failCount)
                                + (detail.length() > 0 ? "\n\n" + detail : ""));
                        files.clear();
                        selected.clear();
                        fileList.removeAllViews();
                        rowSelect.setVisibility(View.GONE);
                        tvSummary.setText(getString(R.string.hint_placeholder));
                        toast(getString(R.string.guard_done, okCount, failCount));
                    }
                });
            }
        }).start();
    }

    /**
     * 加密单个文件：加密 → 回环解密校验 → 通过才删原文件。
     * 任一步失败都返回 false，原文件保持不动。
     */
    private boolean encryptOne(SourceScanner.SourceFile sf, String pwd) throws Exception {
        byte[] plain = FileUtil.readBytes(sf.file);
        if (plain == null) {
            return false;
        }
        byte[] cipher = SourceCipher.encrypt(plain, pwd);

        File target = SourceScanner.encTarget(sf.file);
        if (!FileUtil.writeBytes(target, cipher)) {
            return false;
        }

        // ---- 回环校验：解回来跟原文比对 ----
        byte[] written = FileUtil.readBytes(target);
        if (written == null) {
            return false;
        }
        byte[] back = SourceCipher.decrypt(written, pwd);
        if (!java.util.Arrays.equals(plain, back)) {
            // 解不开，删掉产物，绝不删原文件
            target.delete();
            return false;
        }

        // 校验通过，才删除原文件
        return sf.file.delete();
    }

    /**
     * 解密单个文件：解密 → 写回原文件名 → 校验 → 删 .ctenc。
     */
    private boolean decryptOne(SourceScanner.SourceFile sf, String pwd) throws Exception {
        byte[] data = FileUtil.readBytes(sf.file);
        if (data == null) {
            return false;
        }
        byte[] plain = SourceCipher.decrypt(data, pwd);

        File target = SourceScanner.decTarget(sf.file);
        if (!FileUtil.writeBytes(target, plain)) {
            return false;
        }

        // ---- 回环校验 ----
        byte[] written = FileUtil.readBytes(target);
        if (written == null || !java.util.Arrays.equals(written, plain)) {
            target.delete();
            return false;
        }

        return sf.file.delete();
    }
}
