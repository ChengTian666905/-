package com.modace.ctmod.clean;

/** 一条可清理项 */
public class CleanItem {

    public static final String TYPE_APK = "安装包";
    public static final String TYPE_TEMP = "临时文件";
    public static final String TYPE_EMPTY = "空目录";
    public static final String TYPE_LARGE = "大文件";
    public static final String TYPE_DUP = "重复文件";
    public static final String TYPE_RESIDUE = "卸载残留";
    public static final String TYPE_LOG = "日志缓存";
    public static final String TYPE_ZIP = "压缩包";

    /**
     * 该类型是否默认勾选。
     * 压缩包和大文件默认不选——它们体积大但很可能是用户有意保留的，
     * 误删代价高，必须让用户主动确认。
     */
    public static boolean isDefaultSelected(String type) {
        if (TYPE_ZIP.equals(type)) {
            return false;
        }
        if (TYPE_LARGE.equals(type)) {
            return false;
        }
        return true;
    }

    public final String path;
    public final long size;
    public final String type;

    public CleanItem(String path, long size, String type) {
        this.path = path;
        this.size = size;
        this.type = type;
    }

    /** 显示名：取路径最后一段 */
    public String name() {
        int idx = path.lastIndexOf('/');
        if (idx >= 0 && idx < path.length() - 1) {
            return path.substring(idx + 1);
        }
        return path;
    }
}
