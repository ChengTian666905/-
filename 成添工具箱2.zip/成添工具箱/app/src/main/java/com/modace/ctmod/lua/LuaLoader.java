package com.modace.ctmod.lua;

/**
 * 生成 Lua 端解密器（Loader）。
 *
 * 产出的 Loader 是自包含的 .lua 文件：内嵌密文 + 解密函数，
 * 直接 require / dofile 即可运行原脚本。
 *
 * 三种模式的 Lua 端依赖：
 *   light  : 纯 Lua 5.1 语法，无任何库依赖
 *   strong : 纯 Lua 5.1 语法，无任何库依赖
 *   xxtea  : 需要 Lua 5.3+（使用原生位运算符），或提供 bit32/bit 库
 */
public final class LuaLoader {

    private LuaLoader() {
    }

    /** 生成一个可直接运行的加密 Lua 文件全文 */
    public static String build(int mode, String key, String base64) {
        StringBuilder sb = new StringBuilder();
        sb.append("--[[ CT Toolbox encrypted script ]]\n");
        sb.append("-- mode: ").append(modeName(mode)).append("\n");
        sb.append("-- 本文件由成添工具箱生成，请勿手工修改，改后可能无法运行\n");
        sb.append("local CT_KEY = '").append(escape(key)).append("'\n");
        sb.append("local CT_DAT = '").append(escape(base64)).append("'\n\n");

        sb.append(COMMON_HELPERS);

        if (mode == LuaCipher.MODE_LIGHT) {
            sb.append(LIGHT_TAIL);
        } else if (mode == LuaCipher.MODE_STRONG) {
            sb.append(STRONG_HELPERS);
            sb.append(STRONG_TAIL);
        } else {
            sb.append(XXTEA_HELPERS);
            sb.append(XXTEA_TAIL);
        }
        return sb.toString();
    }

    public static String modeName(int mode) {
        if (mode == LuaCipher.MODE_LIGHT) {
            return "light (RC4+Base64) target Lua 5.1+";
        }
        if (mode == LuaCipher.MODE_STRONG) {
            return "strong (RC4+permute+checksum) target Lua 5.1+";
        }
        return "xxtea target Lua 5.3+";
    }

    private static String escape(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "");
    }

    // ============ 公共：按位异或（纯算术，不依赖 bit 库）+ Base64 + RC4 + loader ============
    private static final String COMMON_HELPERS =
            "local function CT_BXOR(a, b)\n" +
                    "  local r, p = 0, 128\n" +
                    "  for _ = 1, 8 do\n" +
                    "    local x, y = 0, 0\n" +
                    "    if a >= p then x = p a = a - p end\n" +
                    "    if b >= p then y = p b = b - p end\n" +
                    "    if x ~= y then r = r + p end\n" +
                    "    p = p / 2\n" +
                    "  end\n" +
                    "  return math.floor(r)\n" +
                    "end\n\n" +
                    "local function CT_B64(s)\n" +
                    "  local B = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'\n" +
                    "  local function I(c)\n" +
                    "    if c == '=' then return 0 end\n" +
                    "    local p = string.find(B, c, 1, true)\n" +
                    "    if not p then return nil end\n" +
                    "    return p - 1\n" +
                    "  end\n" +
                    "  local out = {}\n" +
                    "  local i, L = 1, #s\n" +
                    "  while i <= L do\n" +
                    "    local c1 = I(string.sub(s, i, i))\n" +
                    "    local c2 = I(string.sub(s, i + 1, i + 1))\n" +
                    "    local c3 = I(string.sub(s, i + 2, i + 2))\n" +
                    "    local c4 = I(string.sub(s, i + 3, i + 3))\n" +
                    "    if not c1 or not c2 then break end\n" +
                    "    local n = c1 * 262144 + c2 * 4096 + (c3 or 0) * 64 + (c4 or 0)\n" +
                    "    out[#out + 1] = string.char(math.floor(n / 65536) % 256)\n" +
                    "    if c3 then out[#out + 1] = string.char(math.floor(n / 256) % 256) end\n" +
                    "    if c4 then out[#out + 1] = string.char(n % 256) end\n" +
                    "    i = i + 4\n" +
                    "  end\n" +
                    "  return table.concat(out)\n" +
                    "end\n\n" +
                    "local function CT_RC4(key, data)\n" +
                    "  local S = {}\n" +
                    "  for i = 0, 255 do S[i] = i end\n" +
                    "  local j, kl = 0, #key\n" +
                    "  for i = 0, 255 do\n" +
                    "    j = (j + S[i] + string.byte(key, (i % kl) + 1)) % 256\n" +
                    "    local t = S[i] S[i] = S[j] S[j] = t\n" +
                    "  end\n" +
                    "  local out = {}\n" +
                    "  local a, b = 0, 0\n" +
                    "  for n = 1, #data do\n" +
                    "    a = (a + 1) % 256\n" +
                    "    b = (b + S[a]) % 256\n" +
                    "    local t = S[a] S[a] = S[b] S[b] = t\n" +
                    "    local k = S[(S[a] + S[b]) % 256]\n" +
                    "    out[n] = string.char(CT_BXOR(string.byte(data, n), k))\n" +
                    "  end\n" +
                    "  return table.concat(out)\n" +
                    "end\n\n" +
                    "local function CT_LOAD(src)\n" +
                    "  if loadstring then return loadstring(src) end\n" +
                    "  return load(src)\n" +
                    "end\n\n";

    // ============ light ============
    private static final String LIGHT_TAIL =
            "local CT_SRC = CT_RC4(CT_KEY, CT_B64(CT_DAT))\n" +
                    "return assert(CT_LOAD(CT_SRC))()\n";

    // ============ strong：置换表 + 逆置换 + 校验 ============
    private static final String STRONG_HELPERS =
            "local function CT_BOX(key)\n" +
                    "  local box = {}\n" +
                    "  for i = 0, 255 do box[i] = i end\n" +
                    "  local j, kl = 0, #key\n" +
                    "  for i = 0, 255 do\n" +
                    "    j = (j + box[i] + string.byte(key, (i % kl) + 1) * 31) % 256\n" +
                    "    local t = box[i] box[i] = box[j] box[j] = t\n" +
                    "  end\n" +
                    "  return box\n" +
                    "end\n\n" +
                    "local function CT_INV(key)\n" +
                    "  local box, inv = CT_BOX(key), {}\n" +
                    "  for i = 0, 255 do inv[box[i]] = i end\n" +
                    "  return inv\n" +
                    "end\n\n" +
                    "local function CT_SUM(s)\n" +
                    "  local t = 0\n" +
                    "  for i = 1, #s do t = (t + string.byte(s, i)) % 4294967296 end\n" +
                    "  return t\n" +
                    "end\n\n";

    private static final String STRONG_TAIL =
            "local CT_RAW = CT_RC4(CT_KEY, CT_B64(CT_DAT))\n" +
                    "local CT_PAD = string.byte(CT_RAW, 1)\n" +
                    "local CT_OFF = 1 + CT_PAD\n" +
                    "local CT_CHK = string.byte(CT_RAW, CT_OFF + 1) * 16777216\n" +
                    "             + string.byte(CT_RAW, CT_OFF + 2) * 65536\n" +
                    "             + string.byte(CT_RAW, CT_OFF + 3) * 256\n" +
                    "             + string.byte(CT_RAW, CT_OFF + 4)\n" +
                    "local CT_INVT = CT_INV(CT_KEY)\n" +
                    "local CT_BEG = CT_OFF + 5\n" +
                    "local CT_OUT = {}\n" +
                    "local CT_LEN = #CT_RAW - CT_BEG + 1\n" +
                    "for i = 1, CT_LEN do\n" +
                    "  CT_OUT[i] = string.char(CT_INVT[string.byte(CT_RAW, CT_BEG + i - 1)])\n" +
                    "end\n" +
                    "local CT_SRC = table.concat(CT_OUT)\n" +
                    "if CT_SUM(CT_SRC) ~= CT_CHK then\n" +
                    "  error('CT: checksum mismatch, wrong key or corrupted file')\n" +
                    "end\n" +
                    "return assert(CT_LOAD(CT_SRC))()\n";

    // ============ xxtea：Lua 5.3 原生位运算 ============
    private static final String XXTEA_HELPERS =
            "local CT_DELTA = 0x9E3779B9\n" +
                    "local function CT_M32(x) return x & 0xFFFFFFFF end\n" +
                    "local function CT_MX(sum, y, z, p, e, k)\n" +
                    "  local a = ((z >> 5) ~ ((y << 2) & 0xFFFFFFFF)) & 0xFFFFFFFF\n" +
                    "  local b = ((y >> 3) ~ ((z << 4) & 0xFFFFFFFF)) & 0xFFFFFFFF\n" +
                    "  local c = (sum ~ y) & 0xFFFFFFFF\n" +
                    "  local d = (k[((p & 3) ~ e) + 1] ~ z) & 0xFFFFFFFF\n" +
                    "  return (CT_M32(a + b) ~ CT_M32(c + d)) & 0xFFFFFFFF\n" +
                    "end\n" +
                    "local function CT_TOINT(s, inclen)\n" +
                    "  local n = math.floor((#s + 3) / 4)\n" +
                    "  local r = {}\n" +
                    "  for i = 1, n do r[i] = 0 end\n" +
                    "  if inclen then r[n + 1] = #s end\n" +
                    "  for i = 1, #s do\n" +
                    "    local idx = math.floor((i - 1) / 4) + 1\n" +
                    "    local sh = ((i - 1) % 4) * 8\n" +
                    "    r[idx] = r[idx] | (string.byte(s, i) << sh)\n" +
                    "  end\n" +
                    "  return r\n" +
                    "end\n" +
                    "local function CT_KEYINT(s)\n" +
                    "  local k = {}\n" +
                    "  for i = 1, 4 do\n" +
                    "    local v = 0\n" +
                    "    for j = 0, 3 do\n" +
                    "      local b = string.byte(s, (i - 1) * 4 + j + 1) or 0\n" +
                    "      v = v | (b << (j * 8))\n" +
                    "    end\n" +
                    "    k[i] = v\n" +
                    "  end\n" +
                    "  return k\n" +
                    "end\n" +
                    "local function CT_TOBYTES(v, inclen)\n" +
                    "  local n = #v * 4\n" +
                    "  if inclen then n = v[#v] end\n" +
                    "  local out = {}\n" +
                    "  for i = 1, n do\n" +
                    "    local idx = math.floor((i - 1) / 4) + 1\n" +
                    "    local sh = ((i - 1) % 4) * 8\n" +
                    "    out[i] = string.char((v[idx] >> sh) & 0xFF)\n" +
                    "  end\n" +
                    "  return table.concat(out)\n" +
                    "end\n" +
                    "local function CT_DEC(k, data)\n" +
                    "  local v = CT_TOINT(data, false)\n" +
                    "  local n = #v - 1\n" +
                    "  if n < 1 then return data end\n" +
                    "  local y = v[1]\n" +
                    "  local z = v[n + 1]\n" +
                    "  local q = 6 + math.floor(52 / (n + 1))\n" +
                    "  local sum = CT_M32(q * CT_DELTA)\n" +
                    "  while sum ~= 0 do\n" +
                    "    local e = (sum >> 2) & 3\n" +
                    "    for p = n, 1, -1 do\n" +
                    "      z = v[p]\n" +
                    "      y = CT_M32(v[p + 1] - CT_MX(sum, y, z, p, e, k))\n" +
                    "      v[p + 1] = y\n" +
                    "    end\n" +
                    "    z = v[n + 1]\n" +
                    "    y = CT_M32(v[1] - CT_MX(sum, y, z, 0, e, k))\n" +
                    "    v[1] = y\n" +
                    "    sum = CT_M32(sum - CT_DELTA)\n" +
                    "  end\n" +
                    "  return CT_TOBYTES(v, true)\n" +
                    "end\n\n";

    private static final String XXTEA_TAIL =
            "local CT_K16 = CT_KEY\n" +
                    "while #CT_K16 < 16 do CT_K16 = CT_K16 .. CT_K16 end\n" +
                    "CT_K16 = string.sub(CT_K16, 1, 16)\n" +
                    "local CT_SRC = CT_DEC(CT_KEYINT(CT_K16), CT_B64(CT_DAT))\n" +
                    "return assert(CT_LOAD(CT_SRC))()\n";
}
