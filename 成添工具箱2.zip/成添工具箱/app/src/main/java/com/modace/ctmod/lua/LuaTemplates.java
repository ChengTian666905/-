package com.modace.ctmod.lua;

import com.modace.ctmod.R;

/**
 * 六个功能模板。
 *
 * 模板 1「基础模板」是完整的菜单框架，可直接运行、自行往里填功能。
 * 其余五个为通用 Lua 结构模板，按需取用。
 *
 * 全部为 Lua 5.1 语法，不依赖第三方库。
 */
public final class LuaTemplates {

    /** 一条模板 */
    public static class Template {
        public final int nameRes;
        public final int descRes;
        public final String code;

        public Template(int nameRes, int descRes, String code) {
            this.nameRes = nameRes;
            this.descRes = descRes;
            this.code = code;
        }
    }

    private LuaTemplates() {
    }

    /** 模板 1：基础模板 —— 菜单框架 */
    private static final String TPL_1 =
            "-- ============================\n"
            + "--  基础模板：菜单框架\n"
            + "--  把功能填进 Func1 ~ Func6 即可\n"
            + "-- ============================\n"
            + "\n"
            + "function Main()\n"
            + "  local choice = gg.choice({\n"
            + "    \"功能名称1\",\n"
            + "    \"功能名称2\",\n"
            + "    \"功能名称3\",\n"
            + "    \"功能名称4\",\n"
            + "    \"功能名称5\",\n"
            + "    \"功能名称6\",\n"
            + "    \"退出脚本\"\n"
            + "  }, nil, \"这里可以填写你的提示文字\")\n"
            + "\n"
            + "  if choice == 1 then Func1() end\n"
            + "  if choice == 2 then Func2() end\n"
            + "  if choice == 3 then Func3() end\n"
            + "  if choice == 4 then Func4() end\n"
            + "  if choice == 5 then Func5() end\n"
            + "  if choice == 6 then Func6() end\n"
            + "  if choice == 7 then Exit() end\n"
            + "end\n"
            + "\n"
            + "function Func1()\n"
            + "  -- TODO: 功能一\n"
            + "end\n"
            + "\n"
            + "function Func2()\n"
            + "  -- TODO: 功能二\n"
            + "end\n"
            + "\n"
            + "function Func3()\n"
            + "  -- TODO: 功能三\n"
            + "end\n"
            + "\n"
            + "function Func4()\n"
            + "  -- TODO: 功能四\n"
            + "end\n"
            + "\n"
            + "function Func5()\n"
            + "  -- TODO: 功能五\n"
            + "end\n"
            + "\n"
            + "function Func6()\n"
            + "  -- TODO: 功能六\n"
            + "end\n"
            + "\n"
            + "function Exit()\n"
            + "  print(\"退出脚本后的提示文字\")\n"
            + "  os.exit()\n"
            + "end\n"
            + "\n"
            + "local running = false\n"
            + "\n"
            + "while true do\n"
            + "  if gg.isVisible(true) then\n"
            + "    running = true\n"
            + "    gg.setVisible(false)\n"
            + "  end\n"
            + "  gg.clearResults()\n"
            + "  if running then\n"
            + "    Main()\n"
            + "  end\n"
            + "end\n";

    /** 模板 2：二级子菜单 */
    private static final String TPL_2 =
            "-- ============================\n"
            + "--  二级子菜单\n"
            + "-- ============================\n"
            + "\n"
            + "function Main()\n"
            + "  local choice = gg.choice({\n"
            + "    \"子菜单 A\",\n"
            + "    \"子菜单 B\",\n"
            + "    \"退出\"\n"
            + "  }, nil, \"请选择分类\")\n"
            + "\n"
            + "  if choice == 1 then SubMenuA() end\n"
            + "  if choice == 2 then SubMenuB() end\n"
            + "  if choice == 3 then Exit() end\n"
            + "end\n"
            + "\n"
            + "function SubMenuA()\n"
            + "  local sub = gg.choice({\n"
            + "    \"A-功能1\",\n"
            + "    \"A-功能2\",\n"
            + "    \"返回上级\"\n"
            + "  }, nil, \"子菜单 A\")\n"
            + "\n"
            + "  if sub == 1 then\n"
            + "    -- TODO\n"
            + "  elseif sub == 2 then\n"
            + "    -- TODO\n"
            + "  elseif sub == 3 then\n"
            + "    Main()\n"
            + "  end\n"
            + "end\n"
            + "\n"
            + "function SubMenuB()\n"
            + "  local sub = gg.choice({\n"
            + "    \"B-功能1\",\n"
            + "    \"返回上级\"\n"
            + "  }, nil, \"子菜单 B\")\n"
            + "\n"
            + "  if sub == 1 then\n"
            + "    -- TODO\n"
            + "  elseif sub == 2 then\n"
            + "    Main()\n"
            + "  end\n"
            + "end\n"
            + "\n"
            + "function Exit()\n"
            + "  os.exit()\n"
            + "end\n"
            + "\n"
            + "Main()\n";

    /** 模板 3：数值搜索 */
    private static final String TPL_3 =
            "-- ============================\n"
            + "--  数值搜索\n"
            + "-- ============================\n"
            + "\n"
            + "function Search()\n"
            + "  local value = gg.prompt({\"请输入要搜索的数值\"}, {[1] = 0}, {[1] = \"number\"})\n"
            + "  if value == nil then\n"
            + "    return\n"
            + "  end\n"
            + "\n"
            + "  local num = value[1]\n"
            + "  gg.clearResults()\n"
            + "  gg.searchNumber(num, gg.TYPE_DWORD)\n"
            + "\n"
            + "  local count = gg.getResultCount()\n"
            + "  print(\"搜索到 \" .. count .. \" 个结果\")\n"
            + "\n"
            + "  if count == 0 then\n"
            + "    print(\"没有找到匹配结果\")\n"
            + "    return\n"
            + "  end\n"
            + "\n"
            + "  local results = gg.getResults(count)\n"
            + "  for i = 1, #results do\n"
            + "    print(string.format(\"地址: %X  值: %s\", results[i].address, tostring(results[i].value)))\n"
            + "  end\n"
            + "end\n"
            + "\n"
            + "Search()\n";

    /** 模板 4：结果编辑 */
    private static final String TPL_4 =
            "-- ============================\n"
            + "--  结果编辑\n"
            + "-- ============================\n"
            + "\n"
            + "function EditAll(newValue)\n"
            + "  gg.clearResults()\n"
            + "  gg.searchNumber(\"0\", gg.TYPE_DWORD)\n"
            + "\n"
            + "  local count = gg.getResultCount()\n"
            + "  if count == 0 then\n"
            + "    print(\"没有可编辑的结果\")\n"
            + "    return false\n"
            + "  end\n"
            + "\n"
            + "  local results = gg.getResults(count)\n"
            + "  local edit = {}\n"
            + "\n"
            + "  for i = 1, #results do\n"
            + "    edit[i] = {}\n"
            + "    edit[i].address = results[i].address\n"
            + "    edit[i].flags = results[i].flags\n"
            + "    edit[i].value = newValue\n"
            + "  end\n"
            + "\n"
            + "  gg.setValues(edit)\n"
            + "  print(\"已修改 \" .. #edit .. \" 个结果\")\n"
            + "  return true\n"
            + "end\n"
            + "\n"
            + "local ok = EditAll(9999)\n"
            + "if ok then\n"
            + "  print(\"修改成功\")\n"
            + "else\n"
            + "  print(\"修改失败\")\n"
            + "end\n";

    /** 模板 5：配置存取 */
    private static final String TPL_5 =
            "-- ============================\n"
            + "--  配置存取\n"
            + "-- ============================\n"
            + "\n"
            + "local CONFIG_PATH = gg.getFile() .. \".cfg\"\n"
            + "\n"
            + "function SaveConfig(cfg)\n"
            + "  local f = io.open(CONFIG_PATH, \"w\")\n"
            + "  if f == nil then\n"
            + "    print(\"无法写入配置文件\")\n"
            + "    return false\n"
            + "  end\n"
            + "\n"
            + "  for k, v in pairs(cfg) do\n"
            + "    f:write(k .. \"=\" .. tostring(v) .. \"\\n\")\n"
            + "  end\n"
            + "\n"
            + "  f:close()\n"
            + "  return true\n"
            + "end\n"
            + "\n"
            + "function LoadConfig()\n"
            + "  local cfg = {}\n"
            + "  local f = io.open(CONFIG_PATH, \"r\")\n"
            + "  if f == nil then\n"
            + "    return cfg\n"
            + "  end\n"
            + "\n"
            + "  for line in f:lines() do\n"
            + "    local pos = string.find(line, \"=\")\n"
            + "    if pos ~= nil then\n"
            + "      local k = string.sub(line, 1, pos - 1)\n"
            + "      local v = string.sub(line, pos + 1)\n"
            + "      cfg[k] = v\n"
            + "    end\n"
            + "  end\n"
            + "\n"
            + "  f:close()\n"
            + "  return cfg\n"
            + "end\n"
            + "\n"
            + "local cfg = LoadConfig()\n"
            + "cfg[\"count\"] = (cfg[\"count\"] or 0)\n"
            + "print(\"当前计数: \" .. cfg[\"count\"])\n"
            + "SaveConfig(cfg)\n";

    /** 模板 6：工具函数集 */
    private static final String TPL_6 =
            "-- ============================\n"
            + "--  常用工具函数\n"
            + "-- ============================\n"
            + "\n"
            + "-- 安全调用：出错不崩溃，返回错误信息\n"
            + "function TryCall(fn, ...)\n"
            + "  local ok, err = pcall(fn, ...)\n"
            + "  if ok == false then\n"
            + "    print(\"调用失败: \" .. tostring(err))\n"
            + "    return nil\n"
            + "  end\n"
            + "  return err\n"
            + "end\n"
            + "\n"
            + "-- 拆分字符串\n"
            + "function Split(str, sep)\n"
            + "  local parts = {}\n"
            + "  local pattern = \"([^\" .. sep .. \"]+)\"\n"
            + "  for part in string.gmatch(str, pattern) do\n"
            + "    parts[#parts + 1] = part\n"
            + "  end\n"
            + "  return parts\n"
            + "end\n"
            + "\n"
            + "-- 判断表中是否包含某值\n"
            + "function Contains(list, value)\n"
            + "  for i = 1, #list do\n"
            + "    if list[i] == value then\n"
            + "      return true\n"
            + "    end\n"
            + "  end\n"
            + "  return false\n"
            + "end\n"
            + "\n"
            + "-- 睡眠指定秒数\n"
            + "function Sleep(sec)\n"
            + "  local start = os.time()\n"
            + "  while os.time() - start < sec do\n"
            + "    gg.sleep(100)\n"
            + "  end\n"
            + "end\n"
            + "\n"
            + "-- 示例\n"
            + "local items = Split(\"a,b,c\", \",\")\n"
            + "print(\"拆分出 \" .. #items .. \" 项\")\n"
            + "\n"
            + "if Contains(items, \"b\") then\n"
            + "  print(\"包含 b\")\n"
            + "end\n";

    /** 模板列表（顺序即展示顺序） */
    public static Template[] all() {
        return new Template[]{
                new Template(R.string.tpl_1_name, R.string.tpl_1_desc, TPL_1),
                new Template(R.string.tpl_2_name, R.string.tpl_2_desc, TPL_2),
                new Template(R.string.tpl_3_name, R.string.tpl_3_desc, TPL_3),
                new Template(R.string.tpl_4_name, R.string.tpl_4_desc, TPL_4),
                new Template(R.string.tpl_5_name, R.string.tpl_5_desc, TPL_5),
                new Template(R.string.tpl_6_name, R.string.tpl_6_desc, TPL_6)
        };
    }
}
