package com.modace.ctmod;

import android.widget.LinearLayout;

import com.modace.ctmod.util.DeviceInfo;
import com.modace.ctmod.util.FormatUtil;

/** 设置页：展示设备与版本信息 */
public class SettingsActivity extends BaseModuleActivity {

    @Override
    protected String getTitleText() {
        return getString(R.string.title_settings);
    }

    @Override
    protected void buildContent(LinearLayout container) {
        addSectionTitle(container, "设备信息");
        addCard(container, "机型",
                DeviceInfo.getManufacturer() + " " + DeviceInfo.getDeviceModel());
        addCard(container, "系统版本", DeviceInfo.getSystemVersion());
        addCard(container, "CPU 核心数", String.valueOf(DeviceInfo.getCpuCores()));

        long memTotal = DeviceInfo.getTotalMemory();
        long memAvail = DeviceInfo.getAvailMemory(this);
        addCard(container, "运行内存",
                FormatUtil.formatUsedTotal(memTotal, memAvail));

        long[] store = DeviceInfo.getStorage();
        addCard(container, "内部存储",
                FormatUtil.formatUsedTotal(store[0], store[1]));

        addSectionTitle(container, "关于本应用");
        addCard(container, "版本", "v1.0 (versionCode 1)");
        addCard(container, "包名", getPackageName());
        addCard(container, "隐私",
                "本应用不声明 INTERNET 权限，所有运算在本地完成，无后台唤醒、无数据统计。");
    }
}
