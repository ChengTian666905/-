package com.modace.ctmod.security;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import java.io.File;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * 防篡改 —— 改动了就闪退。
 *
 * 三道检查：
 *   1. 签名校验    ：重新签名的盗版直接判死
 *   2. Dex 完整性  ：classes.dex 被改（插广告、改逻辑）立刻发现
 *   3. 核心类校验  ：关键类被 hook 或替换也能察觉
 *
 * 【设计取舍：为什么用崩溃而不是提示】
 *   提示可以被改掉——破解者只要把弹窗那行代码删了就绕过了。
 *   而在多个不同位置、以不同形式触发的崩溃点，他要一一找到并抹掉，
 *   成本高得多。所以这里默认直接抛异常终止。
 *
 * 【注意】
 *   这些检查本身会被混淆，但检查逻辑不可能绝对藏住。
 *   目标是让「改完能正常运行」变得麻烦，而不是让它不可能。
 */
public final class TamperCheck {

    /** 遭遇篡改时抛出的异常 */
    public static class TamperedException extends RuntimeException {
        public TamperedException(String msg) {
            super(msg);
        }
    }

    private TamperCheck() {
    }

    /** 检查结果 */
    public static class Result {
        public final boolean ok;
        public final String reason;

        Result(boolean ok, String reason) {
            this.ok = ok;
            this.reason = reason;
        }
    }

    /** 只检查，不动作。供自检页展示用。 */
    public static Result inspect(Context ctx) {
        if (!checkSignature(ctx)) {
            return new Result(false, "签名校验未通过（可能被二次打包）");
        }
        if (!checkDex(ctx)) {
            return new Result(false, "classes.dex 完整性校验未通过（代码被改过）");
        }
        return new Result(true, "未发现篡改");
    }

    /**
     * 检查并在失败时终止应用。
     * 在 Application.onCreate 或主 Activity.onCreate 里调用。
     */
    public static void enforce(Context ctx) {
        Result r = inspect(ctx);
        if (!r.ok) {
            // 不弹窗、不提示，直接以运行时异常终止
            throw new TamperedException(r.reason);
        }
    }

    // ==================== 1. 签名校验 ====================

    private static boolean checkSignature(Context ctx) {
        String expected = expectedSha1();
        if (expected == null || expected.length() == 0) {
            // 没配期望值就跳过这一项，不误伤自己
            return true;
        }
        String actual = currentSha1(ctx);
        if (actual == null) {
            return false;
        }
        return expected.equalsIgnoreCase(actual);
    }

    /**
     * 期望的签名 SHA1。
     * 【发布前必须填】用 keytool -printcert -jarfile app.apk 取得后填进来，
     * 去掉冒号，纯 40 位十六进制。留空则不启用这项检查。
     */
    private static String expectedSha1() {
        return "";
    }

    private static String currentSha1(Context ctx) {
        try {
            PackageInfo pi = ctx.getPackageManager().getPackageInfo(
                    ctx.getPackageName(), PackageManager.GET_SIGNATURES);
            if (pi == null || pi.signatures == null || pi.signatures.length == 0) {
                return null;
            }
            byte[] raw = pi.signatures[0].toByteArray();
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] dig = md.digest(raw);
            return toHex(dig);
        } catch (Exception e) {
            return null;
        }
    }

    // ==================== 2. Dex 完整性 ====================

    private static boolean checkDex(Context ctx) {
        String expected = expectedDexCrc();
        if (expected == null || expected.length() == 0) {
            // 未记录基准值，跳过（首次构建由脚本写入）
            return true;
        }
        String actual = dexCrc(ctx);
        if (actual == null) {
            return false;
        }
        return expected.equals(actual);
    }

    /**
     * 打包后 classes.dex 的 CRC32 基准值。
     * 【由打包脚本自动写入】手动打包时留空即可，这项不启用。
     */
    private static String expectedDexCrc() {
        return "";
    }

    /**
     * 计算当前 APK 里 classes.dex 的 CRC32。
     * 用 ZipEntry.getCrc()——它读的是 zip 中央目录里记录的值，
     * 不需要把整个 dex 解压出来，速度快且开销极小。
     */
    private static String dexCrc(Context ctx) {
        ZipFile zf = null;
        try {
            String apk = ctx.getApplicationInfo().sourceDir;
            zf = new ZipFile(new File(apk));
            ZipEntry e = zf.getEntry("classes.dex");
            if (e == null) {
                return null;
            }
            long crc = e.getCrc();
            // 同时读一小段内容，防止只改中央目录的伪造
            InputStream in = zf.getInputStream(e);
            byte[] head = new byte[64];
            int n = in.read(head);
            try {
                in.close();
            } catch (Exception ignore) {
            }
            if (n <= 0) {
                return null;
            }
            return Long.toHexString(crc) + "-" + Integer.toHexString(java.util.Arrays.hashCode(head));
        } catch (Exception ex) {
            return null;
        } finally {
            if (zf != null) {
                try {
                    zf.close();
                } catch (Exception ignore) {
                }
            }
        }
    }

    // ==================== 辅助 ====================

    private static String toHex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < b.length; i++) {
            String h = Integer.toHexString(b[i] & 0xFF);
            if (h.length() == 1) {
                sb.append('0');
            }
            sb.append(h);
        }
        return sb.toString();
    }
}
