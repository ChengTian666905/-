package com.modace.ctmod.util;

/**
 * 通用格式化工具。全部为 Java 6 语法，避免旧 Gradle 因源码级别报错。
 */
public final class FormatUtil {

    private static final String[] UNITS = {"B", "KB", "MB", "GB", "TB"};

    private FormatUtil() {
    }

    /** 字节 -> 可读大小 */
    public static String formatSize(long bytes) {
        if (bytes <= 0) {
            return "0 B";
        }
        double value = bytes;
        int index = 0;
        while (value >= 1024 && index < UNITS.length - 1) {
            value = value / 1024;
            index++;
        }
        if (index == 0) {
            return ((long) value) + " " + UNITS[index];
        }
        if (value >= 100) {
            return String.format("%.0f %s", value, UNITS[index]);
        }
        return String.format("%.1f %s", value, UNITS[index]);
    }

    /** "已用 / 总量" */
    public static String formatUsedTotal(long total, long avail) {
        if (total <= 0) {
            return "--";
        }
        long used = total - avail;
        if (used < 0) {
            used = 0;
        }
        return formatSize(used) + " / " + formatSize(total);
    }

    /** 占用百分比 0-100 */
    public static int percent(long total, long avail) {
        if (total <= 0) {
            return 0;
        }
        long used = total - avail;
        if (used < 0) {
            used = 0;
        }
        int p = (int) (used * 100L / total);
        if (p < 0) {
            p = 0;
        }
        if (p > 100) {
            p = 100;
        }
        return p;
    }

    /** 字节数组转十六进制 */
    public static String toHex(byte[] data) {
        if (data == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(data.length * 2);
        for (int i = 0; i < data.length; i++) {
            String h = Integer.toHexString(data[i] & 0xFF);
            if (h.length() == 1) {
                sb.append('0');
            }
            sb.append(h);
        }
        return sb.toString();
    }
}
