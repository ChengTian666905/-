package com.modace.ctmod.lua;

import android.util.Base64;

/**
 * Lua 脚本加密核心。
 *
 * 三种模式，Java 侧与生成的 Lua Loader 侧算法严格对称：
 *   MODE_LIGHT  = 0  RC4 流加密 + Base64          —— Lua 5.1 通用，无位运算依赖
 *   MODE_STRONG = 1  RC4 + 字节置换 + 校验和 + 随机填充 —— Lua 5.1 通用
 *   MODE_XXTEA  = 2  XXTEA 分组加密 + Base64       —— 需 Lua 5.3+ 或 bit32/bit 库
 *
 * 【重要说明】
 * Lua 是解释型语言，运行时必须拿到明文，因此任何 Lua 加密本质上
 * 都属于「混淆级」保护：可防直接阅读、防随手篡改，
 * 无法对抗专业逆向。请勿用它保护真正的高价值密钥。
 */
public final class LuaCipher {

    public static final int MODE_LIGHT = 0;
    public static final int MODE_STRONG = 1;
    public static final int MODE_XXTEA = 2;

    private LuaCipher() {
    }

    // ==================== 对外接口 ====================

    /** 加密明文字节，返回 Base64 字符串 */
    public static String encrypt(int mode, String key, byte[] plain) {
        if (plain == null || key == null || key.length() == 0) {
            return null;
        }
        byte[] body;
        if (mode == MODE_LIGHT) {
            body = rc4(key.getBytes(), plain);
        } else if (mode == MODE_STRONG) {
            body = strongEncrypt(key.getBytes(), plain);
        } else {
            body = xxteaEncrypt(padKey16(key.getBytes()), plain);
        }
        if (body == null) {
            return null;
        }
        return Base64.encodeToString(body, Base64.NO_WRAP);
    }

    /** 解密 Base64 字符串，返回明文字节；失败返回 null */
    public static byte[] decrypt(int mode, String key, String b64) {
        if (b64 == null || key == null || key.length() == 0) {
            return null;
        }
        byte[] body = Base64.decode(b64, Base64.DEFAULT);
        if (mode == MODE_LIGHT) {
            return rc4(key.getBytes(), body);
        } else if (mode == MODE_STRONG) {
            return strongDecrypt(key.getBytes(), body);
        } else {
            return xxteaDecrypt(padKey16(key.getBytes()), body);
        }
    }

    /** 生成随机密钥（16 位大小写字母数字） */
    public static String randomKey() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder(16);
        for (int i = 0; i < 16; i++) {
            int idx = (int) (Math.random() * chars.length());
            if (idx >= chars.length()) {
                idx = chars.length() - 1;
            }
            sb.append(chars.charAt(idx));
        }
        return sb.toString();
    }

    // ==================== RC4 ====================

    /** RC4 对称加密/解密（同一函数） */
    public static byte[] rc4(byte[] key, byte[] data) {
        if (key == null || key.length == 0 || data == null) {
            return null;
        }
        int[] s = new int[256];
        for (int i = 0; i < 256; i++) {
            s[i] = i;
        }
        int j = 0;
        for (int i = 0; i < 256; i++) {
            j = (j + s[i] + (key[i % key.length] & 0xFF)) & 0xFF;
            int t = s[i];
            s[i] = s[j];
            s[j] = t;
        }
        byte[] out = new byte[data.length];
        int i = 0;
        j = 0;
        for (int n = 0; n < data.length; n++) {
            i = (i + 1) & 0xFF;
            j = (j + s[i]) & 0xFF;
            int t = s[i];
            s[i] = s[j];
            s[j] = t;
            int k = s[(s[i] + s[j]) & 0xFF];
            out[n] = (byte) ((data[n] & 0xFF) ^ k);
        }
        return out;
    }

    // ==================== 增强模式 ====================

    /** 明文 -> [1B padding长度][随机填充][4B 校验和][置换后数据] -> RC4 */
    private static byte[] strongEncrypt(byte[] key, byte[] plain) {
        long chk = checksum(plain);
        int padLen = 1 + (int) (Math.random() * 16); // 1..16
        byte[] buf = new byte[1 + padLen + 4 + plain.length];
        buf[0] = (byte) padLen;
        for (int i = 0; i < padLen; i++) {
            buf[1 + i] = (byte) (int) (Math.random() * 256);
        }
        int off = 1 + padLen;
        buf[off] = (byte) ((chk >>> 24) & 0xFF);
        buf[off + 1] = (byte) ((chk >>> 16) & 0xFF);
        buf[off + 2] = (byte) ((chk >>> 8) & 0xFF);
        buf[off + 3] = (byte) (chk & 0xFF);
        int[] box = buildBox(key);
        for (int i = 0; i < plain.length; i++) {
            buf[off + 4 + i] = (byte) box[plain[i] & 0xFF];
        }
        return rc4(key, buf);
    }

    /** RC4 -> 去填充 -> 校验 -> 逆置换 */
    private static byte[] strongDecrypt(byte[] key, byte[] body) {
        byte[] buf = rc4(key, body);
        if (buf == null || buf.length < 6) {
            return null;
        }
        int padLen = buf[0] & 0xFF;
        int off = 1 + padLen;
        if (padLen < 1 || buf.length < off + 4) {
            return null;
        }
        long chk = ((long) (buf[off] & 0xFF) << 24)
                | ((long) (buf[off + 1] & 0xFF) << 16)
                | ((long) (buf[off + 2] & 0xFF) << 8)
                | (long) (buf[off + 3] & 0xFF);
        int dataLen = buf.length - off - 4;
        byte[] out = new byte[dataLen];
        int[] inv = buildInvBox(key);
        for (int i = 0; i < dataLen; i++) {
            out[i] = (byte) inv[buf[off + 4 + i] & 0xFF];
        }
        if (checksum(out) != (chk & 0xFFFFFFFFL)) {
            return null; // 校验失败，密钥不对或文件被篡改
        }
        return out;
    }

    /** 简单字节累加校验和（Lua 端可用纯算术实现，无需位运算） */
    private static long checksum(byte[] data) {
        long sum = 0L;
        for (int i = 0; i < data.length; i++) {
            sum = (sum + (data[i] & 0xFF)) & 0xFFFFFFFFL;
        }
        return sum;
    }

    /** 由密钥派生置换表（0-based 值域 0..255） */
    private static int[] buildBox(byte[] key) {
        int[] box = new int[256];
        for (int i = 0; i < 256; i++) {
            box[i] = i;
        }
        int j = 0;
        for (int i = 0; i < 256; i++) {
            j = (j + box[i] + ((key[i % key.length] & 0xFF) * 31)) & 0xFF;
            int t = box[i];
            box[i] = box[j];
            box[j] = t;
        }
        return box;
    }

    private static int[] buildInvBox(byte[] key) {
        int[] box = buildBox(key);
        int[] inv = new int[256];
        for (int i = 0; i < 256; i++) {
            inv[box[i]] = i;
        }
        return inv;
    }

    // ==================== XXTEA ====================

    private static final int DELTA = 0x9E3779B9;

    private static byte[] padKey16(byte[] key) {
        byte[] k = new byte[16];
        for (int i = 0; i < 16; i++) {
            k[i] = key[i % key.length];
        }
        return k;
    }

    public static byte[] xxteaEncrypt(byte[] key, byte[] data) {
        if (data.length == 0) {
            return new byte[0];
        }
        int[] v = toIntArray(data, true);
        int[] k = toIntArray(key, false);
        int n = v.length - 1;
        if (n < 1) {
            return data;
        }
        int y = v[0];
        int z = v[n];
        int sum = 0;
        int q = 6 + 52 / (n + 1);
        while (q-- > 0) {
            sum = sum + DELTA;
            int e = (sum >>> 2) & 3;
            for (int p = 0; p < n; p++) {
                y = v[p + 1];
                z = v[p] = v[p] + mx(sum, y, z, p, e, k);
            }
            y = v[0];
            z = v[n] = v[n] + mx(sum, y, z, n, e, k);
        }
        return toByteArray(v, false);
    }

    public static byte[] xxteaDecrypt(byte[] key, byte[] data) {
        if (data.length == 0) {
            return new byte[0];
        }
        int[] v = toIntArray(data, false);
        int[] k = toIntArray(key, false);
        int n = v.length - 1;
        if (n < 1) {
            return data;
        }
        int y = v[0];
        int z = v[n];
        int q = 6 + 52 / (n + 1);
        int sum = q * DELTA;
        while (sum != 0) {
            int e = (sum >>> 2) & 3;
            for (int p = n; p > 0; p--) {
                z = v[p - 1];
                y = v[p] = v[p] - mx(sum, y, z, p, e, k);
            }
            z = v[n];
            y = v[0] = v[0] - mx(sum, y, z, 0, e, k);
            sum = sum - DELTA;
        }
        return toByteArray(v, true);
    }

    private static int mx(int sum, int y, int z, int p, int e, int[] k) {
        return (((z >>> 5) ^ (y << 2)) + ((y >>> 3) ^ (z << 4)))
                ^ ((sum ^ y) + (k[(p & 3) ^ e] ^ z));
    }

    private static int[] toIntArray(byte[] data, boolean includeLength) {
        int n = ((data.length & 3) == 0)
                ? (data.length >>> 2)
                : ((data.length >>> 2) + 1);
        int[] result;
        if (includeLength) {
            result = new int[n + 1];
            result[n] = data.length;
        } else {
            result = new int[n];
        }
        for (int i = 0; i < data.length; i++) {
            result[i >>> 2] |= (0x000000FF & data[i]) << ((i & 3) << 3);
        }
        return result;
    }

    private static byte[] toByteArray(int[] v, boolean includeLength) {
        int n = v.length << 2;
        if (includeLength) {
            int m = v[v.length - 1];
            n = m;
        }
        byte[] result = new byte[n];
        for (int i = 0; i < n; i++) {
            result[i] = (byte) ((v[i >>> 2] >>> ((i & 3) << 3)) & 0xFF);
        }
        return result;
    }
}
