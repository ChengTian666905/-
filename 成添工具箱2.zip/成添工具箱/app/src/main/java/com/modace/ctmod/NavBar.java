package com.modace.ctmod;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;

/**
 * 底部三按钮导航 —— 主页 / 版本 / 开发信息。
 *
 * 用法：在页面的 onCreate 末尾调用
 *     NavBar.bind(this, NavBar.TAB_HOME);
 * 当前所在页会自动高亮，点击其他页会跳转。
 */
public final class NavBar {

    public static final int TAB_HOME = 0;
    public static final int TAB_VERSION = 1;
    public static final int TAB_DEV = 2;

    private NavBar() {
    }

    /** 绑定底栏：设置高亮 + 点击跳转 */
    public static void bind(final Activity activity, int current) {
        TextView home = (TextView) activity.findViewById(R.id.btn_nav_home);
        TextView version = (TextView) activity.findViewById(R.id.btn_nav_version);
        TextView dev = (TextView) activity.findViewById(R.id.btn_nav_dev);
        if (home == null || version == null || dev == null) {
            return; // 该页面没放底栏，直接跳过
        }

        highlight(activity, home, current == TAB_HOME);
        highlight(activity, version, current == TAB_VERSION);
        highlight(activity, dev, current == TAB_DEV);

        home.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                go(activity, MainActivity.class, MainActivity.class);
            }
        });
        version.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                go(activity, VersionActivity.class, MainActivity.class);
            }
        });
        dev.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                go(activity, DevInfoActivity.class, MainActivity.class);
            }
        });
    }

    /** 当前页高亮（青底深字），其余页普通卡片样式 */
    private static void highlight(Activity activity, TextView tv, boolean current) {
        if (current) {
            tv.setBackgroundResource(R.drawable.bg_tab_selected);
            tv.setTextColor(0xFF10221E);
            tv.setTypeface(null, android.graphics.Typeface.BOLD);
        } else {
            tv.setBackgroundResource(R.drawable.bg_card);
            tv.setTextColor(activity.getResources().getColor(R.color.text_secondary));
            tv.setTypeface(null, android.graphics.Typeface.NORMAL);
        }
    }

    /**
     * 跳转。已在目标页则不做处理，避免自己跳自己造成栈堆积。
     * 回主页时用 CLEAR_TOP，保证栈里只留一个主页面实例。
     */
    private static void go(Activity activity, Class<?> target, Class<?> homeClass) {
        if (activity.getClass().equals(target)) {
            return;
        }
        Intent intent = new Intent(activity, target);
        if (target.equals(homeClass)) {
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        }
        activity.startActivity(intent);
    }
}
