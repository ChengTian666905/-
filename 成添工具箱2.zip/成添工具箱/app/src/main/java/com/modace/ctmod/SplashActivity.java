package com.modace.ctmod;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.modace.ctmod.security.Guard;

/**
 * 启动闪屏页 —— 纯代码构建 UI，不依赖任何新增 XML 资源。
 *
 * 为什么不写 XML：
 *   部分手机上 AIDE 解压新文件后 R.java 不会立刻重建，
 *   导致 R.layout.xxx / R.id.xxx 报 unknown member。
 *   本文件只用代码创建控件，规避该问题。
 *
 * 依赖：仅使用 colors.xml 中已有的 bg_window / text_primary / text_hint。
 */
public class SplashActivity extends Activity {

    /** 闪屏停留时长（毫秒）—— 刻意做短，工具类应用拖 3 秒只会招骂 */
    private static final long DELAY = 1200L;
    /** 淡入动画时长（毫秒） */
    private static final long FADE = 550L;

    private final Handler handler = new Handler();

    /** 延时任务单独提出来，便于在 onDestroy 里取消，避免 Activity 重建后重复跳转 */
    private final Runnable goMain = new Runnable() {
        public void run() {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish();
            // 去掉过场动画，避免闪屏页退出时又黑一下
            overridePendingTransition(0, 0);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*
         * 加固自检：必须最早执行，且早于 setContentView。
         * 检测到被篡改（重签名 / 改 dex）会直接抛异常终止，
         * 此时界面还没渲染，盗版看到的是直接闪退而不是界面闪一下再消失。
         */
        Guard.boot(this);

        // 统一跟随用户的横竖屏设置，必须早于 setContentView
        OrientUtil.apply(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(getResources().getColor(R.color.bg_window));

        // 顶部弹性留白，让 logo 视觉上居中偏上
        View topSpace = new View(this);
        root.addView(topSpace, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        // 圆形渐变 Logo（代码绘制，替代 bg_logo_circle.xml）
        TextView logo = new TextView(this);
        logo.setText("CT");
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(34);
        logo.setTypeface(null, android.graphics.Typeface.BOLD);
        logo.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFFA97BFF, 0xFF4B2E86});
        circle.setShape(GradientDrawable.OVAL);
        logo.setBackgroundDrawable(circle);
        int logoSize = dp(88);
        root.addView(logo, new LinearLayout.LayoutParams(logoSize, logoSize));

        // 应用名
        TextView title = new TextView(this);
        title.setText(getString(R.string.app_name));
        title.setTextColor(getResources().getColor(R.color.text_primary));
        title.setTextSize(24);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        titleLp.setMargins(0, dp(20), 0, 0);
        root.addView(title, titleLp);

        // 副标题
        TextView subtitle = new TextView(this);
        subtitle.setText(getString(R.string.app_subtitle));
        subtitle.setTextColor(getResources().getColor(R.color.text_hint));
        subtitle.setTextSize(12);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        subLp.setMargins(0, dp(8), 0, 0);
        root.addView(subtitle, subLp);

        // 底部弹性留白
        View bottomSpace = new View(this);
        root.addView(bottomSpace, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        // 底部版本标注
        TextView footer = new TextView(this);
        footer.setText("v1.0 · 本地运行 · 不联网");
        footer.setTextColor(getResources().getColor(R.color.text_hint));
        footer.setTextSize(11);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        footLp.setMargins(0, 0, 0, dp(26));
        root.addView(footer, footLp);

        setContentView(root);

        // 淡入
        AlphaAnimation fade = new AlphaAnimation(0.0f, 1.0f);
        fade.setDuration(FADE);
        root.startAnimation(fade);

        handler.postDelayed(goMain, DELAY);
    }

    /**
     * 方向切换会导致 Activity 重建，这里必须取消未执行的跳转任务，
     * 否则旧实例的任务仍会触发，导致主界面被启动两次。
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(goMain);
    }

    /** 闪屏期间按返回直接退出，不回主界面 */
    @Override
    public void onBackPressed() {
        finish();
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (value * density + 0.5f);
    }
}
