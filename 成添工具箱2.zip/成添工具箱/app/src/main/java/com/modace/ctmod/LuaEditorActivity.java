package com.modace.ctmod;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.Spanned;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.modace.ctmod.lua.LuaChecker;
import com.modace.ctmod.lua.LuaTemplates;
import com.modace.ctmod.util.FileUtil;
import com.modace.ctmod.util.WaveLineSpan;

import java.io.File;
import java.util.List;

/**
 * Lua 编写器 —— 带行号、功能模板、实时语法检查。
 *
 * 三个核心能力：
 *   1. 左侧行号：随内容实时重算，与代码区等宽字体对齐
 *   2. 右上角「+」：弹出六个功能模板，一键插入
 *   3. 实时检查：停止输入 600ms 后自动扫描，错误显示在下方面板
 *
 * 【诚实说明】这里的语法检查是启发式的静态扫描，
 *   能抓括号不配对、块结构缺失、字符串未闭合这类手滑错误，
 *   不是完整的 Lua 解析器，不保证 100% 准确。
 */
public class LuaEditorActivity extends Activity implements View.OnClickListener {

    private EditText etCode;
    private TextView tvLineNumbers;
    private TextView tvStatus;
    private TextView tvError;
    private TextView tvErrFlag;
    private TextView tvHint;
    private LinearLayout hintPanel;
    private LinearLayout errorPanel;
    private ScrollView editorScroll;

    /*
     * 加波浪线时会改动 EditText 内容，从而再次触发 TextWatcher，
     * 不拦住就会无限递归。用这个标志在改 span 期间屏蔽监听。
     */
    private boolean applyingSpan = false;

    private final Handler handler = new Handler();

    /** 实时检查的防抖延迟：太快会每敲一个字就扫描一次，卡顿且结果乱跳 */
    private static final long CHECK_DELAY = 600L;

    private final Runnable checkTask = new Runnable() {
        public void run() {
            runCheck();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        OrientUtil.apply(this);
        setContentView(R.layout.activity_lua_editor);

        etCode = (EditText) findViewById(R.id.et_code);
        tvLineNumbers = (TextView) findViewById(R.id.tv_line_numbers);
        tvStatus = (TextView) findViewById(R.id.tv_status);
        tvError = (TextView) findViewById(R.id.tv_error);
        tvErrFlag = (TextView) findViewById(R.id.tv_err_flag);
        tvHint = (TextView) findViewById(R.id.tv_hint);
        hintPanel = (LinearLayout) findViewById(R.id.hint_panel);
        errorPanel = (LinearLayout) findViewById(R.id.error_panel);
        editorScroll = (ScrollView) findViewById(R.id.editor_scroll);

        findViewById(R.id.btn_back).setOnClickListener(this);
        findViewById(R.id.btn_add).setOnClickListener(this);
        findViewById(R.id.btn_check).setOnClickListener(this);
        findViewById(R.id.btn_save).setOnClickListener(this);

        etCode.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            public void afterTextChanged(Editable s) {
                // 加波浪线时会改文本，若不屏蔽会递归触发本回调
                if (applyingSpan) {
                    return;
                }
                updateLineNumbers();
                updateStatus();
                // 防抖：先取消上一次待执行的检查，再重新排队
                handler.removeCallbacks(checkTask);
                handler.postDelayed(checkTask, CHECK_DELAY);
            }
        });

        updateLineNumbers();
        updateStatus();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(checkTask);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btn_back) {
            finish();
            return;
        }
        if (id == R.id.btn_add) {
            showTemplateDialog();
            return;
        }
        if (id == R.id.btn_check) {
            runCheck();
            toastWithResult();
            return;
        }
        if (id == R.id.btn_save) {
            saveFile();
            return;
        }
    }

    // ==================== 行号 ====================

    /** 根据当前行数重绘左侧行号 */
    private void updateLineNumbers() {
        int lines = countLines(etCode.getText().toString());
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= lines; i++) {
            sb.append(i);
            if (i < lines) {
                sb.append('\n');
            }
        }
        tvLineNumbers.setText(sb.toString());
    }

    private int countLines(String text) {
        if (text == null || text.length() == 0) {
            return 1;
        }
        int n = 1;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '\n') {
                n++;
            }
        }
        return n;
    }

    // ==================== 状态行：行 / 列 / 总行数 ====================

    private void updateStatus() {
        String text = etCode.getText().toString();
        int pos = etCode.getSelectionStart();
        if (pos < 0) {
            pos = 0;
        }
        if (pos > text.length()) {
            pos = text.length();
        }
        int line = 1;
        int col = 1;
        for (int i = 0; i < pos; i++) {
            if (text.charAt(i) == '\n') {
                line++;
                col = 1;
            } else {
                col++;
            }
        }
        tvStatus.setText(getString(R.string.editor_status_line, line, col, countLines(text)));
    }

    // ==================== 语法检查 ====================

    /** 执行检查：顶部「成添提示」+ 代码下方红色波浪线 + 底部详细列表 */
    private void runCheck() {
        String code = etCode.getText().toString();
        if (code.trim().length() == 0) {
            hintPanel.setVisibility(View.GONE);
            errorPanel.setVisibility(View.GONE);
            tvErrFlag.setVisibility(View.GONE);
            clearErrorSpans();
            return;
        }

        List<LuaChecker.Issue> issues = LuaChecker.check(code);

        if (issues.isEmpty()) {
            // 通过：绿色提示，清掉所有波浪线
            hintPanel.setVisibility(View.VISIBLE);
            tvHint.setTextColor(getResources().getColor(R.color.accent_cyan));
            tvHint.setText(getString(R.string.editor_tip_ok));
            errorPanel.setVisibility(View.VISIBLE);
            tvError.setTextColor(getResources().getColor(R.color.accent_cyan));
            tvError.setText(getString(R.string.editor_no_error));
            tvErrFlag.setVisibility(View.GONE);
            clearErrorSpans();
            return;
        }

        // ---- 顶部提示：取第一条错误，格式为「成添提示:(代码)错误！原因:(原因)」 ----
        LuaChecker.Issue first = issues.get(0);
        String snippet = trimCode(first.lineText);
        String tip = getString(R.string.editor_tip_format, snippet, first.message);
        if (issues.size() > 1) {
            tip = tip + getString(R.string.editor_tip_more, issues.size() - 1);
        }
        hintPanel.setVisibility(View.VISIBLE);
        tvHint.setTextColor(getResources().getColor(R.color.accent_red));
        tvHint.setText(tip);

        // ---- 底部详细列表 ----
        errorPanel.setVisibility(View.VISIBLE);
        tvError.setTextColor(getResources().getColor(R.color.accent_red));
        tvError.setText(LuaChecker.format(issues));
        tvErrFlag.setVisibility(View.VISIBLE);
        tvErrFlag.setText(String.valueOf(issues.size()));

        // ---- 代码下方红色波浪线 ----
        applyErrorSpans(code, issues);
    }

    /** 清空所有波浪线 */
    private void clearErrorSpans() {
        applyingSpan = true;
        Editable e = etCode.getText();
        WaveLineSpan[] olds = e.getSpans(0, e.length(), WaveLineSpan.class);
        for (int i = 0; i < olds.length; i++) {
            e.removeSpan(olds[i]);
        }
        applyingSpan = false;
    }

    /** 给每个出错行加红色波浪线 */
    private void applyErrorSpans(String code, List<LuaChecker.Issue> issues) {
        applyingSpan = true;
        try {
            Editable e = etCode.getText();

            // 先清旧的，避免残留
            WaveLineSpan[] olds = e.getSpans(0, e.length(), WaveLineSpan.class);
            for (int i = 0; i < olds.length; i++) {
                e.removeSpan(olds[i]);
            }

            int color = getResources().getColor(R.color.accent_red);
            float wave = dp(3);
            float period = dp(6);
            float stroke = dp(1);

            for (int i = 0; i < issues.size(); i++) {
                int[] range = LuaChecker.lineRange(code, issues.get(i).line);
                int s = range[0];
                int t = range[1];
                if (t <= s || s < 0 || t > e.length()) {
                    continue; // 空行或越界，跳过
                }
                e.setSpan(new WaveLineSpan(color, wave, period, stroke),
                        s, t, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        } finally {
            applyingSpan = false;
        }
    }

    /** 提示里的代码片段做截断，避免一行超长把提示条撑爆 */
    private String trimCode(String text) {
        if (text == null) {
            return "";
        }
        String s = text.trim();
        if (s.length() > 24) {
            return s.substring(0, 24) + "…";
        }
        if (s.length() == 0) {
            return "空行";
        }
        return s;
    }

    /** 手动点「检查语法」时给个明确反馈 */
    private void toastWithResult() {
        String code = etCode.getText().toString();
        if (code.trim().length() == 0) {
            toast(getString(R.string.editor_empty_hint));
            return;
        }
        List<LuaChecker.Issue> issues = LuaChecker.check(code);
        if (issues.isEmpty()) {
            toast(getString(R.string.editor_no_error));
        } else {
            toast("发现 " + issues.size() + " 处问题，详见下方");
        }
    }

    // ==================== 功能模板 ====================

    /** 右上角「+」：弹出六个模板 */
    private void showTemplateDialog() {
        final LuaTemplates.Template[] templates = LuaTemplates.all();
        String[] names = new String[templates.length];
        for (int i = 0; i < templates.length; i++) {
            String desc = getString(templates[i].descRes);
            names[i] = getString(templates[i].nameRes) + "\n" + desc;
        }

        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.editor_insert_template))
                .setItems(names, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        confirmInsert(templates[which]);
                    }
                })
                .setNegativeButton(getString(R.string.action_cancel), null)
                .show();
    }

    /** 插入前确认：内容非空时提醒会被覆盖 */
    private void confirmInsert(final LuaTemplates.Template template) {
        String current = etCode.getText().toString();
        if (current.trim().length() == 0) {
            insertTemplate(template);
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.editor_insert_template))
                .setMessage(getString(R.string.editor_replace_warn))
                .setNegativeButton(getString(R.string.action_cancel), null)
                .setPositiveButton(getString(R.string.editor_confirm),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                insertTemplate(template);
                            }
                        })
                .show();
    }

    private void insertTemplate(LuaTemplates.Template template) {
        etCode.setText(template.code);
        etCode.setSelection(0);
        if (editorScroll != null) {
            editorScroll.smoothScrollTo(0, 0);
        }
        updateLineNumbers();
        updateStatus();
        runCheck();
        toast(getString(template.nameRes) + " 已插入");
    }

    // ==================== 保存 ====================

    private void saveFile() {
        String code = etCode.getText().toString();
        if (code.trim().length() == 0) {
            toast("内容为空，无需保存");
            return;
        }
        File dir = new File(android.os.Environment.getExternalStorageDirectory(), "CTScript");
        File target = new File(dir, "script.lua");
        if (FileUtil.writeText(target, code)) {
            toast(getString(R.string.editor_saved, target.getAbsolutePath()));
        } else {
            toast(getString(R.string.editor_save_failed));
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private float dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return value * density;
    }
}
