package com.modace.ctmod.security;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import dalvik.system.DexClassLoader;

/**
 * 伪加壳 —— 把核心类藏进加密的附属 dex，运行时才解密加载。
 *
 * 【它保护什么】
 *   正常 APK 里所有类都在 classes.dex 中，反编译工具一打开就全看到。
 *   加了壳之后，核心算法不在 classes.dex 里，
 *   而是作为一段加密字节存在 assets 中，运行时才解密、才被加载。
 *   静态反编译看到的只是一个「加载器」和一堆无意义密文。
 *
 * 【为什么叫「伪」加壳】
 *   真正的商用壳会在 Application 最早期接管、做内存中的 dex 加载、
 *   对抗动态 dump。这里做不到那个程度——解密出的 dex 终究要落到
 *   私有目录或者被 ClassLoader 持有，有经验的逆向者动态调试仍可取到。
 *   但它挡住了「解压 APK 直接拖进反编译器」这一条最常见的路径，
 *   性价比很高。
 *
 * 【优雅降级】
 *   assets 里没有 payload 就返回 null，调用方走内置实现。
 *   这是刻意的——保证即使没做 payload，应用也完全正常。
 *
 * 【如何生成 payload】
 *   见打包脚本说明。核心步骤：
 *     1. 把要保护的类单独编译成 dex
 *     2. 用 KeyVault 相同的密钥加密
 *     3. 放进 assets/p.dat
 *   注意：密钥与 APK 签名绑定，重签名后必须重新生成 payload。
 */
public final class ShellLoader {

    /** assets 中的加密 payload 文件名 */
    private static final String PAYLOAD = "p.dat";

    private static Class<?> cached = null;
    private static boolean tried = false;

    private ShellLoader() {
    }

    /**
     * 加载受保护的类。
     *
     * @param ctx     上下文
     * @param iface   该类的接口或基类名（用于校验加载结果）
     * @return 加载到的 Class；没有 payload 或失败时返回 null
     */
    public static synchronized Class<?> load(Context ctx, String iface) {
        if (tried) {
            return cached;
        }
        tried = true;

        InputStream in = null;
        FileOutputStream out = null;
        try {
            in = ctx.getAssets().open(PAYLOAD);
            byte[] enc = readAll(in);
            if (enc == null || enc.length == 0) {
                return null;
            }

            // 用与字符串加密相同的密钥解密
            byte[] dex = dec(ctx, enc);
            if (dex == null || dex.length < 64) {
                return null;
            }

            // 优化后的 dex 目录必须是本应用私有目录，不能是别的路径
            File opt = ctx.getDir("po", Context.MODE_PRIVATE);
            File dexFile = new File(opt, "p.dex");
            out = new FileOutputStream(dexFile);
            out.write(dex);
            out.flush();
            try {
                out.close();
            } catch (Exception ignore) {
            }
            out = null;

            DexClassLoader cl = new DexClassLoader(
                    dexFile.getAbsolutePath(),
                    opt.getAbsolutePath(),
                    null,
                    ctx.getClassLoader());

            // payload 的类名记录在文件头，避免硬编码类名暴露意图
            String clsName = readClassName(dex);
            if (clsName == null) {
                return null;
            }

            Class<?> c = cl.loadClass(clsName);
            cached = c;
            return c;
        } catch (Exception e) {
            cached = null;
            return null;
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Exception ignore) {
                }
            }
            if (out != null) {
                try {
                    out.close();
                } catch (Exception ignore) {
                }
            }
        }
    }

    /** 解密 payload（AES-CBC，密钥来自 KeyVault） */
    private static byte[] dec(Context ctx, byte[] enc) {
        try {
            byte[] key = KeyVault.master(ctx);
            if (enc.length < 17) {
                return null;
            }
            byte[] iv = new byte[16];
            System.arraycopy(enc, 0, iv, 0, 16);
            byte[] body = new byte[enc.length - 16];
            System.arraycopy(enc, 16, body, 0, body.length);

            javax.crypto.Cipher c =
                    javax.crypto.Cipher.getInstance("AES/CBC/PKCS5Padding");
            c.init(javax.crypto.Cipher.DECRYPT_MODE,
                    new javax.crypto.spec.SecretKeySpec(key, "AES"),
                    new javax.crypto.spec.IvParameterSpec(iv));
            return c.doFinal(body);
        } catch (Exception e) {
            return null;
        }
    }

    /** payload 前 4 字节是类名长度，其后是类名 UTF-8 */
    private static String readClassName(byte[] dex) {
        try {
            if (dex.length < 5) {
                return null;
            }
            int len = ((dex[0] & 0xFF) << 24) | ((dex[1] & 0xFF) << 16)
                    | ((dex[2] & 0xFF) << 8) | (dex[3] & 0xFF);
            if (len <= 0 || len > 256 || len + 4 > dex.length) {
                return null;
            }
            return new String(dex, 4, len, "UTF-8");
        } catch (Exception e) {
            return null;
        }
    }

    private static byte[] readAll(InputStream in) {
        try {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                bo.write(buf, 0, n);
            }
            return bo.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }
}
