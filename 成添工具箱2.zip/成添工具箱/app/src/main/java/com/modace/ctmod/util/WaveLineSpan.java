package com.modace.ctmod.util;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.text.style.ReplacementSpan;

/**
 * 红色波浪下划线 —— 画在出错代码文字的正下方。
 *
 * 为什么用 ReplacementSpan 而不是 UnderlineSpan：
 *   UnderlineSpan 只能画直线，画不出波浪。
 *   注意 ReplacementSpan 默认不绘制文字，必须自己在 draw 里补画，
 *   否则加上 span 的那段文字会整个消失。
 *
 * 尺寸单位统一为像素（px），由调用方用 dp() 换算后传入，
 * 避免不同屏幕密度下波浪线粗细不一。
 */
public class WaveLineSpan extends ReplacementSpan {

    private final int color;
    private final float waveHeight;
    private final float period;
    private final float strokeWidth;

    /**
     * @param color      波浪线颜色
     * @param waveHeight 波浪线距基线的距离（px）
     * @param period     一个完整波形的宽度（px）
     * @param strokeWidth 线宽（px）
     */
    public WaveLineSpan(int color, float waveHeight, float period, float strokeWidth) {
        this.color = color;
        this.waveHeight = waveHeight;
        this.period = period;
        this.strokeWidth = strokeWidth;
    }

    @Override
    public int getSize(Paint paint, CharSequence text, int start, int end,
                       Paint.FontMetricsInt fm) {
        // 返回原文字宽度，保证排版不变形
        return Math.round(paint.measureText(text, start, end));
    }

    @Override
    public void draw(Canvas canvas, CharSequence text, int start, int end,
                     float x, int top, int y, int bottom, Paint paint) {
        // 1. 先画原本的文字（ReplacementSpan 不会自动画，漏了就变空白）
        canvas.drawText(text, start, end, x, y, paint);

        // 2. 再在文字下方画波浪线
        Paint p = new Paint(paint);
        p.setColor(color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(strokeWidth);
        p.setAntiAlias(true);

        float width = paint.measureText(text, start, end);
        float lineY = y + waveHeight;
        // 别超出行底，否则会被下一行裁掉
        if (lineY > bottom - strokeWidth) {
            lineY = bottom - strokeWidth;
        }

        Path path = new Path();
        path.moveTo(x, lineY);
        float half = period / 2f;
        float px = x;
        boolean up = true;
        while (px < x + width) {
            float nx = Math.min(px + half, x + width);
            // 用二次贝塞尔画出平滑的波峰波谷
            path.quadTo(px + half / 2f, up ? lineY - waveHeight : lineY + waveHeight, nx, lineY);
            px = nx;
            up = !up;
        }
        canvas.drawPath(path, p);
    }
}
