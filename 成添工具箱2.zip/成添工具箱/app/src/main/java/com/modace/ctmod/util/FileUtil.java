package com.modace.ctmod.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;

/**
 * 文件操作工具：遍历、大小、MD5、删除、读写。
 */
public final class FileUtil {

    private FileUtil() {
    }

    /** 递归删除文件或目录 */
    public static boolean deleteRecursive(File file) {
        if (file == null || !file.exists()) {
            return false;
        }
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (int i = 0; i < children.length; i++) {
                    deleteRecursive(children[i]);
                }
            }
        }
        try {
            return file.delete();
        } catch (Exception e) {
            return false;
        }
    }

    /** 目录总大小（递归） */
    public static long sizeOf(File file) {
        if (file == null || !file.exists()) {
            return 0L;
        }
        if (file.isFile()) {
            return file.length();
        }
        long total = 0L;
        File[] children = file.listFiles();
        if (children != null) {
            for (int i = 0; i < children.length; i++) {
                total += sizeOf(children[i]);
            }
        }
        return total;
    }

    /** 目录是否为空（无子文件无子目录） */
    public static boolean isEmptyDir(File dir) {
        if (dir == null || !dir.isDirectory()) {
            return false;
        }
        File[] children = dir.listFiles();
        return children == null || children.length == 0;
    }

    /** 文件 MD5，失败返回 null */
    public static String md5(File file) {
        if (file == null || !file.isFile()) {
            return null;
        }
        InputStream in = null;
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            in = new FileInputStream(file);
            byte[] buffer = new byte[8192];
            int len;
            while ((len = in.read(buffer)) > 0) {
                digest.update(buffer, 0, len);
            }
            return FormatUtil.toHex(digest.digest());
        } catch (Exception e) {
            return null;
        } finally {
            closeQuietly(in);
        }
    }

    /** 读全部字节 */
    public static byte[] readBytes(File file) {
        if (file == null || !file.isFile()) {
            return null;
        }
        InputStream in = null;
        try {
            long len = file.length();
            if (len > Integer.MAX_VALUE) {
                return null;
            }
            byte[] data = new byte[(int) len];
            in = new FileInputStream(file);
            int read = 0;
            while (read < data.length) {
                int n = in.read(data, read, data.length - read);
                if (n < 0) {
                    break;
                }
                read += n;
            }
            return data;
        } catch (Exception e) {
            return null;
        } finally {
            closeQuietly(in);
        }
    }

    /** 写字节，自动建父目录 */
    public static boolean writeBytes(File file, byte[] data) {
        if (file == null || data == null) {
            return false;
        }
        OutputStream out = null;
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }
            out = new FileOutputStream(file, false);
            out.write(data);
            out.flush();
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            closeQuietly(out);
        }
    }

    /** 写文本 */
    public static boolean writeText(File file, String text) {
        if (text == null) {
            return false;
        }
        return writeBytes(file, text.getBytes());
    }

    /** 文件扩展名（小写，不含点） */
    public static String ext(String name) {
        if (name == null) {
            return "";
        }
        int dot = name.lastIndexOf('.');
        if (dot < 0 || dot == name.length() - 1) {
            return "";
        }
        return name.substring(dot + 1).toLowerCase();
    }

    private static void closeQuietly(InputStream in) {
        if (in != null) {
            try {
                in.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static void closeQuietly(OutputStream out) {
        if (out != null) {
            try {
                out.close();
            } catch (Exception ignored) {
            }
        }
    }
}
