package com.modace.ctmod;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;

/**
 * 全局横竖屏管理。
 *
 * 解决的问题：
 *   主界面右上角可以切横竖屏，但点进二级页后又被 Manifest 里的
 *   screenOrientation="portrait" 拉回竖屏，方向不统一。
 *
 * 方案：
 *   方向偏好存进 SharedPreferences，每个 Activity 在 setContentView 之前
 *   （必须是之前，否则会闪一下甚至不生效）调用 apply() 统一应用。
 *
 * 【关键】用 commit() 而不是 apply()：
 *   apply() 是异步落盘，下一个 Activity 启动时可能还没写完，读到的仍是旧值。
 *   commit() 同步写盘，保证切完立刻跳转的页面能拿到新方向。
 */
public final class OrientUtil {

    private static final String PREF_NAME = "ct_orient";
    private static final String KEY_LANDSCAPE = "landscape";

    private OrientUtil() {
    }

    /** 当前是否设为横屏 */
    public static boolean isLandscape(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return sp.getBoolean(KEY_LANDSCAPE, false);
    }

    /** 保存方向偏好（同步写盘） */
    public static void setLandscape(Context context, boolean landscape) {
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putBoolean(KEY_LANDSCAPE, landscape).commit();
    }

    /**
     * 把已保存的方向应用到当前 Activity。
     * 必须在 setContentView() 之前调用。
     */
    public static void apply(Activity activity) {
        if (isLandscape(activity)) {
            activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        } else {
            activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }

    /** 切换方向：先存偏好再应用，切换后 Activity 会重建并由新布局接管 */
    public static void toggle(Activity activity) {
        boolean next = !isLandscape(activity);
        setLandscape(activity, next);
        apply(activity);
    }
}
