package com.modace.ctmod;

import android.view.View;
import android.widget.LinearLayout;

/**
 * 开发信息页 —— 作者 / 群聊 / 反馈 三个跳转入口。
 *
 * 【发布前必做】
 * 把下面三个 LINK_ 常量替换成你自己的真实地址，
 * 否则点击会跳到示例占位页。
 */
public class DevInfoActivity extends NavPageBaseActivity {

    /** 作者主页（个人主页 / 主页 / GitHub 等） */
    private static final String LINK_AUTHOR = "https://qm.qq.com/q/uwfhvC0xTG";
    /** 官方群聊（QQ 群网页版加入链接） */
    private static final String LINK_GROUP = "https://qm.qq.com/q/XO2WKoEQuG";
    /** 问题反馈（邮箱 mailto 或反馈表单网址） */
    private static final String LINK_FEEDBACK = "https://@qq.com/3388478340";
    
    @Override
    protected String getTitleText() {
        return getString(R.string.title_dev);
    }

    @Override
    protected int getNavTab() {
        return NavBar.TAB_DEV;
    }

    @Override
    protected void buildContent(LinearLayout container) {
        addCard(container, getString(R.string.app_name), getString(R.string.dev_intro));

        addSectionTitle(container, getString(R.string.dev_section_links));

        addLinkRow(container,
                getString(R.string.dev_author),
                getString(R.string.dev_author_desc),
                new View.OnClickListener() {
                    public void onClick(View v) {
                        openLink(LINK_AUTHOR);
                    }
                });

        addLinkRow(container,
                getString(R.string.dev_group),
                getString(R.string.dev_group_desc),
                new View.OnClickListener() {
                    public void onClick(View v) {
                        openLink(LINK_GROUP);
                    }
                });

        addLinkRow(container,
                getString(R.string.dev_feedback),
                getString(R.string.dev_feedback_desc),
                new View.OnClickListener() {
                    public void onClick(View v) {
                        openLink(LINK_FEEDBACK);
                    }
                });

        addSectionTitle(container, getString(R.string.dev_section_tech));

        addCard(container, getString(R.string.dev_tech_stack),
                getString(R.string.dev_tech_stack_body));
        addCard(container, getString(R.string.dev_tech_module),
                getString(R.string.dev_tech_module_body));

        // 提示占位链接尚未替换，避免开发者忘记
        addCard(container, "", getString(R.string.dev_link_placeholder_tip));
    }
}
