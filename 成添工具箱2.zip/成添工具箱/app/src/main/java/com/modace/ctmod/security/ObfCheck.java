package com.modace.ctmod.security;

import android.content.Context;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * 检测当前 APK 是否已被混淆。
 *
 * 原理：
 *   未混淆的 dex 里，类名以原始形式存储，例如
 *     com/modace/ctmod/MainActivity
 *   混淆并 -repackageclasses '' 之后，这个字符串会消失，
 *   类名变成 a/a/a 之类。所以直接搜原始包名路径即可判断。
 *
 * 这是「读自己的 APK」来验证，结果真实可信，
 * 不用猜 build.gradle 写了什么、也不用猜构建时走的哪个 variant。
 */
public final class ObfCheck {

    /** 默认要搜索的原始包名路径（斜杠形式） */
    private static final String DEFAULT_NEEDLE = "com/modace/ctmod/";

    private ObfCheck() {
    }

    /** 检测结果 */
    public static class Result {
        public final boolean checked;      // 是否成功检测
        public final boolean obfuscated;   // 是否已混淆
        public final String detail;        // 说明文字

        Result(boolean checked, boolean obfuscated, String detail) {
            this.checked = checked;
            this.obfuscated = obfuscated;
            this.detail = detail;
        }
    }

    /**
     * 检测自身 APK 的 classes.dex 是否还含有原始包名路径。
     *
     * @param context 上下文
     * @param needle  要搜索的原始包名路径，传 null 用默认值
     */
    public static Result check(Context context, String needle) {
        String target = (needle == null || needle.length() == 0)
                ? DEFAULT_NEEDLE : needle;

        String apkPath = null;
        try {
            apkPath = context.getApplicationInfo().sourceDir;
        } catch (Exception e) {
            return new Result(false, false, "无法定位 APK 路径");
        }
        if (apkPath == null) {
            return new Result(false, false, "无法定位 APK 路径");
        }

        ZipFile zip = null;
        try {
            zip = new ZipFile(apkPath);
            ZipEntry entry = zip.getEntry("classes.dex");
            if (entry == null) {
                return new Result(false, false, "APK 中没有 classes.dex");
            }

            InputStream in = zip.getInputStream(entry);
            boolean found = streamContains(new BufferedInputStream(in, 65536), target);
            try {
                in.close();
            } catch (Exception ignore) {
            }

            if (found) {
                return new Result(true, false,
                        "发现原始包名路径「" + target + "」，说明代码未被混淆");
            }
            return new Result(true, true, "未发现原始包名路径，代码已混淆");
        } catch (Exception e) {
            return new Result(false, false, "读取失败：" + e.getMessage());
        } finally {
            if (zip != null) {
                try {
                    zip.close();
                } catch (Exception ignore) {
                }
            }
        }
    }

    /**
     * 流式搜索：不把整个 dex 读进内存。
     * 用滚动窗口匹配，避免跨越缓冲区边界时漏判。
     */
    private static boolean streamContains(BufferedInputStream in, String needle)
            throws Exception {
        byte[] pat = needle.getBytes("US-ASCII");
        int patLen = pat.length;
        if (patLen == 0) {
            return false;
        }

        byte[] buf = new byte[65536];
        int overlap = patLen - 1;      // 保留上一块尾部，防止跨块漏判
        byte[] window = new byte[buf.length + overlap];
        int winLen = 0;

        // 部分匹配表（KMP），避免最坏情况下的重复比较
        int[] lps = buildLps(pat);

        int matched = 0;
        while (true) {
            int n = in.read(buf);
            if (n <= 0) {
                break;
            }
            // 拼成 上块尾部 + 本块
            System.arraycopy(window, winLen > overlap ? winLen - overlap : 0,
                    window, 0, Math.min(winLen, overlap));
            int carry = Math.min(winLen, overlap);
            System.arraycopy(buf, 0, window, carry, n);
            int total = carry + n;

            for (int i = 0; i < total; i++) {
                while (matched > 0 && window[i] != pat[matched]) {
                    matched = lps[matched - 1];
                }
                if (window[i] == pat[matched]) {
                    matched++;
                    if (matched == patLen) {
                        return true;
                    }
                } else {
                    matched = 0;
                }
            }

            // 保存本块尾部供下一轮
            System.arraycopy(window, Math.max(0, total - overlap), window, 0,
                    Math.min(overlap, total));
            winLen = Math.min(overlap, total);
        }
        return false;
    }

    /** KMP 最长前后缀表 */
    private static int[] buildLps(byte[] pat) {
        int[] lps = new int[pat.length];
        int len = 0;
        for (int i = 1; i < pat.length; ) {
            if (pat[i] == pat[len]) {
                lps[i++] = ++len;
            } else if (len > 0) {
                len = lps[len - 1];
            } else {
                lps[i++] = 0;
            }
        }
        return lps;
    }
}
