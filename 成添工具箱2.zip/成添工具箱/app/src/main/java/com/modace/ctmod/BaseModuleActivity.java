package com.modace.ctmod;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 二级页面基类：统一处理返回按钮、标题、可选右上角按钮、底部提示。
 *
 * 子类只需实现 getTitleText() 与 buildContent()。
 */
public abstract class BaseModuleActivity extends Activity implements View.OnClickListener {

    private LinearLayout contentContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 统一跟随主界面设置的横竖屏，必须早于 setContentView
        OrientUtil.apply(this);
        setContentView(R.layout.activity_module);

        TextView title = (TextView) findViewById(R.id.tv_title);
        title.setText(getTitleText());

        TextView back = (TextView) findViewById(R.id.btn_back);
        back.setOnClickListener(this);

        TextView action = (TextView) findViewById(R.id.btn_action);
        String actionText = getActionText();
        if (actionText != null && actionText.length() > 0) {
            action.setText(actionText);
            action.setVisibility(View.VISIBLE);
            action.setOnClickListener(this);
        }

        TextView footer = (TextView) findViewById(R.id.tv_footer);
        if (footer != null) {
            footer.setText(getFooterText());
        }

        setupContentHost();
    }

    /**
     * 内容宿主模式：
     *  - 子类重写 getContentLayoutRes() 返回布局 id，则直接 inflate 进去（自带滚动视图）
     *  - 否则自动创建 ScrollView + 纵向 LinearLayout，供 addCard 等方法使用
     */
    private void setupContentHost() {
        android.widget.FrameLayout host =
                (android.widget.FrameLayout) findViewById(R.id.content_host);
        if (host == null) {
            return;
        }
        int res = getContentLayoutRes();
        if (res != 0) {
            getLayoutInflater().inflate(res, host, true);
            return;
        }
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.setBackgroundColor(getResources().getColor(R.color.bg_window));
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setPadding(0, 0, 0, dp(20));
        sv.addView(ll, new android.widget.ScrollView.LayoutParams(
                android.widget.ScrollView.LayoutParams.MATCH_PARENT,
                android.widget.ScrollView.LayoutParams.WRAP_CONTENT));
        host.addView(sv, new android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT));
        contentContainer = ll;
        buildContent(ll);
    }

    /** 自定义内容布局，返回 0 表示使用默认滚动容器 */
    protected int getContentLayoutRes() {
        return 0;
    }

    protected abstract String getTitleText();

    /** 使用默认容器时构建内容；使用自定义布局时留空即可 */
    protected abstract void buildContent(LinearLayout container);

    /** 右上角按钮文字，返回空则不显示 */
    protected String getActionText() {
        return null;
    }

    protected String getFooterText() {
        return getString(R.string.privacy_note_title);
    }

    protected LinearLayout getContentContainer() {
        return contentContainer;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_back) {
            finish();
            return;
        }
        if (v.getId() == R.id.btn_action) {
            onActionClick();
        }
    }

    protected void onActionClick() {
    }

    protected void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    protected int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (value * density + 0.5f);
    }

    // ============ 通用 UI 构建辅助 ============

    /** 区块小标题 */
    protected void addSectionTitle(LinearLayout container, String text) {
        if (container == null) {
            return;
        }
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(getResources().getColor(R.color.text_secondary));
        tv.setTextSize(13);
        tv.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(18), dp(18), 0, dp(10));
        container.addView(tv, lp);
    }

    /** 标题 + 正文卡片，两个参数都可为空 */
    protected void addCard(LinearLayout container, String title, String body) {
        if (container == null) {
            return;
        }
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));

        if (title != null && title.length() > 0) {
            TextView t = new TextView(this);
            t.setText(title);
            t.setTextColor(getResources().getColor(R.color.text_primary));
            t.setTextSize(14);
            t.setTypeface(null, Typeface.BOLD);
            card.addView(t);
        }

        if (body != null && body.length() > 0) {
            TextView b = new TextView(this);
            b.setText(body);
            b.setTextColor(getResources().getColor(R.color.text_secondary));
            b.setTextSize(12);
            b.setLineSpacing(dp(2), 1f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, dp(6), 0, 0);
            card.addView(b, lp);
        }

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(18), 0, dp(18), dp(10));
        container.addView(card, lp);
    }

    /** 状态行：左侧名称，右侧状态（带颜色） */
    protected void addStatusRow(LinearLayout container, String name, String status, int color) {
        if (container == null) {
            return;
        }
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBackgroundResource(R.drawable.bg_card);
        row.setPadding(dp(16), dp(12), dp(16), dp(12));
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);

        TextView n = new TextView(this);
        n.setText(name);
        n.setTextColor(getResources().getColor(R.color.text_primary));
        n.setTextSize(13);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(n, nlp);

        TextView s = new TextView(this);
        s.setText(status);
        s.setTextColor(getResources().getColor(color));
        s.setTextSize(12);
        s.setTypeface(null, Typeface.BOLD);
        row.addView(s);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(18), 0, dp(18), dp(8));
        container.addView(row, lp);
    }
}
