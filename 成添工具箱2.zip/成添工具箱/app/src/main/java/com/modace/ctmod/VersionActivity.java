package com.modace.ctmod;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.widget.LinearLayout;

import com.modace.ctmod.util.DeviceInfo;

/**
 * 版本页 —— 应用版本 + 隐私与法律声明。
 */
public class VersionActivity extends NavPageBaseActivity {

    @Override
    protected String getTitleText() {
        return getString(R.string.title_version);
    }

    @Override
    protected int getNavTab() {
        return NavBar.TAB_VERSION;
    }

    @Override
    protected void buildContent(LinearLayout container) {
        // ---------- 版本信息 ----------
        addSectionTitle(container, getString(R.string.version_section_app));

        String versionName = "1.0";
        int versionCode = 1;
        try {
            PackageManager pm = getPackageManager();
            PackageInfo info = pm.getPackageInfo(getPackageName(), 0);
            versionName = info.versionName;
            versionCode = info.versionCode;
        } catch (Exception e) {
            // 读不到就用默认值，不影响展示
        }

        addCard(container, getString(R.string.app_name),
                getString(R.string.version_name) + "：" + versionName + "\n"
                        + getString(R.string.version_code) + "：" + versionCode + "\n"
                        + getString(R.string.version_package) + "：" + getPackageName());

        addCard(container, getString(R.string.version_runtime),
                "Android " + DeviceInfo.getSystemVersion()
                        + " · " + DeviceInfo.getManufacturer() + " " + DeviceInfo.getDeviceModel()
                        + " · " + DeviceInfo.getCpuCores() + " 核");

        // ---------- 隐私声明 ----------
        addSectionTitle(container, getString(R.string.privacy_section));

        addCard(container, getString(R.string.privacy_item_1_title),
                getString(R.string.privacy_item_1_body));
        addCard(container, getString(R.string.privacy_item_2_title),
                getString(R.string.privacy_item_2_body));
        addCard(container, getString(R.string.privacy_item_3_title),
                getString(R.string.privacy_item_3_body));
        addCard(container, getString(R.string.privacy_item_4_title),
                getString(R.string.privacy_item_4_body));

        // ---------- 法律声明 ----------
        addSectionTitle(container, getString(R.string.legal_section));

        addCard(container, getString(R.string.legal_item_1_title),
                getString(R.string.legal_item_1_body));
        addCard(container, getString(R.string.legal_item_2_title),
                getString(R.string.legal_item_2_body));
        addCard(container, getString(R.string.legal_item_3_title),
                getString(R.string.legal_item_3_body));
        addCard(container, getString(R.string.legal_item_4_title),
                getString(R.string.legal_item_4_body));
        addCard(container, getString(R.string.legal_item_5_title),
                getString(R.string.legal_item_5_body));

        addSectionTitle(container, getString(R.string.legal_thirdparty_title));
        addCard(container, "", getString(R.string.legal_thirdparty_body));
    }
}
