package com.modace.ctmod.security;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.modace.ctmod.util.FileUtil;

/**
 * 源码文件扫描 —— 递归找出待加密/待解密的文件。
 *
 * 刻意不引用 R，避免子包导入问题。
 */
public final class SourceScanner {

    /** 加密产物后缀 */
    public static final String ENC_EXT = "ctenc";

    /** 默认排除的目录：构建产物与版本库，扫进去既没意义又极慢 */
    private static final String[] SKIP_DIRS = {
            "build", ".git", ".gradle", "node_modules", ".idea", "bin", "gen", "obj"
    };

    /** 一个待处理文件 */
    public static class SourceFile {
        public final File file;
        public final long size;
        /** 是否已处于加密状态（是则本次应解密，反之应加密） */
        public final boolean encrypted;

        public SourceFile(File file, long size, boolean encrypted) {
            this.file = file;
            this.size = size;
            this.encrypted = encrypted;
        }

        public String name() {
            return file.getName();
        }

        public String path() {
            return file.getAbsolutePath();
        }
    }

    private SourceScanner() {
    }

    /**
     * 扫描目录。
     *
     * @param root      根目录
     * @param exts      关注的扩展名（小写，不含点）；为 null 或空表示不限
     * @param forDecrypt true=只收已加密文件，false=只收未加密文件
     */
    public static List<SourceFile> scan(File root, String[] exts, boolean forDecrypt) {
        List<SourceFile> out = new ArrayList<SourceFile>();
        if (root == null || !root.isDirectory()) {
            return out;
        }
        collect(root, exts, forDecrypt, out);
        // 按体积从大到小，大文件排前面便于优先确认
        Collections.sort(out, new Comparator<SourceFile>() {
            public int compare(SourceFile a, SourceFile b) {
                if (a.size > b.size) {
                    return -1;
                }
                if (a.size < b.size) {
                    return 1;
                }
                return 0;
            }
        });
        return out;
    }

    private static void collect(File dir, String[] exts, boolean forDecrypt, List<SourceFile> out) {
        File[] children = dir.listFiles();
        if (children == null) {
            return;
        }
        for (int i = 0; i < children.length; i++) {
            File f = children[i];
            if (f.isDirectory()) {
                if (!isSkipped(f.getName())) {
                    collect(f, exts, forDecrypt, out);
                }
                continue;
            }
            if (!f.isFile()) {
                continue;
            }

            String name = f.getName();
            String ext = FileUtil.ext(name);

            // 已加密文件：后缀一定是 .ctenc
            boolean isEnc = ENC_EXT.equals(ext);

            if (forDecrypt) {
                // 解密模式只收加密文件
                if (!isEnc) {
                    continue;
                }
                out.add(new SourceFile(f, f.length(), true));
            } else {
                // 加密模式跳过已加密文件，避免二次加密
                if (isEnc) {
                    continue;
                }
                if (!matchExt(ext, exts)) {
                    continue;
                }
                out.add(new SourceFile(f, f.length(), false));
            }
        }
    }

    private static boolean matchExt(String ext, String[] exts) {
        if (exts == null || exts.length == 0) {
            return true;
        }
        for (int i = 0; i < exts.length; i++) {
            if (exts[i].equals(ext)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isSkipped(String dirName) {
        for (int i = 0; i < SKIP_DIRS.length; i++) {
            if (SKIP_DIRS[i].equals(dirName)) {
                return true;
            }
        }
        return false;
    }

    /** 加密后的目标文件名 */
    public static File encTarget(File src) {
        return new File(src.getAbsolutePath() + "." + ENC_EXT);
    }

    /** 解密后的目标文件名（去掉 .ctenc 后缀） */
    public static File decTarget(File src) {
        String p = src.getAbsolutePath();
        String suffix = "." + ENC_EXT;
        if (p.endsWith(suffix)) {
            return new File(p.substring(0, p.length() - suffix.length()));
        }
        return new File(p + ".dec");
    }
}
