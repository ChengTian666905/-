package com.modace.ctmod.security;

import android.content.Context;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.util.zip.Inflater;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * 字符串运行时解密。
 *
 * 用法（由打包脚本自动改写，不需要手写）：
 *     原始：  String s = "某段敏感文字";
 *     改写后：String s = StringCrypt.d("Ab3dEf...");
 *
 * 这样 dex 里就搜不到那串敏感文字的明文了。
 *
 * 【必须先 init】
 *     StringCrypt.init(this) 要在 Application 或首个 Activity 里调用一次，
 *     否则拿不到 Context，也就拿不到密钥。
 *
 * 【为什么用压缩】
 *     Base64 会让密文膨胀约 1/3，且大量短字符串各自补齐到 16 字节块，
 *     整体开销可观。先 inflate 再解密可以抵消一部分膨胀。
 *
 * 【API 兼容】
 *     android.util.Base64 是 API 8 加的，minSdk 14 安全。
 */
public final class StringCrypt {

    private static Context ctx;

    private StringCrypt() {
    }

    /** 在使用前调用一次 */
    public static void init(Context context) {
        ctx = context.getApplicationContext();
    }

    /**
     * 解密字符串。
     * @param packed Base64( IV(16) + AES-CBC( 压缩后的明文 ) )
     */
    public static String d(String packed) {
        try {
            byte[] key = KeyVault.master(ctx);
            byte[] raw = Base64.decode(packed, Base64.DEFAULT);
            if (raw.length < 17) {
                return "";
            }
            byte[] iv = new byte[16];
            System.arraycopy(raw, 0, iv, 0, 16);
            byte[] body = new byte[raw.length - 16];
            System.arraycopy(raw, 16, body, 0, body.length);

            Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
            c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
            byte[] comp = c.doFinal(body);

            byte[] plain = inflate(comp);
            return new String(plain, "UTF-8");
        } catch (Exception e) {
            // 解不开通常是签名被改（二次打包），返回空串让上层逻辑自然失效
            return "";
        }
    }

    private static byte[] inflate(byte[] comp) {
        Inflater inf = new Inflater();
        inf.setInput(comp);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[512];
        try {
            while (!inf.finished()) {
                int n = inf.inflate(buf);
                if (n <= 0) {
                    break;
                }
                out.write(buf, 0, n);
            }
        } catch (Exception e) {
            return new byte[0];
        } finally {
            inf.end();
        }
        return out.toByteArray();
    }
}
