package com.modace.ctmod.clean;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Environment;

import com.modace.ctmod.util.FileUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 垃圾扫描引擎。
 *
 * 【能做什么 / 不能做什么】
 *  Android 6.0 起禁止读写其他应用的私有缓存目录，
 *  因此本扫描器只处理「公共存储」上的文件，这是合规且真实有效的范围。
 *  应用私有缓存无法直接清理，只能引导用户跳系统设置页。
 *  对外宣传时不要声称「一键清空所有 App 缓存」，用户一试就会露馅。
 */
public final class CleanScanner {

    /** 扫描深度上限，防止在深层目录耗时过久 */
    private static final int MAX_DEPTH = 4;
    /** 扫描文件数上限，防止超大存储卡导致长时间无响应 */
    private static final int MAX_FILES = 8000;
    /** 大文件阈值：50MB */
    private static final long LARGE_THRESHOLD = 50L * 1024 * 1024;
    /** 参与重复文件比对的下限：小于它的文件不值得去重 */
    private static final long DUP_MIN = 100L * 1024;
    /** 参与重复文件比对的上限：大于它算 MD5 太慢 */
    private static final long DUP_MAX = 20L * 1024 * 1024;

    /** 白名单：这些目录一律跳过，绝不扫描 */
    private static final String[] WHITELIST = {
            "DCIM", "Pictures", "Music", "Movies", "Download",
            "Ringtones", "Notifications", "Alarms", "Podcasts"
    };

    /** 临时/垃圾文件扩展名 */
    private static final String[] TEMP_EXTS = {
            "tmp", "temp", "log", "cache", "bak", "swp", "old", "crdownload", "part"
    };

    /** 压缩包扩展名 */
    private static final String[] ZIP_EXTS = {
            "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "tgz"
    };

    /** 已知广告/统计 SDK 遗留目录名，命中即视为残留 */
    private static final String[] JUNK_DIRS = {
            ".umeng", ".ds_data", "tbs", ".gs_file", "log", "logs", "crash"
    };

    private final Context context;
    private int fileCount = 0;

    public CleanScanner(Context context) {
        this.context = context;
    }

    /** 同步扫描，请在后台线程调用 */
    public List<CleanItem> scan() {
        List<CleanItem> result = new ArrayList<CleanItem>();
        File root = Environment.getExternalStorageDirectory();
        if (root == null || !root.exists()) {
            return result;
        }
        fileCount = 0;

        List<File> allFiles = new ArrayList<File>();
        List<File> allDirs = new ArrayList<File>();
        collect(root, 0, allFiles, allDirs);

        // 1. 安装包
        for (int i = 0; i < allFiles.size(); i++) {
            File f = allFiles.get(i);
            if ("apk".equals(FileUtil.ext(f.getName()))) {
                result.add(new CleanItem(f.getAbsolutePath(), f.length(), CleanItem.TYPE_APK));
            }
        }

        // 2. 压缩包
        for (int i = 0; i < allFiles.size(); i++) {
            File f = allFiles.get(i);
            String ext = FileUtil.ext(f.getName());
            for (int j = 0; j < ZIP_EXTS.length; j++) {
                if (ZIP_EXTS[j].equals(ext)) {
                    result.add(new CleanItem(f.getAbsolutePath(), f.length(), CleanItem.TYPE_ZIP));
                    break;
                }
            }
        }

        // 3. 临时文件
        for (int i = 0; i < allFiles.size(); i++) {
            File f = allFiles.get(i);
            String ext = FileUtil.ext(f.getName());
            for (int j = 0; j < TEMP_EXTS.length; j++) {
                if (TEMP_EXTS[j].equals(ext)) {
                    result.add(new CleanItem(f.getAbsolutePath(), f.length(), CleanItem.TYPE_TEMP));
                    break;
                }
            }
        }

        // 4. 大文件
        for (int i = 0; i < allFiles.size(); i++) {
            File f = allFiles.get(i);
            if (f.length() >= LARGE_THRESHOLD) {
                result.add(new CleanItem(f.getAbsolutePath(), f.length(), CleanItem.TYPE_LARGE));
            }
        }

        // 5. 重复文件（按 MD5 分组，保留每组第一个之外的）
        Map<String, File> seen = new HashMap<String, File>();
        for (int i = 0; i < allFiles.size(); i++) {
            File f = allFiles.get(i);
            long len = f.length();
            if (len < DUP_MIN || len > DUP_MAX) {
                continue;
            }
            String md5 = FileUtil.md5(f);
            if (md5 == null) {
                continue;
            }
            if (seen.containsKey(md5)) {
                result.add(new CleanItem(f.getAbsolutePath(), len, CleanItem.TYPE_DUP));
            } else {
                seen.put(md5, f);
            }
        }

        // 6. 空目录
        for (int i = 0; i < allDirs.size(); i++) {
            File d = allDirs.get(i);
            if (FileUtil.isEmptyDir(d)) {
                result.add(new CleanItem(d.getAbsolutePath(), 0L, CleanItem.TYPE_EMPTY));
            }
        }

        // 7. 卸载残留：Android/data 下包名目录，对应应用已卸载
        result.addAll(scanResidue());

        // 8. 日志缓存目录
        for (int i = 0; i < allDirs.size(); i++) {
            File d = allDirs.get(i);
            for (int j = 0; j < JUNK_DIRS.length; j++) {
                if (JUNK_DIRS[j].equalsIgnoreCase(d.getName())) {
                    long size = FileUtil.sizeOf(d);
                    if (size > 0) {
                        result.add(new CleanItem(d.getAbsolutePath(), size, CleanItem.TYPE_LOG));
                    }
                    break;
                }
            }
        }

        return dedup(result);
    }

    /** 遍历收集文件与目录 */
    private void collect(File dir, int depth, List<File> files, List<File> dirs) {
        if (dir == null || !dir.isDirectory() || depth > MAX_DEPTH || fileCount > MAX_FILES) {
            return;
        }
        if (isWhitelisted(dir)) {
            return;
        }
        File[] children = dir.listFiles();
        if (children == null) {
            return;
        }
        for (int i = 0; i < children.length; i++) {
            if (fileCount > MAX_FILES) {
                return;
            }
            File c = children[i];
            if (c.isDirectory()) {
                dirs.add(c);
                collect(c, depth + 1, files, dirs);
            } else if (c.isFile()) {
                files.add(c);
                fileCount++;
            }
        }
    }

    private boolean isWhitelisted(File dir) {
        String name = dir.getName();
        for (int i = 0; i < WHITELIST.length; i++) {
            if (WHITELIST[i].equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }

    /** 扫描 Android/data 下的卸载残留 */
    private List<CleanItem> scanResidue() {
        List<CleanItem> out = new ArrayList<CleanItem>();
        File dataDir = new File(Environment.getExternalStorageDirectory(), "Android/data");
        if (!dataDir.exists() || !dataDir.isDirectory()) {
            return out;
        }
        Set<String> installed = new HashSet<String>();
        try {
            PackageManager pm = context.getPackageManager();
            List<PackageInfo> list = pm.getInstalledPackages(0);
            for (int i = 0; i < list.size(); i++) {
                installed.add(list.get(i).packageName);
            }
        } catch (Exception e) {
            return out;
        }
        File[] children = dataDir.listFiles();
        if (children == null) {
            return out;
        }
        for (int i = 0; i < children.length; i++) {
            File d = children[i];
            if (!d.isDirectory()) {
                continue;
            }
            if (!installed.contains(d.getName())) {
                long size = FileUtil.sizeOf(d);
                if (size > 0) {
                    out.add(new CleanItem(d.getAbsolutePath(), size, CleanItem.TYPE_RESIDUE));
                }
            }
        }
        return out;
    }

    /** 同一路径可能被多条规则命中，去重 */
    private List<CleanItem> dedup(List<CleanItem> input) {
        Set<String> seen = new HashSet<String>();
        List<CleanItem> out = new ArrayList<CleanItem>();
        for (int i = 0; i < input.size(); i++) {
            CleanItem item = input.get(i);
            if (seen.add(item.path)) {
                out.add(item);
            }
        }
        return out;
    }
}
