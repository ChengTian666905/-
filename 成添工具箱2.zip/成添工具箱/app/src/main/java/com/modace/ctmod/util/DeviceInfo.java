package com.modace.ctmod.util;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 * 设备信息读取。
 *
 * 原则：
 *  1. 全部走 /proc 与公开 API，不申请运行时权限；
 *  2. 兼容 minSdk 14 —— 不用 MemoryInfo.totalMem（API 16+）、
 *     不用 StatFs.getBlockSizeLong（API 18+）；
 *  3. 任何读取失败返回安全值，不让界面崩。
 */
public final class DeviceInfo {

    private DeviceInfo() {
    }

    /** 总物理内存（字节），失败返回 0 */
    public static long getTotalMemory() {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader("/proc/meminfo"), 1024);
            String line = reader.readLine();
            if (line != null && line.startsWith("MemTotal")) {
                String[] parts = line.split("\\s+");
                return Long.parseLong(parts[1]) * 1024L;
            }
        } catch (Exception e) {
            // 忽略
        } finally {
            closeQuietly(reader);
        }
        return 0L;
    }

    /** 可用内存（字节） */
    public static long getAvailMemory(Context context) {
        try {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return mi.availMem;
        } catch (Exception e) {
            return 0L;
        }
    }

    /** 内部存储 {总, 可用} */
    @SuppressWarnings("deprecation")
    public static long[] getStorage() {
        try {
            String path = Environment.getExternalStorageDirectory().getPath();
            StatFs sf = new StatFs(path);
            long blockSize = sf.getBlockSize();
            long total = ((long) sf.getBlockCount()) * blockSize;
            long avail = ((long) sf.getAvailableBlocks()) * blockSize;
            return new long[]{total, avail};
        } catch (Exception e) {
            return new long[]{0L, 0L};
        }
    }

    /** CPU 快照 {总时间, 空闲时间} */
    public static long[] readCpuSnapshot() {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader("/proc/stat"), 1024);
            String line = reader.readLine();
            if (line == null || !line.startsWith("cpu ")) {
                return null;
            }
            String[] t = line.split("\\s+");
            long user = Long.parseLong(t[1]);
            long nice = Long.parseLong(t[2]);
            long system = Long.parseLong(t[3]);
            long idle = Long.parseLong(t[4]);
            long iowait = Long.parseLong(t[5]);
            long irq = Long.parseLong(t[6]);
            long softirq = Long.parseLong(t[7]);
            long total = user + nice + system + idle + iowait + irq + softirq;
            return new long[]{total, idle};
        } catch (Exception e) {
            return null;
        } finally {
            closeQuietly(reader);
        }
    }

    /** 由两次快照算占用率 0-100，失败返回 -1 */
    public static int calcCpuUsage(long[] first, long[] second) {
        if (first == null || second == null) {
            return -1;
        }
        long totalDiff = second[0] - first[0];
        long idleDiff = second[1] - first[1];
        if (totalDiff <= 0) {
            return -1;
        }
        int usage = (int) ((totalDiff - idleDiff) * 100L / totalDiff);
        if (usage < 0) {
            usage = 0;
        }
        if (usage > 100) {
            usage = 100;
        }
        return usage;
    }

    public static int getCpuCores() {
        try {
            return Runtime.getRuntime().availableProcessors();
        } catch (Exception e) {
            return 0;
        }
    }

    public static String getSystemVersion() {
        return "API " + Build.VERSION.SDK_INT;
    }

    public static String getDeviceModel() {
        return Build.MODEL;
    }

    public static String getManufacturer() {
        return Build.MANUFACTURER;
    }

    private static void closeQuietly(BufferedReader reader) {
        if (reader != null) {
            try {
                reader.close();
            } catch (Exception ignored) {
            }
        }
    }
}
