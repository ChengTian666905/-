package com.modace.ctmod;

import android.content.ClipboardManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.modace.ctmod.lua.LuaCipher;
import com.modace.ctmod.lua.LuaLoader;
import com.modace.ctmod.util.FileUtil;
import com.modace.ctmod.util.FormatUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Lua 加密模块（真实可用）。
 *
 * 流程：
 *   选目录 -> 扫描 .lua -> 逐文件加密 -> 生成自包含 Loader 写入输出目录
 *   -> 可选回环验证（Java 侧解密比对，确认算法对称正确）
 *
 * 诚实提示：Lua 是解释型语言，运行时必须还原明文，
 * 因此这是「混淆级」保护，能挡住直接阅读和随手篡改，挡不住专业逆向。
 */
public class LuaActivity extends BaseModuleActivity implements View.OnClickListener {

    private EditText etSrc;
    private EditText etOut;
    private EditText etKey;
    private RadioGroup rgMode;
    private TextView tvLog;
    private TextView tvLoader;
    private LinearLayout loaderBlock;

    private String lastLoader = "";
    private String lastKey = "";

    @Override
    protected String getTitleText() {
        return getString(R.string.title_lua);
    }

    @Override
    protected int getContentLayoutRes() {
        return R.layout.activity_lua;
    }

    @Override
    protected void buildContent(LinearLayout container) {
        // 使用自定义布局，不往默认容器里加东西
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        etSrc = (EditText) findViewById(R.id.et_src);
        etOut = (EditText) findViewById(R.id.et_out);
        etKey = (EditText) findViewById(R.id.et_key);
        rgMode = (RadioGroup) findViewById(R.id.rg_mode);
        tvLog = (TextView) findViewById(R.id.tv_log);
        tvLoader = (TextView) findViewById(R.id.tv_loader);
        loaderBlock = (LinearLayout) findViewById(R.id.loader_block);

        findViewById(R.id.btn_gen_key).setOnClickListener(this);
        findViewById(R.id.btn_encrypt).setOnClickListener(this);
        findViewById(R.id.btn_verify).setOnClickListener(this);
        findViewById(R.id.btn_save_loader).setOnClickListener(this);
        findViewById(R.id.btn_copy_loader).setOnClickListener(this);

        // 默认给一个随机密钥，省得用户空着手点加密
        etKey.setText(LuaCipher.randomKey());
    }

    @Override
    protected String getFooterText() {
        return "Lua 加密属混淆级保护，可防直接阅读与篡改，无法对抗专业逆向";
    }

    private int currentMode() {
        int checked = rgMode.getCheckedRadioButtonId();
        if (checked == R.id.rb_mode1) {
            return LuaCipher.MODE_STRONG;
        }
        if (checked == R.id.rb_mode2) {
            return LuaCipher.MODE_XXTEA;
        }
        return LuaCipher.MODE_LIGHT;
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btn_gen_key) {
            etKey.setText(LuaCipher.randomKey());
            return;
        }
        if (id == R.id.btn_encrypt) {
            runEncrypt();
            return;
        }
        if (id == R.id.btn_verify) {
            runVerify();
            return;
        }
        if (id == R.id.btn_save_loader) {
            saveLoader();
            return;
        }
        if (id == R.id.btn_copy_loader) {
            copyLoader();
            return;
        }
        super.onClick(v);
    }

    /** 收集待加密的 .lua 文件 */
    private List<File> collectLuaFiles(File root) {
        List<File> out = new ArrayList<File>();
        if (root == null || !root.exists()) {
            return out;
        }
        if (root.isFile()) {
            if ("lua".equals(FileUtil.ext(root.getName()))) {
                out.add(root);
            }
            return out;
        }
        collectLuaRecursive(root, out, 0);
        return out;
    }

    private void collectLuaRecursive(File dir, List<File> out, int depth) {
        if (dir == null || !dir.isDirectory() || depth > 5 || out.size() > 500) {
            return;
        }
        File[] children = dir.listFiles();
        if (children == null) {
            return;
        }
        for (int i = 0; i < children.length; i++) {
            File c = children[i];
            if (c.isDirectory()) {
                collectLuaRecursive(c, out, depth + 1);
            } else if (c.isFile() && "lua".equals(FileUtil.ext(c.getName()))) {
                out.add(c);
            }
        }
    }

    // ==================== 加密 ====================

    private void runEncrypt() {
        final String srcPath = etSrc.getText().toString().trim();
        final String outPath = etOut.getText().toString().trim();
        final String key = etKey.getText().toString().trim();
        final int mode = currentMode();

        if (srcPath.length() == 0 || outPath.length() == 0) {
            toast("请先填写脚本目录和输出目录");
            return;
        }
        if (key.length() == 0) {
            toast("请先生成或填写密钥");
            return;
        }

        final File srcDir = new File(srcPath);
        final File outDir = new File(outPath);
        final List<File> files = collectLuaFiles(srcDir);
        if (files.isEmpty()) {
            tvLog.setText("未在 " + srcPath + " 下找到 .lua 文件");
            return;
        }

        tvLog.setText("开始加密，共 " + files.size() + " 个文件…");
        lastKey = key;

        new Thread(new Runnable() {
            public void run() {
                final StringBuilder log = new StringBuilder();
                int ok = 0;
                int fail = 0;
                long totalIn = 0;
                long totalOut = 0;
                String firstLoader = "";

                for (int i = 0; i < files.size(); i++) {
                    File f = files.get(i);
                    byte[] plain = FileUtil.readBytes(f);
                    if (plain == null) {
                        fail++;
                        log.append("[失败] 读取失败 ").append(f.getName()).append("\n");
                        continue;
                    }
                    String b64 = LuaCipher.encrypt(mode, key, plain);
                    if (b64 == null) {
                        fail++;
                        log.append("[失败] 加密失败 ").append(f.getName()).append("\n");
                        continue;
                    }
                    String loader = LuaLoader.build(mode, key, b64);
                    if (firstLoader.length() == 0) {
                        firstLoader = loader;
                    }
                    // 输出保持与源目录相同的相对结构
                    String rel = relative(srcDir, f);
                    File target = new File(outDir, rel);
                    if (FileUtil.writeText(target, loader)) {
                        ok++;
                        totalIn += plain.length;
                        totalOut += loader.length();
                        log.append("[成功] ").append(rel)
                                .append("  ").append(FormatUtil.formatSize(plain.length))
                                .append(" -> ").append(FormatUtil.formatSize(loader.length()))
                                .append("\n");
                    } else {
                        fail++;
                        log.append("[失败] 写入失败 ").append(rel).append("\n");
                    }
                }

                log.insert(0, "模式：" + LuaLoader.modeName(mode)
                        + "\n密钥：" + key
                        + "\n成功 " + ok + " 个，失败 " + fail + " 个"
                        + "\n原始合计 " + FormatUtil.formatSize(totalIn)
                        + " -> 加密后 " + FormatUtil.formatSize(totalOut)
                        + "\n输出目录：" + outPath + "\n\n");

                final String finalLoader = firstLoader;
                runOnUiThread(new Runnable() {
                    public void run() {
                        tvLog.setText(log.toString());
                        if (finalLoader.length() > 0) {
                            lastLoader = finalLoader;
                            tvLoader.setText(finalLoader);
                            loaderBlock.setVisibility(View.VISIBLE);
                        }
                        toast("加密完成");
                    }
                });
            }
        }).start();
    }

    /** 源目录下的相对路径 */
    private String relative(File base, File file) {
        String basePath = base.getAbsolutePath();
        String full = file.getAbsolutePath();
        if (base.isFile()) {
            return file.getName();
        }
        if (full.startsWith(basePath)) {
            String rel = full.substring(basePath.length());
            while (rel.startsWith("/")) {
                rel = rel.substring(1);
            }
            return rel.length() == 0 ? file.getName() : rel;
        }
        return file.getName();
    }

    // ==================== 回环验证 ====================

    private void runVerify() {
        final String srcPath = etSrc.getText().toString().trim();
        final String key = etKey.getText().toString().trim();
        final int mode = currentMode();
        final File srcDir = new File(srcPath);
        final List<File> files = collectLuaFiles(srcDir);
        if (files.isEmpty()) {
            toast("源目录下没有 .lua 文件");
            return;
        }
        tvLog.setText("回环验证中…");

        new Thread(new Runnable() {
            public void run() {
                int ok = 0;
                int fail = 0;
                StringBuilder log = new StringBuilder();
                for (int i = 0; i < files.size() && i < 50; i++) {
                    File f = files.get(i);
                    byte[] plain = FileUtil.readBytes(f);
                    if (plain == null) {
                        fail++;
                        continue;
                    }
                    String b64 = LuaCipher.encrypt(mode, key, plain);
                    byte[] back = LuaCipher.decrypt(mode, key, b64);
                    if (back != null && sameBytes(plain, back)) {
                        ok++;
                    } else {
                        fail++;
                        log.append("[不一致] ").append(f.getName()).append("\n");
                    }
                }
                log.insert(0, "回环验证（加密后再解密，比对原文）\n成功 "
                        + ok + " 个，失败 " + fail + " 个\n\n");
                final String text = log.toString();
                final int failCount = fail;
                runOnUiThread(new Runnable() {
                    public void run() {
                        tvLog.setText(text);
                        if (failCount == 0) {
                            toast("验证通过：加解密对称正确");
                        } else {
                            toast("存在不一致，请检查模式与密钥");
                        }
                    }
                });
            }
        }).start();
    }

    private boolean sameBytes(byte[] a, byte[] b) {
        if (a == null || b == null || a.length != b.length) {
            return false;
        }
        for (int i = 0; i < a.length; i++) {
            if (a[i] != b[i]) {
                return false;
            }
        }
        return true;
    }

    // ==================== Loader 保存与复制 ====================

    private void saveLoader() {
        if (lastLoader.length() == 0) {
            toast("请先执行一次加密");
            return;
        }
        String outPath = etOut.getText().toString().trim();
        if (outPath.length() == 0) {
            toast("请先填写输出目录");
            return;
        }
        File target = new File(new File(outPath), "ct_loader_sample.lua");
        if (FileUtil.writeText(target, lastLoader)) {
            toast("已保存到 " + target.getAbsolutePath());
        } else {
            toast("保存失败，请检查目录是否有写权限");
        }
    }

    private void copyLoader() {
        if (lastLoader.length() == 0) {
            toast("没有可复制的内容");
            return;
        }
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setText(lastLoader);
            toast("Loader 已复制到剪贴板");
        } catch (Exception e) {
            toast("复制失败：" + e.getMessage());
        }
    }
}
