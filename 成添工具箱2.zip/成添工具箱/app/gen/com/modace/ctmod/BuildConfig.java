/** Automatically generated file. DO NOT MODIFY */
package com.modace.ctmod;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}